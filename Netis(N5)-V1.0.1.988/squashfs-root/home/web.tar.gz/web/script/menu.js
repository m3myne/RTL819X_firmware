var menu_n = (
	function()
	{
		function ctor(o) 
		{
			o && 
			(
				$.CurrentModule = o.loadPage.split(":")[0],
				$.CurrentApp = o.loadPage.split(":")[1]
			);
			init();
		}

		var vrs = 
		{
			_parent : [],
			_child : []
		},

		action = 
		{
			p_click : function(e)
			{
				var m = e.data;
				$.CurrentModule = m.name;
				JQ(vrs._parent).each(function(){
					JQ(this).find('div:eq(0)').attr('class',JQ(this).data('mode') ? 'm_p_img m_no' : 'm_p_img m_jia');
				});

				JQ($.MenuLayer).find('div[class$="m_p_txt_checked"]').attr('class','m_p_txt');
				JQ($.MenuLayer).find('div[class$="panel"]').hide();

				if (m.mode)
				{
					JQ(this).find('div:eq(0)').attr('class','m_p_img m_now'),
					JQ(this).find('div:eq(1)').attr('class','m_p_txt_checked');
					$.CurrentApp = m.name,
					SKK.load(m.name);
				}
				else
				{
					JQ(this).find('div:eq(0)').attr('class','m_p_img m_jian');
					JQ(this).find('div:eq(1)').attr('class','m_p_txt_checked');
					JQ(this).next().show();

					if($.CurrentApp != $.CurrentModule)
					{
						if ( $.CurrentModule == 'network')
						{
							if($.SUPPORT_MULTI_WAN == 1 && JQ("#c_menu_eth_wan").is(':hidden') == false){
								JQ("#c_menu_eth_wan").click();
								return;
							} else if (JQ("#c_menu_wan").is(':hidden') == false) {
								JQ("#c_menu_wan").click();
								return;
							}
						} 
						for (var i in Applications[m.name])
						{
							if (JQ("#c_menu_" + Applications[m.name][i].name).is(':hidden') == false) {
								JQ("#c_menu_" + Applications[m.name][i].name).click();
								return;
							}
						}
						var data = $.DataMap;
						if($.CurrentModule == "network")
						{
							if(data.opMode == "1")
							{
								JQ("#c_menu_opmode").click();
							}
						}
					}
				}
				if (isMobile == true && $.SUPPORT_MOBLIE == 1 && JQ.cookie('AccFrom') != 1) {
					resize_content();
					JQ('#p_menu_network').show();
					JQ('#p_menu_misc').show();
					JQ('#p_menu_wireless').show();
					JQ('#p_menu_wireless5g').show();
				}
			},
			c_click : function(e)
			{
				var m = e.data;
				$.CurrentApp = m.name;
				JQ(vrs._child).each(function(){
					JQ(this).attr('class','menu_child').find('div:eq(0)').attr('class','m_c_img m_no');
				});
				JQ($.MenuLayer).find('div[class$="m_c_txt_checked"]').attr('class','m_c_txt');
				JQ(this).attr('class','menu_child_checked').find('div:eq(0)').attr('class','m_c_img m_now');
				JQ(this).attr('class','menu_child_checked').find('div:eq(1)').attr('class','m_c_txt_checked');
				SKK.load($.CurrentApp);

				if (isMobile == true && $.SUPPORT_MOBLIE == 1) {
					JQ("#full_center").height(0);
					resize_content();
				}
			}
		};

		function init()
		{
			JQ($.MenuLayer).empty();
			
			main_menu = CreateElem(Constant.createDiv,{name:'m_menu'});

			var mds = $.Modules;

			for(var i in mds)
			{
				if(checknobj(i))
				{
					continue;
				}
				var apps = mds[i].Apps,
				parent_element = CreateParent(mds[i]), 
				panel_element = CreateElem(Constant.panelDiv,{name:mds[i].name}),
				clear_element = CreateElem(Constant.createDiv,{name:'clear'}),
				child_element;

				for(var j in apps){
					if(checknobj(j)){
						continue;
					}
					child_element = CreateChild(apps[j],panel_element);
					vrs._child.push(child_element);
					panel_element.append(child_element);
				}	
				main_menu.append(parent_element,panel_element,clear_element);

				vrs._parent.push(parent_element);
			}

			JQ($.MenuLayer).append(main_menu.append(clear_element));
			JQ('.clear').attr("style","clear:both");
			JQ("#p_menu_" + $.CurrentModule).click();
		};

		function CreateParent (data) 
		{
			 var elem = CreateElem(Constant.parentDiv,data),
			 img = CreateElem(Constant.createDiv,{name : data.mode ? 'm_p_img m_no' : 'm_p_img m_jia'}),
			 txt = CreateElem(Constant.createDiv,{name : 'm_p_txt',txt : data.Lan.txt});
			 elem.append(img,txt);
			 return elem;
		}

		function CreateChild (data,panel) {
			 var elem = CreateElem(Constant.childDiv,{name : data.name}),
			 img = CreateElem(Constant.createDiv,{name :'m_c_img m_no'}),
			 txt = CreateElem(Constant.createDiv,{name : 'm_c_txt',txt : data.Lan.txt});
			 elem.append(img,txt);
			 return elem;
		}

		function CreateElem(Topic,data)
		{
			switch (Topic) {
				case Constant.parentDiv:
					return JQ('<div>',{ID : 'p_menu_'+ data.name, class : 'menu_parent'}).data('mode',data.mode).bind('click', { name: data.name, mode: data.mode} , action.p_click);
				case Constant.childDiv:
					return JQ('<div>',{ID : 'c_menu_'+ data.name, class : 'menu_child'}).bind('click' ,{ name: data.name }, action.c_click);
				case Constant.createDiv:
					return JQ('<div>',{class : data.name , text:data.txt});
				case Constant.panelDiv:
					return JQ('<div>',{ID : 'panel_'+ data.name, class : 'menu_child_panel'});
				default:
					return null;
			}
		}
		return {
			init : ctor
		};
	}
)(); 

var Constant = {
	parentDiv 	: 'parentDiv',
	childDiv	: 'childDiv',
	createDiv   : 'createDiv',
	panelDiv	: 'panelDiv'
}
function initMenu(){
	var url=window.location.toString();
	var sp= url.split("/");
	if (sp[sp.length-1].match("index.htm")!=null)
		menu_n.init({loadPage:"status:interface"});
}