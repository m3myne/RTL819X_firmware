jQuery.noConflict();

var WLcome_save = true;
var DvBand = -1;
var IsDef = true;
var showv6 = false;
var RPT = 5;

JQ( function(){
	set_appname();
} );
function set_appname()
{
	var page = "/index.htm";
	JQ(".advance").attr('href', CurrIP + page);
	$.MaxLockTime = 15;
	$.CurrentApp = 'wan_set_shortcut';
	if($.Debug) {
		$.DataMap = debugData;
		init_welcome();
	}
}
function init_welcome()
{
	var data = $.DataMap;
	VEZ = 0;
	additionalData();
	comb_wan_type();
	DvBand = parseInt($.DataMap.wlanBandMode,10);
	
	if (typeof(check_login_pwd) != 'undefined') {
		check_login_pwd();
	}
	if (DvBand & 1)
		$.APCHANNEL.channel = $.DataMap.wlan[$.DataMap.wl2g_idx].channel;
	if (DvBand & 2)
		$.APCHANNEL.channel5g = $.DataMap.wlan[$.DataMap.wl5g_idx].channel;

	init_html(data);
	init_lang(data);
	init_apr(data);
  (function($) {
	if(data.opMode == "1") {
		$(".inter").hide();
	} else {
		if (SKK.SUPPORT_MULTI_WAN != 1)
			$(".inter").show();
	}
	$(".div_2g_mtop").css('margin-top','2px');
	$(".div_5g_mtop").css('margin-top','2px');
  })(jQuery);

	var connv6 = $.DataMap.wan[0].ipv6Type;
	if ($.DataMap.wan[0].ver == '3')
	{
		if (connv6 == '23' || connv6 =='24')
			showv6 = true;
	}
	if (showv6 == false) JQ('#selmode option[value=5]').remove();
	if(data.mapController == "2") {
		JQ(".apr").hide();
		JQ("input[type='button']").prop('disabled',true);
	}
	//如果等于土耳其版本
	if($.DataMap.config_name=="TURKISH_SEGMENT_ISP"){
		if($.DataMap.firstSetup==1 && $.DataMap.superlogin==0){
			JQ(".inter").hide();
		}
	}
}

function apr_idx(rpt, idx)
{
	if (idx == 1){
		if($.DataMap.wlanBandMode & 1) rpt+=parseInt($.DataMap.wl2g_idx);
	}else if (idx == 0){
		if($.DataMap.wlanBandMode & 2) rpt+=parseInt($.DataMap.wl5g_idx);
	}
	return rpt;
}

function enable_wire_click()
{
	var val = get_radio_val("enable_wire");
	JQ('#wpaPsk_t').attr('disabled',val == '0'?true:false);
}

function init_lang(data)
{
	var sel = JQ("#showlang");
	if(!sel.html()){
		var option = eval("("+CUS.Lang_opt+")");
		var select = new CreateSelect(option,'lang');
		sel.append(select.entity);
		JQ('#' + select.ID + ' option[value=' + data.language+ ']').attr('selected', true);
	}
	var option = eval("("+CUS.Lang_opt+")");
	JQ('#setlang')[0][0].text = option[0]+' ('+$.CommonLan['_auto']+')';
}

function init_html(data)
{
	var def_idx = (DvBand == 1)?'1':'0';
	if ($.SUPPORT_MULTI_WAN != 1)
	{
		var wv = data.wan[0];
		set_value(wv.type);
		if(wv.type==22){
			JQ("#wan_ip").val(data.st_wanIpAddr2);
			JQ("#wan_mask").val(data.st_wanSubMask2);
		}else{
			JQ("#wan_ip").val(wv.ipAddr);
			JQ("#wan_mask").val(wv.subMask);
		}
		
		
		JQ("#wan_gw").val(wv.defGw);
		JQ("#wan_dns_a").val(data.dns1 == "0.0.0.0"?"":data.dns1);
		JQ("#wan_dns_b").val(data.dns2 == "0.0.0.0"?"":data.dns2);
		JQ("#pppoe_pwd_btn").mousedown(function(){show_hide_password(1)});
		JQ("#pppoe_pwd_btn").mouseup(function(){setTimeout(function(){show_hide_password(2);},2000);});
	}
}

function set_value(str)
{
	var data = $.DataMap.wan[0];
	JQ("#selmode").val(str);
	JQ("#ip").hide();
	JQ("#mask").hide();
	JQ("#gateway").hide();
	JQ("#dns_a").hide();
	JQ("#dns_b").hide();
	JQ("#user").hide();
	JQ("#pass").hide();
	JQ("#domain").hide();

	switch(str)
	{
		case '21'://Static IP
			JQ("#ip").show();
			JQ("#mask").show();
			JQ("#gateway").show();
			JQ("#dns_a").show();
			JQ("#dns_b").show();
			break;
		case '22'://Russia PPPoE
			JQ("#ip").show();
			JQ("#mask").show();
			break;
		case '3': //L2TP
			JQ("#wan_domain").val(data.servDomain);
			JQ("#domain").show();
			break;
		case '4': //PPTP
			JQ("#wan_domain").val(data.servDomain);
			JQ("#domain").show();
			break;
		default: break;
	}
	if (str == '2' || str == '22' || str == '3' || str == '4' ) {
		JQ("#user").show();
		JQ("#pass").show();
		JQ("#pppoe_username").val(Base64.decode(data.pppUsername));
		JQ("#pppoe_pwd").val(Base64.decode(data.pppPassword));
	}
}

function set_power(str){
	JQ("#wl_power").val(str);
	JQ("#wl_power_image").html("");
	var img = new Image();
	img.className = "wl_power_img";
	img.src=(str=="0")?"images/high.gif":"images/normal.gif";
	img.src+='?a=+'+Math.random();
	JQ('#wl_power_image').html(img);
	JQ("#wl_power_image").css("background","no-repeat scroll center center");
}

function show_hide_password(flag) {
	var val = JQ("#pppoe_pwd").val();
	if(flag == 1) {
		JQ("#ppp_show_hide").html('<input id="pppoe_pwd" maxlength="31" type="text" class="df_text" value=' + val + '>');
	}else{
		JQ("#ppp_show_hide").html('<input id="pppoe_pwd" maxlength="31" type="password" class="df_text"  value=' + val + '>')
	}
}

function deal_ip_mask()
{
	var wan_ip = JQ("#wan_ip").val();
	var wan_mask = JQ("#wan_mask").val();
	var ip_obj = check_text_obj(wan_ip);
	var mask_obj = check_text_obj(wan_mask);

	check_ip(ip_obj);
	if(!ip_obj.val){
	checkShow(JQ("#wan_ip")[0],ip_obj.info);
	return false;
	}
	check_mask(mask_obj);
	if(!mask_obj.val){
		checkShow(JQ("#wan_mask")[0],mask_obj.info);
		return false;
	}
	if(check_ip_lanip(wan_ip,$.DataMap.lanIpAddr) == 4 || check_lan_ip_segment(wan_ip,wan_mask) == 4){
		checkShow(JQ("#wan_ip")[0],$.WLang['_ip_err']);
		return false;
	}
	var obj_wan_ip = new Object();
	obj_wan_ip.text = wan_ip;
	if(!check_ip_mask(wan_ip,wan_mask,obj_wan_ip)){return false;}
	return true;
}

function deal_pppoe(uname,pwd){
	var user_obj = check_text_obj(uname);
	check_string(user_obj);
	if(!user_obj.val){
		checkShow(JQ("#pppoe_username")[0],user_obj.info);
		return false;
	}
	if(uname.length < 1 || uname.length>128){
		checkShow(JQ("#pppoe_username")[0],"Invilad Setting");
		return false;
	}
	var pwd_obj = check_text_obj(pwd);
	check_string(pwd_obj);
	if(!pwd_obj.val){
		checkShow(JQ("#pppoe_pwd")[0],pwd_obj.info);
		return false;
	}
	if(pwd.length < 1 || pwd.length>128){
		checkShow(JQ("#pppoe_pwd")[0],"Invilad Setting");
		return false;
	}
	return true;
}

function deal_static(){
	var wan_ip = JQ("#wan_ip").val();
	var wan_mask = JQ("#wan_mask").val();
	var wan_gw = JQ("#wan_gw").val();
	var dns_a = JQ("#wan_dns_a").val();
	var dns_b = JQ("#wan_dns_b").val();
	var gw_obj = check_text_obj(wan_gw);
	var dns_a_obj = check_text_obj(dns_a);
	var dns_b_obj = check_text_obj(dns_b);

	if(!deal_ip_mask()){WLcome_save = false;return false;}
	check_ip(gw_obj);
	if(!gw_obj.val){
		checkShow(JQ("#wan_gw")[0],gw_obj.info);
		return false;
	}
	check_dns(dns_a_obj);
	if(!dns_a_obj.val){
		checkShow(JQ("#wan_dns_a")[0],dns_a_obj.info);
		return false;
	}
	check_dns(dns_b_obj);
	if(!dns_b_obj.val){
		checkShow(JQ("#wan_dns_b")[0],dns_b_obj.info);
		return false;
	}
	if(wan_ip.split('.')[3] == '0' || wan_ip.split('.')[3] == '255'){
		checkShow(JQ("#wan_ip")[0],$.WLang['_ip_err']);
		return;
	}
	if(wan_gw.split('.')[3] == '0' || wan_gw.split('.')[3] == '255'){
		checkShow(JQ("#wan_gw")[0],$.WLang['_ip_err']);
		return;
	}

	var obj_wan_gw = new Object();
	obj_wan_gw.text = wan_gw;
	if(!check_ip_mask(wan_gw,wan_mask,obj_wan_gw)){return false;}
	return true;
}

function deal_domain(){
	var dom = JQ("#wan_domain").val();
	var obj = check_text_obj(dom);
	check_string(obj);
	if(!obj.val){
		checkShow(JQ("#wan_domain")[0],obj.info);
		return false;
	}
	return true;
}

function saveWan(obj)
{
	//obj.wan_set = 1;
	obj.type = JQ('#selmode').val();
	obj.dnsMode = 0;
	obj.dns1 = "";
	obj.dns2 = "";

	switch(obj.type)
	{
		case '20'://DHCP
			obj.ipoeMtu = 1500;
			break;
		case '21'://Static IP
			if(!deal_static()){WLcome_save = false;return;}
			obj.ipAddr = JQ("#wan_ip").val();
			obj.subMask = JQ("#wan_mask").val();
			obj.defGw = JQ("#wan_gw").val();
			obj.dns1 = JQ("#wan_dns_a").val();
			obj.dns2 = JQ("#wan_dns_b").val();
			obj.ipoeMtu = 1500;
			break;
		case '2'://PPPoE
			obj.dhcp = 0;
			obj.pppMtu = 1492;
			break;
		case '22'://Russia PPPoE
			if(!deal_ip_mask()){WLcome_save = false;return;}
			obj.ipAddr = JQ("#wan_ip").val();
			obj.subMask = JQ("#wan_mask").val();
			obj.dhcp = 1;
			obj.pppMtu = 1492;
			break;
		case '3': //L2TP
			if(!deal_domain()){WLcome_save = false;return;}
			obj.servDomain = JQ("#wan_domain").val();
			obj.dhcp = 0;
			obj.l2tpMtu = 1460;
			break;
		case '4': //PPTP
			if(!deal_domain()){WLcome_save = false;return;}
			obj.servDomain = JQ("#wan_domain").val();
			obj.dhcp = 0;
			obj.pptpMtu = 1400;
			break;
	}
	if (obj.type == '2' || obj.type == '22'||
		obj.type == '3' || obj.type == '4')
	{
		var uname= JQ("#pppoe_username").val();
		var pwd = JQ("#pppoe_pwd").val();
		if(!deal_pppoe(uname,pwd)){WLcome_save = false;return;}
		obj.pppUsername = Base64.encode(uname);
		obj.pppPassword = Base64.encode(pwd);
		obj.connType = 0;//auto
	}
	obj.wan = 'mod';
	obj.id = '1';
	obj.ifIndex = '1';
	return dis_wan_type(obj);
}

function save_shortcut(){
	$.CGI_MOUDLE = {};
	var obj = new Object;
	obj.quick_set = "ap";
	if(!JQ(".inter").is(":hidden"))saveWan(obj);
	if(!WLcome_save) {WLcome_save = true; return;}
	if(!JQ(".apr").is(":hidden"))saveApr(obj);
	if(!WLcome_save) {WLcome_save = true; return;}
	setAppData('save',obj);
}

function initBrowser(s,br){
	for(var i=0;i<br.length;i++){
		if(s.indexOf(br[i].str)!=-1){
			$.BrowserVersion = br[i].type;
			break;
		}
	}
}

function repeater_sh()
{
	var act = false;
	JQ('#d_apr_ssid').show();
	if (APRData.length == 0) {
		act = true;
		JQ('#apr_ssid').val('');
		JQ('#wepKey_t').val('');
		JQ('#wpaPsk_t').val('');
		JQ('#encrypt').val(0);
		JQ('#d_wpaPsk').show();
	}
//	JQ('#apr_ssid').prop('disabled', act);
//	JQ('.btn_save').prop('disabled', act);
	if($.DataMap.wifi_nums==0){
		JQ("#apr_ssid").val(Base64.decode($.DataMap.wlan[$.DataMap.wl2g_idx].ssid))
		JQ("#wpaPsk_t").val(Base64.decode($.DataMap.wlan[$.DataMap.wl2g_idx].wpaPsk))
	}else{
		JQ("#apr_ssid").val(Base64.decode($.DataMap.wlan[$.DataMap.wl5g_idx].ssid))
		JQ("#wpaPsk_t").val(Base64.decode($.DataMap.wlan[$.DataMap.wl2g_idx].wpaPsk))
	}
//	JQ("#wpaPsk_t").removeAttr("disabled")
	
}
function ap_sh()
{
	JQ('.btn_save').prop('disabled', false);
	if(DvBand & 1) JQ('#d_apr_ssid2g').show();
	if(DvBand & 2) JQ('#d_apr_ssid5g').show();
	JQ('#h3_apr').show();
	JQ('#wpaPsk_tip').show();
	JQ('#wire_sec_div').show();
}

function apr_hide_clean()
{
  (function($) {
	$('#d_apr_ssid2g').hide();
	$('#d_apr_ssid5g').hide();
	$('#d_apr_ssid').hide();
	$('#wire_sec_div').hide();

	$('#d_KeySize').hide();
	$('#d_KeySize_64').hide();
	$('#d_KeySize_128').hide();
	$('#d_PskType').hide();
	$('#d_wpaPskType_t').hide();
	$('#d_wpaPskType_a').hide();
	$('#d_keyFormat').hide();
	$('#d_keyFormat_hex').hide();
	$('#d_keyFormat_asc').hide();
	$('#d_wepKey').hide();
	$('#d_wpaPsk').hide();
	$('#wpaPsk_tip').hide();
	$('#wepKey_tip').hide();
	$('#wepKey_t').val('');
	$('#wpaPsk_t').val('');
  })(jQuery);
}

function init_apr(data){
	JQ(".apr").show();
	apr_hide_clean();
	JQ("[data-toggle='popover']").popover();
	apr_mode_sel();
}

function apr_sec_sel()
{
	var apr = get_radio_val("apr_mode");
	apr_hide_clean();
	apr_sec_sel_value(apr);
	if (apr == 20) repeater_sh();
	else ap_sh();
	apr_sec_sel_sh();
}
function apr_sec_sel_value(apr)
{
	var data = $.DataMap.wlan[0];
	var fm = (apr == 20)?false:true;
//	var fm = (typeof(data) != "undefined")?true:false;
	var sec = fm?'4':JQ("#encrypt").val();
	if (apr == 20 && APRData.length == 0) return;
	if(sec == '6') sec = '4';
	if(DvBand & 1) JQ("#apr_ssid2g").val(Base64.decode($.DataMap.wlan[$.DataMap.wl2g_idx].ssid));
	if(DvBand & 2) JQ("#apr_ssid5g").val(Base64.decode($.DataMap.wlan[$.DataMap.wl5g_idx].ssid));

	if (apr == 20) JQ("#encrypt").val(sec);
	switch(sec){
		case '1':
			set_radio("wepKeySize",fm?data.wepKeySize:get_radio_val('wepKeySize'));
			set_radio("keyFormat",fm?data.wepKeyFormat:get_radio_val('keyFormat'));
			JQ("#wepKey_t").val(fm?Base64.decode(data.wepKey):JQ("#wepKey_t").val());
			break;
		case '0':
		case '2':
		case '4':
			set_radio("keyFormat",fm?data.wpaPskFormat:get_radio_val('keyFormat'));
			set_radio("wpaPskType",fm?((data.wpaPskType=='3')?'2':data.wpaPskType):get_radio_val('wpaPskType'));
			JQ("#wpaPsk_t").val(fm?Base64.decode(data.wpaPsk):JQ("#wpaPsk_t").val());
			break;
		default: break;
	}
}

function apr_sec_sel_sh()
{
	var apr = get_radio_val("apr_mode");
	var sec = (apr != 20)?get_radio_val("enable_wire"):JQ('#encrypt').val();

	JQ("#wpaPsk_t").prop('disabled', false);
	switch(sec){
		case '0':
			JQ("#d_wpaPsk").show();
//			JQ("#wpaPsk_t").prop('disabled', (apr == 20)?true:false);
			if (apr != 20)
				enable_wire_click();
			break;
		case '1':
			JQ("#d_wepKey").show();
			break;
		case '2':
		case '4':
			JQ("#d_wpaPsk").show();
			break;
		default: break;
	}
	add_wep_wpa_after();
}

function deal_apr(){
	var apr = get_radio_val("apr_mode");
	var wep_key = JQ("#wepKey_t").val();
	var wpa_key = JQ("#wpaPsk_t").val();
	var wep_key_obj = check_text_obj(wep_key);
	var wpa_key_obj = check_text_obj(wpa_key);

	var secmode = (apr != 20)?get_radio_val("enable_wire"):JQ('#encrypt').val();
	var keysize = get_radio_val("wepKeySize");
	var keymode = get_radio_val("keyFormat");
	var wpamode = get_radio_val("keyFormat");

	var ssid_chk = function(item){
		if (JQ('#'+item).is(':visible') == true) {
			var ssid_obj = check_text_obj(JQ('#'+item).val());
			if (!ssid_obj.data)
			{
				checkShow(ID(item),$.CommonLan["_lock_error"]); return false;
			}
//			var re = /^[a-zA-Z0-9.-_]*$/g;
//				  if(re.test(ssid_obj.data)){
//				    return;
//				  }else{
//				  	checkShow(ID(item),$.CommonLan["_lock_error"]); return false;
//				    return false;
//				  }    
				var reg1 = new RegExp(regMap.che);
				flag1 = reg1.test(ssid_obj.data);
				if(flag1){
					checkShow(ID(item),$.CommonLan["_lock_error"]); return false;
				}
				
			check_string_ssid(ssid_obj);
			if (!ssid_obj.val)
			{
				checkShow(ID(item),ssid_obj.info); return false;
			}
		}
	}
	if (ssid_chk('apr_ssid') == false) return;
	if (ssid_chk('apr_ssid2g') == false) return;
	if (ssid_chk('apr_ssid5g') == false) return;

	var v = null;
	if(secmode == "1"){ //wep
		check_string(wep_key_obj);
		if(!wep_key_obj.val){
			checkShow(JQ("#wepKey_t")[0],wep_key_obj.info);
			return;
		}

		if (apr == 20)
		{
			var len = wep_key.length;
			var map = after_map[$.after_map];
			switch(len){
				case parseInt(map['a'].ch,10):
					v = after_map[$.after_map]['a'];
					set_radio("wepKeySize",1);
					set_radio("keyFormat",1);
					break;
				case parseInt(map['b'].ch,10):
					v = after_map[$.after_map]['b'];
					set_radio("wepKeySize",1);
					set_radio("keyFormat",0);
					break;
				case parseInt(map['c'].ch,10):
					v = after_map[$.after_map]['c'];
					set_radio("wepKeySize",2);
					set_radio("keyFormat",1);
					break;
				case parseInt(map['d'].ch,10):
					v = after_map[$.after_map]['d'];
					set_radio("wepKeySize",2);
					set_radio("keyFormat",0);
					break;
				default:
					checkShow(JQ("#wepKey_t")[0],$.CommonLan["string_null"]);
					return;
					break;
			}
			ch_info = v;
			if(!Qcheck_keyvalue(JQ("#wepKey_t"))){return;}
		} else {
			if(keysize == "1"){
				v = (keymode == "1")?(after_map[$.after_map]['a']):(after_map[$.after_map]['b']);
			}else{
				v = (keymode == "1")?(after_map[$.after_map]['c']):(after_map[$.after_map]['d']);
			}
			if(!Qcheck_keyvalue(JQ("#wepKey_t"))){return;}
		}
	}else if (secmode !='0'){  //wpa , wpa2
		if (apr == 20)
		{
			check_string(wpa_key_obj);
			if(!wpa_key_obj.val){
				checkShow(JQ("#wpaPsk_t")[0],wpa_key_obj.info);
				return;
			}
			var len = wpa_key.length;
			var map = after_map[$.after_map];
			if (len == parseInt(map['e'].ch,10)){
				v = after_map[$.after_map]['e'];
				set_radio("keyFormat",1);
			} else {
				var range = map['f'].ch.split('-');
				var a = parseInt(range[0],10);
				var b = parseInt(range[1],10);
				if(len >= a && len <= b){
					v = after_map[$.after_map]['f'];
					set_radio("keyFormat",0);
				} else {
					checkShow(JQ("#wpa_key")[0],$.CommonLan["string_null"]);
				}
			}
			ch_info = v;
			if(!Qcheck_keyvalue(JQ("#wpaPsk_t"))){return;}
		} else {
			if (get_radio_val("enable_wire") != 0)
			{
				check_string(wpa_key_obj);
				if(!wpa_key_obj.val){
					checkShow(JQ("#wpaPsk_t")[0],wpa_key_obj.info);
					return;
				}
				v = (wpamode == "1")?(after_map[$.after_map]['e']):(after_map[$.after_map]['f']);
				if(!Qcheck_keyvalue(JQ("#wpaPsk_t"))){return;}
			}
		}
	}
	ch_info = v;
	return true;
}

function Qcheck_keyvalue(tag){
	var val = tag.val();
	var ch = ch_info.ch;
	var str = ch_info.str.replace(/\(/g,"").replace(/\)/g,"");
	if(!val || val ==''){checkShow(tag[0],str);return false;}

	if(ch.split('-').length != 2){
		if(val.length != parseInt(ch,10) && val.indexOf('%26') =='-1'){
			checkShow(tag[0],str);
			return false;}
	}else{
		var a = parseInt(ch.split('-')[0],10);
		var b = parseInt(ch.split('-')[1],10);
		if(val.length < a || val.length > b){
			checkShow(tag[0],str);
			return false;}
	}
	if (ch_info.type == 'hex'){
		var obj = check_text_obj(val);
		check_hex(obj);
		if(!obj.val){
			checkShow(tag[0],obj.info);
			return false;
		}
	}

	return true;
}

function setAprParam(obj)
{
	var mode = get_radio_val("apr_mode");
	var encrypt = 0;
	var idx = ((DvBand==1)?'1':'0');

	obj.wlanMode = mode;
	if(mode=='20') {
		if ( APRData.length != 0)
			idx = (parseInt(APRData[3].split(' ')[0],10) <14)?1:0;
		obj.ssid = Base64.encode(JQ("#apr_ssid").val());
		obj.rp_ssid = Base64.encode(JQ("#apr_ssid").val());
		encrypt = JQ('#encrypt').val();
	} else {
		if(DvBand & 1) obj.ssid2g = Base64.encode(JQ("#apr_ssid2g").val());
		if(DvBand & 2) obj.ssid5g = Base64.encode(JQ("#apr_ssid5g").val());
		encrypt = (get_radio_val("enable_wire") !=0)?6:0;
	}
	obj.wl_idx = (idx!="0")?$.DataMap.wl2g_idx:$.DataMap.wl5g_idx;
	obj.wlanEnabled = 1;
	if($.DataMap.model=='NC65')
		obj.encrypt = 4;
	else
		obj.encrypt = ($.DataMap.vender=='RUSSIA' && ($.DataMap.model=='N4M' || $.DataMap.model=='N3M' || $.DataMap.model=='N2M' || $.DataMap.model=='M1'))?4:encrypt;

	if(obj.encrypt == 1) {
		obj.wepKey = Base64.encode(JQ("#wepKey_t").val());
		obj.wepKeySize = get_radio_val("wepKeySize");
		obj.wepKeyFormat = get_radio_val("keyFormat");
	}
	else if(obj.encrypt != 0) {
		var wpa = (mode=='20')?get_radio_val("wpaPskType"):3;
		obj.wpaPsk = Base64.encode(JQ("#wpaPsk_t").val());
		if($.DataMap.model=='NC65')
			obj.wpaPskType = 2;
		else
			obj.wpaPskType = ($.DataMap.vender=='RUSSIA' && ($.DataMap.model=='N4M' || $.DataMap.model=='N3M' || $.DataMap.model=='N2M' || $.DataMap.model=='M1'))?2:wpa;
		obj.wpaPskFormat = get_radio_val("keyFormat");
	}
}

function saveApr(obj)
{
	if(!deal_apr()){WLcome_save = false;return;}
	setAprParam(obj);
}
function apr_mode_sel(val)
{
	var rpt5 = rpt2 = RPT;
	var act = actenc = 0;

	if(DvBand & 1) rpt2=apr_idx(0,1);
	if(DvBand & 2) rpt5=apr_idx(0,0);

	if (typeof(val) == 'undefined') {
		if(DvBand & 1 && DvBand & 2)
		{
			if($.DataMap.wlan[rpt2].wlanMode == 20 || $.DataMap.wlan[rpt5].wlanMode == 20)
				act = 20;
		} else if(DvBand & 1) {
			if($.DataMap.wlan[rpt2].wlanMode == 20)
				act = 20;
		} else if(DvBand & 2) {
			if($.DataMap.wlan[rpt5].wlanMode == 20)
				act = 20;
		}
		if($.DataMap.opMode != "1") {
			act = 0;
			JQ('#d_apr_sel_mode').hide();
		}
		set_radio("apr_mode", act);

		if(DvBand & 1 && DvBand & 2)
		{
			if($.DataMap.wlan[rpt2].encrypt != 0 || $.DataMap.wlan[rpt5].encrypt != 0)
				actenc = 4;
		} else if(DvBand & 1) {
			if($.DataMap.wlan[rpt2].encrypt != 0)
				actenc = 4;
		} else if(DvBand & 2) {
			if($.DataMap.wlan[rpt5].encrypt != 0)
				actenc = 4;
		}
		set_radio("enable_wire", actenc);
	}

	apr_sec_sel();
}

function change_language_show(langs, onchange_lang){
	$.Language = ($.ShowLang)?langs:$.Language;
	$.after_map = ($.ShowLang)?langs:$.Language;
	obj2obj($.WLang,Language[langs].welcome);
	obj2obj($.LLang,Language[langs].network);
	obj2obj($.CommonLan,Language[langs].common);

	var pwdlang = Language[langs].misc.passwd;;
	var llang = $.LLang.wan;
	var wlang = $.WLang;
	var CommonLan = $.CommonLan;
	var band = $.DataMap.wlanBandMode;
	if (onchange_lang == 'yes') add_wep_wpa_after();

  (function($) {
	$(function() {
		var l = band == 3?1:0;
		document.title = SpanLang(wlang['welcome'], [SKK.CO.name]);
		if (SKK.CO.url != "" || SKK.CO.email != "") {
			$("#co").show();
			if (SKK.CO.url != "") $('#url').attr("href", SKK.CO.url).html(SKK.CO.url);
			if (SKK.CO.email != "")
				$("#mail").attr("href", "mailto:" + SKK.CO.email).text(wlang['email'] + ': ' + SKK.CO.email);
		} else $("#co").hide();
		if (SKK.CO.url != "" && SKK.CO.email != "")
			$('#url').html($('#url').html() + ' | ');

		if ($('#setlang').length > 0) {
			var option = eval("("+CUS.Lang_opt+")");
			$('#setlang')[0][0].text = option[0]+' ('+CommonLan['_auto']+')';
		}

		$('#pcver').text(wlang['acc_from_pc']);
		$('#mobver').text(wlang['acc_from_mob']);
		$('.btn_save').val(wlang['save']);
//		$('#advanced').html(wlang['advanced']);
		$('#div_qs').html(wlang['txt']);
		$('#h3_inter').html(wlang['inter']);
		$('#h3_apr').html(wlang['wire']);

		if (SKK.SUPPORT_MULTI_WAN != 1)
		{
			var options = eval(llang.type_options);
			for(var i in options){
				$('#selmode option:eq('+i+')').text(options[i]);
			}
			$("#l_ip").text(wlang['wanIpAddr']);
			$("#l_mask").text(wlang['mask']);
			$("#l_gateway").text(wlang['gateway']);
			$("#l_dns_a").text(wlang['dns_a']);
			$("#l_dns_b").text(wlang['dns_b']);
			$("#l_user").text(wlang['user']);
			$("#l_pass").text(wlang['pass']);
			$("#l_domain").text(wlang['domain']);
		}

		if (typeof(w_connect) != 'undefined') {
			w_connect();
		}

		// AP/R
		$("#div_apr_sel_mode").text(wlang['radioMode']+ ' : ');
		$("#div_apr_sel_band").text(llang['wispWanId_label']+ ' : ');
		$("#l_apr_mode_auto").text(wlang['repeater']);
		$("#l_apr_mode_ap").text(wlang['work_mode_ap']);
		$("#l_apr_band_2").text(wlang['wlan2']);
		$("#l_apr_band_5").text(wlang['wlan5']);
		$('#div_wire_sec').html(wlang['wire_sec']);
		$("#l_sec_mode_none").text(wlang['disable']);
		$("#l_sec_mode_mix").text(wlang['enable']);

		var oEncrypt = eval(llang.encrypt_options);
		for(var i in oEncrypt){
			$('#encrypt option:eq('+i+')').text(oEncrypt[i]);
		}
		$('#div_apr_ssid').html(wlang['ssid']);
		$('#div_apr_ssid2g').html("SSID ("+wlang['wlan2']+") :");
		$('#div_apr_ssid5g').html("SSID ("+wlang['wlan5']+") :");
		$('#btn_apr_ssid').val(CommonLan['ap_get']);
		$('#l_encrypt').html(llang['encrypt_label']+ ' : ');
		$('#l_wepKeySize').html(llang['wepKeySize_label']+ ' : ');
		$('#l_wepKeySize0').html(llang['64_r']);
		$('#l_wepKeySize1').html(llang['128_r']);
		$('#l_wpaPskType').html(llang['wpaPskType_label']+ ' : ');
		$('#l_keyFormat').html(llang['wepKeyFormat_label']+ ' : ');
		$('#l_keyFormat0').html(llang['hex_r']);
		$('#l_keyFormat1').html(llang['asc_r']);
		$('#l_wepKey').html(llang['wepKey_label']+ ' : ');
		$('#l_wpaPsk').html(llang['wpaPsk_label']+ ' : ');
		$('.btn_back').val(CommonLan['_back']);
		$('#btn_extend').html(CommonLan['connect']);
		$('#btn_refresh').html(CommonLan['_rescan']);
	});

  })(jQuery);
}