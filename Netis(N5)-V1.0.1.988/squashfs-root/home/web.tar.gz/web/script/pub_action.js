var sec_map = {'0':'None','1':'WEP','2':'WPA-PSK','4':'WPA2-PSK','6':'WPA/WPA2-PSK'};
var secen_map = {'1':'TKIP','2':'AES', '3':'TKIP+AES'};
var net_map = {'0':'AP','1':'CLIENT','20':'REPEATER'};
var comm_map = {'0':'Bridged','1':'IPOE','2':'PPPoE','3':'L2TP/Russia L2TP','4':'PPTP/Russia PPTP','5':'Dslite','6':'6rd','20':'Dynamic IP','21':'Static IP','22':'Russia PPPoE','23':'autoconfig', '24':'static', '25':'pppoev6'};
var mtu_mapping = {'3':1460,'4':1400,'20':1500,'21':1500,'modem':1500,'ipv6_configure':1492,'min':576};
var proto_map = new Object();
var protoval_map = new Object();
var Scroll_ST = true;
var VEZ = 0;
var MAX_VEZ = 60;
var AJAX_STATUS = false;
var JQ = jQuery.noConflict();
jQuery.noConflict();

//接口信息
var sys_status_time = null;
var status_time=2000;
var moreHei = 0;
var stop_time=3;

//弹窗
function pop_ups_show(){
	if(JQ(".tr069_upgrade_2").html()==""){
		JQ(".tr069_upgrade_2").html($.CommonLan['tr069_upgrade_2']);
	}
	if($.DataMap.tr069_upgrade_status==2 || $.DataMap.auto_upgrade_status==2){
		status_time=60000;	
		JQ(".pop_ups_s").show();
	}else{
		status_time=2000;
		JQ(".pop_ups_s").hide();
		stop_time=3;
	}
}

function before_func_init()
{
	var page = "/welcome.htm";
	if (isMobile == true && $.SUPPORT_MOBLIE == 1 && JQ.cookie('AccFrom') != 1)
	{
		if (window.location.href.match("moblie")==null){
			window.location.href = CurrIP + "/moblie_index.htm"; return;}
	}
	if (isMobile != true || $.SUPPORT_MOBLIE != 1)
	{
		if (window.location.href.match("moblie")!=null) {
			window.location.href = CurrIP + "/index.htm"; return;}
	}

	var option = eval("("+CUS.Lang_opt+")");
	JQ('#setlang')[0][0].text = option[0]+' ('+$.CommonLan['_auto']+')';
	JQ("#welcomea").attr('href', CurrIP+page);
	if ($.CO.url != "" || $.CO.email != "") {
		JQ("#co").show();
		if ($.CO.url != "") JQ('#url').attr("href", $.CO.url).html($.CO.url);
		if ($.CO.email != "")
			JQ("#mail").attr("href", "mailto:" + $.CO.email).text($.WLang['email'] + ': ' + $.CO.email);
	} else JQ("#co").hide();
	if ($.CO.url != "" && $.CO.email != "")
		JQ('#url').html(JQ('#url').html() + ' | ');
	JQ("#pcver").text($.WLang['acc_from_pc']);
	JQ("#mobver").text($.WLang['acc_from_mob']);
	if (isMobile == true)
	{
		if (JQ.cookie('AccFrom') != 1) {
			JQ("#pcver").show();
			JQ("#mobver").hide();
		} else {
			JQ("#pcver").hide();
			JQ("#mobver").show();
		}
	}
}
function init_status(){
	if (typeof(check_login_pwd) != 'undefined') {
		if ($.DataMap.setup == 0)
			window.location.href = CurrIP + "/welcome.htm";
	} else
		JQ('#welcomea').show();
	JQ(".f_center").resize(function(event) {
		if(moreHei != 0){
			JQ(".f_left").height(moreHei);
			JQ(".f_right").height(moreHei);
		}else{
			var rehei = JQ(".f_center").height();
			JQ(".f_left").height(rehei+moreHei);
			JQ(".f_right").height(rehei+moreHei);
		}
	});

	JQ("#menu_layer").resize(function(event) {
		var hei = (JQ("#version_v").height() +JQ("#menu_top").height()+JQ("#menu_layer").height()+JQ("#menu_bottom").height());
		if(JQ(".f_left").height() < hei){
			JQ(".f_left").height(hei);
			JQ(".f_right").height(hei);
		}
		if($.CurrentModule == "misc"){
			moreHei = hei;
			JQ(".f_left").height(moreHei);
			JQ(".f_right").height(moreHei);
		}else{
			moreHei = 0;
			var rehei = JQ(".f_center").height();
			JQ(".f_left").height(rehei+moreHei);
			JQ(".f_right").height(rehei+moreHei);
		}
	});

	if(sys_status_time!=null)
		window.clearInterval(sys_status_time);

	get_sys_status();
	easymashShow();
	sys_status_time = window.setInterval(get_sys_status,status_time);
	
}
function get_sys_status(){
	pop_ups_show();
	if($.CurrentApp != "status"){
		window.clearInterval(sys_status_time);
		return;
	}
	getAppData(function(data){
		setAppTagData(data);
		if($.CurrentApp=='status'){
		change_status_show(data);
		getTag('status_wan','connected').btn.entity.onclick = function(){
			$.CGI_MOUDLE = {};
			var obj = new Object();
			obj.connected = (data.connected=='0')?'1':'0';
			if(true){
				setAppData(null,obj);
			}else{return;}
		}
		getTag('status_wan','connected').btn.entity.value=(data.connected=='0')? $.CommonLan['connect']:$.CommonLan['disconnect'];
		}
	});
}
function go(val,acc)
{
	if (val == 0){
		JQ.cookie('AccFrom', '0', { path:'/'});
		if (acc =='i') window.location.href = CurrIP + "/moblie_index.htm";
	}else{
		JQ.cookie('AccFrom', '1', { path:'/'});
		if (acc =='w') window.location.href = CurrIP + "/welcome.htm";
		if (acc =='i') window.location.href = CurrIP + "/index.htm";
	}
}
//log根据接口代码自动修改显示
function log_show(){
	
	if($.DataMap.version.slice(0,1)=="N"){
		if(JQ("#logo_img").attr("src")!="./images/logo_n.png"){
			 var link = document.createElement("link");
	        link.href = "./images/favicon_n.ico";
	        link.rel = "shortcut icon";
	        document.head.appendChild(link);
	        JQ("#logo_img").attr("src","./images/logo_n.png");
	        JQ("#logo_img").show();
		}
		
	}else{
		if(JQ("#logo_img").attr("src")!="./images/logo_s.png"){
		 var link = document.createElement("link");
        link.href = "./images/favicon_s.ico";
        link.rel = "shortcut icon";
        document.head.appendChild(link);
        JQ("#logo_img").attr("src","./images/logo_s.png");
        JQ("#logo_img").show();
       }
	}
	
	
	
}



function init_version(){
	var data = $.DataMap;
	if(data.version){
		JQ("#version_v").html(data.version.substring(data.version.indexOf("(")+1,data.version.lastIndexOf(")")))
		var v = data.version.split("-")[1].split(",")[0];
		var v = data.version.split(",")[0].split("-")[data.version.split(",")[0].split("-").length-1];
		JQ("#version_n").html(v)
	}
	log_show();
	
	//jim test 20210812
	if(data.serialNo){
		//alert('serial no:' + data.serialNo);// for debug
		var sno = data.serialNo;
		JQ("#serial_no").html('S/N: '+sno)
	}
	//end of jim test 20210812
	var str = SpanLang($.CommonLan['advanced_title'], [$.CO.name]);
	if (typeof(tit_customized) != 'undefined') {
		str = tit_customized();
	}
	document.title = str;

	JQ("#btn_quick").html($.WLang['txt']);
}

function display_lang_sel(data)
{
	if (isMobile == true && $.SUPPORT_MOBLIE == 1  && JQ.cookie('AccFrom') != 1) {
		JQ('#setlang').removeClass("df_select");
		var sel = JQ('#showlang');
	} else
		var sel = JQ('#menu_bottom');
	if(!sel.html()){
		var option = eval("("+CUS.Lang_opt+")");
		var select = new CreateSelect(option,'lang');
		sel.append(select.entity);
		JQ('#' + select.ID + ' option[value=' + data.language+ ']').attr('selected', true);
	}
}
function CreateSelect(options,type){
	if($.BrowserVersion.indexOf('IE')!= -1){
		Element.call(this,"SELECT:df_select_ie");
	}else{
		Element.call(this,"SELECT:df_select");
	}
	if (type == 'lang')
	{
		this.setID('setlang');
		for(var i in options){
			var v = CUS.Lang_map_re[options[i]];
			if(i==0) v= 0;
				this.entity.options.add(new Option(options[i],v));
		}
	}else if (type == 'multi'){
		this.setID('multi');
		for(var i in options){
			this.entity.options.add(new Option(options[i],i));
		}
	}

	var _this = this;
	this.entity.onchange = function(){
		if (this.id == 'setlang')
			sel_onchange_lang(this);
		else if (this.id == 'multi')
			sel_multi_opt(this);
	}
	this.checked = function(val){
		this.entity.value = val;
		this.entity.onchange();
	}
	this.setData = function(val){
		if(val){
			this.checked(val);
			this.data = val;
		}
	}
}
function sel_onchange_lang(that){
	$.CGI_MOUDLE = {};
	var ch = false;
	for(var i=0;i<that.options.length;i++){
		var opt = that.options[i];
		if(opt.value == that.value){
			that.setAttribute("selected",that.value);
			ch = true;
			break;
		}
	}
	if(!ch && $.BrowserVersion.indexOf('IE')!= -1){
		_this.data = that.options[0].value;
		_this.checked(_this.data);
	}
	var lang_val = ($.ShowLang)?that.value:$.Language;
	var lang_tmp = (lang_val == 0)?lang_str_mapping():lang_val;
	if($.CurrentApp == 'wan_set_shortcut')
		lang_import(CUS.Lang_map[lang_tmp],"yes");
/* 	if($.CurrentApp != 'wan_set_shortcut') {
		if(!$.Debug && !$.Emulator)
			$.lockWin($.CommonLan['lock_save'],'',3);
	}else
		lang_import(CUS.Lang_map[lang_tmp],"yes"); */
	if($.CurrentApp=='status'){change_status_show($.DataMap)}
	var obj = new Object();
	obj.language = lang_val;
	if($.MenuLayer)
		$.lang($.CurrentApp,false,lang_tmp);
	setAppData('lang',obj);
}

function lang_import(lang, onchange_lang){
	if (typeof(Language[lang]) != 'undefined')
	{
		if(!$.MenuLayer) change_language_show(lang, onchange_lang);
		return;
	}
	ajax_get_lang("./config/language_"+ lang.toLowerCase() + ".js");
	if(!$.MenuLayer)
		change_language_show(lang, onchange_lang);
}

/**
** send an jQuery ajax
** param - js file name
** isAsync - asynchronized or not (optional, default=false)
*/
function ajax_get_lang(param,isAsync)
{
	var ajax_param = {
		type: "GET",
		async: (isAsync==undefined?false:isAsync),
		url: param,
		dataType: "script",
		overrideMimeType: "application/x-www-form-urlencoded; charset=UTF-8",
		success: function (result) {
			//console.log("success");
		},
		error: function(xhr, ajaxOptions, thrownError){
			//console.log("init page error");
		}
	};
	JQ.ajax(ajax_param);
}

var up_url = ['/upload_fw.cgi', '/upload_config.cgi'];
function ajax_update(isAsync, curl)
{
	var formData = new FormData();
	var file = file_val.files[0];
	formData.append('update', file, file.name);
	setAppTagData($.DataMap);
	var ajax_param = {
		type: "POST",
		url: "./cgi-bin"+curl,
		data:formData,
		async: (isAsync==undefined?false:isAsync),
		contentType: false,
		processData: false,
		success: function (result) {
			if (result != "[\"SUCCESS\"]") {
				window.clearInterval(loadtime);
				getPan(0).show();
				if($.DataMap.autoUpdate) getPan(1).show();
					getPan(2).hide();
				$.Lock.load.show();
                               if( result == 130 )
                               {
                                        $.unlockWin($.CommonLan["_invalid_bin"]);
                               }
				else if(result==131)
                                {
                                          $.unlockWin($.CommonLan["_invalid_must_reboot"]);
                                }		
                               else
                               {
                                        $.unlockWin($.CommonLan["_lock_error"]);
                               }				
			}
		},
		error: function(xhr, ajaxOptions, thrownError){
			console.log("init page error");
		}
	};
	JQ.ajax(ajax_param);
}
function easymashShow(){
	if($.DataMap.easy_mesh=="EASYMESH"){
		JQ("#p_menu_easymesh").show();
	}else{
		JQ("#p_menu_easymesh").hide();
	}
}
function ajax_sendRequest(url,param,callback,isAsync,type)
{
	var in_sync = true;
	var str = '';

	
	if (url == "skk_get")
		in_sync = (isAsync == undefined)?false:in_sync;
	for(var i in param){
		str += i + "=" + param[i] + "&";
	}

	var ajax_param = {
		type: "POST",
		async: in_sync,
		url: $.PATH + url + ".cgi",
		data: str,
		success: function (data) {
			try{
				var data = eval("("+data+")");
				if (url == 'skk_get')
				{
					if ($.CurrentApp != 'wan_set_shortcut') {
						if (AJAX_STATUS == true) return;
						if ($.CurrentApp == "sys_log" || $.CurrentApp == "diagnostic")
							$.SPDataMap = data;
						else {
							$.DataMap = data;
							easymashShow();
							if($.DataMap.config_name=="GEORGIA"){
								JQ("#c_menu_wireless_network").show();
								}else{
									JQ("#c_menu_wireless_network").hide();
							}
								log_show();
							if ($.SUPPORT_MULTI_WAN != 1) comb_wan_type();
							additionalData();
						}
						if (JQ('#lock_load').is(':visible') == true) {
							AJAX_STATUS = true;
							$.load($.CurrentApp);
							$.unlockWin($.CommonLan['_save_success']);
						}
					
					} else {
						$.DataMap = data;
						log_show();
						easymashShow();
						if (type != 'quick' && $.LockInterval != undefined)
							$.unlockWin($.CommonLan['_save_success']);
					}
				}
				if(callback){ callback(data);}
			}catch(e){
				if (url == 'skk_get') {
					VEZ +=1;
					if (VEZ >= MAX_VEZ)
						console.log($.CommonLan['_timeout']);
					else{
						
							setTimeout(function(){
								ajax_sendRequest(url,param,callback,isAsync);
							},status_time);
						}
						
					
					//console.log("ajax_sendRequest success catch(e)");
				}
			}
		},
		error: function(xhr, ajaxOptions, thrownError){
			if (url == 'skk_get') {
				VEZ +=1;
				if (VEZ >= MAX_VEZ)
					console.log($.CommonLan['_timeout']);
				else{
					
					setTimeout(function(){
						ajax_sendRequest(url,param,callback,isAsync);
					},status_time);
						
				}
				//console.log("ajax_sendRequest error");
			}
		}
	};
	if (url == "skk_get") ajax_param.timeout = 5000;	
	if($.DataMap.tr069_upgrade_status!=0 || $.DataMap.auto_upgrade_status!=0){
		stop_time--;
		if(stop_time==0){
			return false;
		}else if(stop_time>0){
			JQ.ajax(ajax_param);
		}else if(stop_time==-95){
			stop_time=1;
			JQ.ajax(ajax_param);
		}
	}else{
		JQ.ajax(ajax_param);
	}
	
}

function ajax_AutoFWRequest(param, callback) {
	// var in_sync = true;
	var str = '';
	if ($.Debug) {
		if (callback) { callback(); }
		if (!$.Emulator) { testInfo(param); return; }
		else {
			if (type != null)
				$.lockWin($.CommonLan['lock_save']);
			return;
		}
	}

	for (var i in param) {
		str += i + "=" + param[i] + "&";
	}

	try {
		var ajax_param = {
			type: "POST",
			async: true,
			url: $.PATH + "update.cgi",
			data: str,
			success: function (data) {
				try {
					var data = eval("(" + data + ")");
					if (callback) { callback(data); }
				} catch (e) {
					console.log('AutoFW error');
				};
			},
			error: function (xhr, ajaxOptions, thrownError) {
				console.log('AutoFW error');
			}
		};
	} catch (e) {
		console.log('AutoFW error');
	}
	JQ.ajax(ajax_param);
}
function init_SHRadioAct(){setAppTagData($.DataMap); $.exec(getTag(0,0).action);}
function init_setdata_only(){setAppTagData($.DataMap);}
function refresh_only(){$.Refresh();}

function toshowhide(obj)
{
	var txt = '_img_';
	var tag = obj.id.split(txt)[0];
	var val = JQ('#'+tag).val();
	if (JQ('#'+tag).prop('disabled') == true)
		return;
	if (JQ('#'+tag+'_img_show').is(':hidden'))
	{
		JQ('#'+tag+txt+'show').show();
		JQ('#'+tag+'_show_hide').html('<input id="'+tag+'" maxlength="31" type="text" class="df_text" autocomplete="off" value=' + val + '>');
	} else {
		JQ('#'+tag+txt+'hide').show();
		JQ('#'+tag+'_show_hide').html('<input id="'+tag+'" maxlength="31" type="password" class="df_text"  value=' + val + '>')
	}
	JQ('#'+obj.id).hide();
}
/*************************************** system statistics ***************************************/
var statistics_time = null;
function statistics_hide_wan(){
	if($.DataMap.opMode == 1){
		JQ("#row_1").css("display",'none'); // WAN
	}
}
function init_statistics(){
	if($.DataMap.config_name=="GEORGIA"){
		new_statistics();
	}else{
		old_statistics();
	}
}
//新的统计图
function new_statistics(){
	var data = $.DataMap;
	setAppTagData(data);
	
	if(data.cpu == "100%"){
		var cpu = Math.floor(Math.random()*30) + 50;
		data.cpu = cpu + "%";
	}
	var day = parseInt(parseInt(data.uptime)/86400);
	var hour = parseInt((parseInt(data.uptime)-day*86400)/3600);
	var min = parseInt((parseInt(data.uptime)-day*86400-hour*3600)/60);
	var sec = parseInt(data.uptime)-day*86400-hour*3600-min*60;
	var runTime = day+$.CommonLan['days']+' '+hour+$.CommonLan['hours']+' '+min+$.CommonLan['minutes']+' '+sec+$.CommonLan['seconds'];
	getTagDom(0,0,'context').html(runTime);
	statistics_hide_wan();
	
	if(statistics_time)
		window.clearTimeout(statistics_time);
	statistics_time = window.setTimeout(function(){
		statistics_loop();
	},1000);
	
	init_statistics_tab(data);
	JQ("#refresh_statis").off("click").on("click",function(){
		getAppData(function(data){
			init_statistics_tab(data);
		});												  
	});
}

//老的统计图
function old_statistics(){
	var data = $.DataMap;
	if(data.cpu == "100%"){
		var cpu = Math.floor(Math.random()*30) + 50;
		data.cpu = cpu + "%";
	}
	setAppTagData(data);
	var show = getTag(1,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[3].innerHTML = getnum(data.tx_bytes);
		show[i].entity.cells[4].innerHTML = getnum(data.rx_bytes);
	}
	
	var day = parseInt(parseInt(data.uptime)/86400);
	var hour = parseInt((parseInt(data.uptime)-day*86400)/3600);
	var min = parseInt((parseInt(data.uptime)-day*86400-hour*3600)/60);
	var sec = parseInt(data.uptime)-day*86400-hour*3600-min*60;
	var runTime = day+$.CommonLan['days']+' '+hour+$.CommonLan['hours']+' '+min+$.CommonLan['minutes']+' '+sec+$.CommonLan['seconds'];
	getTagDom(0,0,'context').html(runTime);
	statistics_hide_wan();
	if (statistics_time != null)
		window.clearInterval(statistics_time);
	statistics_time = window.setInterval(function(data) {
		if ($.CurrentApp != 'statistics')
			window.clearInterval(statistics_time);
		else {
			getAppData(function(data){
				data = $.DataMap;
				if (data.cpu == "100%") {
					var cpu = Math.floor(Math.random() * 30) + 50;
					data.cpu = cpu + "%";
				}
//				setAppTagData(data);
				var day = parseInt(parseInt(data.uptime) / 86400);
				var hour = parseInt((parseInt(data.uptime) - day * 86400) / 3600);
				var min = parseInt((parseInt(data.uptime) - day * 86400 - hour * 3600) / 60);
				var sec = parseInt(data.uptime) - day * 86400 - hour * 3600 - min * 60;
				var runTime = day + $.CommonLan['days'] + ' ' + hour + $.CommonLan['hours'] + ' ' + min + $.CommonLan['minutes'] + ' ' + sec + $.CommonLan['seconds'];
				getTagDom(0, 0, 'context').html(runTime);
				statistics_hide_wan();
			});
		}
		
	var show = getTag(1,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[3].innerHTML = getnum(data.tx_bytes);
		show[i].entity.cells[4].innerHTML = getnum(data.rx_bytes);
	}
	}, 1000);
	
	
}

function statistics_loop(){
	if (statistics_time != null)
		window.clearInterval(statistics_time);
	statistics_time = window.setInterval(function(data) {
		if ($.CurrentApp != 'statistics'){
			window.clearInterval(statistics_time);
			return;
		}
		getAppData(function(data){
			init_statistics();
		});
	}, 1000);
}

function init_statistics_tab(data){
	var duplex = ["H","F"];
	var speed = ["10","100","1000"];
	var cont = new Element("DIV");
	getTag(1,0).append(cont);
	getTag(1,0).cont = cont;
	var parent = getTag(1,0).cont.entity.parentNode;
	parent.removeChild(parent.children[0]);
	getTag(1,0).cont.entity.innerHTML = '<table id="statistics_tab" class="df_tab" style="table-layout:fixed;">' + 
										  '<thead class="df_thead">' + 
											  '<tr class="statistics_type_head">' +
												'<td  class="top_ceil"><div></div></td>'+
												'<td colspan="2">' + $.DataMap.statsList[0].type + '</td>'+
												'<td>' + $.DataMap.statsList[1].type + '</td>'+
												'<td>' + $.DataMap.statsList[2].type + '</td>'+
												'<td>' + $.DataMap.statsList[3].type + '</td>'+
												'<td>' + $.DataMap.statsList[5].type + '</td>'+
												'<td>' + $.DataMap.statsList[4].type + '</td>'+
											  '</tr>' + 
											  '<tr class="statistics_sub_head">' + 
//												'<td>' + 
//													'<div class="sub_title">SPF</div>' +
////													'<div>'+ ($.DataMap.gbi_info[0].gbi_link * 1 ? '<div class="link link_'+ speed[$.DataMap.gbi_info[0].gbispeed] + duplex[$.DataMap.gbi_info[0].gbiduplex] +'"></div>' : '<div class="link none"></div>') +'</div>' +
//													'<div class="sub_title">SPF</div>' +
//												'</td>' +
												'<td >' + 
													'<div class="sub_title"></div>' +
													'<div></div>' +
												'</td>' +
												'<td colspan="2">' +
													'<div class="sub_title"></div>' +
													'<div>'+ ($.DataMap.statsList[0].linkstatus * 1 ? '<div class="link link_'+ speed[$.DataMap.statsList[0].speed] + duplex[$.DataMap.statsList[0].duplex] +'"></div>' : '<div class="link none"></div>') +'</div>' + 
												'</td>' +
												'<td>' +
													'<div>&nbsp;</div>' +
													'<div>'+ ($.DataMap.statsList[1].linkstatus * 1 ? '<div class="link link_'+ speed[$.DataMap.statsList[1].speed] + duplex[$.DataMap.statsList[1].duplex] +'"></div>' : '<div class="link none"></div>') +'</div>' +
												'</td>' +
												'<td>' +
													'<div>&nbsp;</div>' +
													'<div>'+ ($.DataMap.statsList[2].linkstatus * 1 ? '<div class="link link_'+ speed[$.DataMap.statsList[2].speed] + duplex[$.DataMap.statsList[2].duplex] +'"></div>' : '<div class="link none"></div>') +'</div>' +
												'</td>' +
												'<td>' +
													'<div>&nbsp;</div>' +
													'<div>'+ ($.DataMap.statsList[3].linkstatus * 1 ? '<div class="link link_'+ speed[$.DataMap.statsList[3].speed] + duplex[$.DataMap.statsList[3].duplex] +'"></div>' : '<div class="link none"></div>') +'</div>' + 
												'</td>' +
												'<td>' +
													'<div>&nbsp;</div>' +
													'<div>'+ ($.DataMap.statsList[5].linkstatus * 1 ? '<div class="link  wlan2"></div>' : '<div class="link wlan"></div>') +'</div>' + 
												'</td>' +
												'<td>' +
													'<div>&nbsp;</div>' +
													'<div>'+ ($.DataMap.statsList[4].linkstatus * 1 ? '<div class="link  wlan2"></div>' : '<div class="link wlan"></div>') +'</div>' + 
												'</td>' +
											  '</tr>' +
											  '<tr class="statistics_sub_head">' +
												'<td>' +
													'<div class="wrapper"><div>' +
//														'<span class="lbl_txt">'+ Language[$.Language]["misc"]["statistics"]["temp"] +'(C)</span>'+
//														'<span>'+ parseFloat($.DataMap.gbi_info[0].gbitemperature).toFixed(1) +'</span>'+
													'</div>' + 
													'<div>'+
//														'<span class="lbl_txt">Tx/Rx(dBm)</span>'+
//														'<span>'+ mw_convert_dBm($.DataMap.gbi_info[0].gbitx_power) + "/" + mw_convert_dBm($.DataMap.gbi_info[0].gbirx_power) +'</span>'+
//														'<span style="display: inline-block;">'+ $.DataMap.gbi_info[0].gbitx_power + "/" + $.DataMap.gbi_info[0].gbirx_power +'</span>'+
													'</div></div>' +
												'</td>' +
												'<td colspan="2">&nbsp;</td>' +
												'<td>&nbsp;</td>' +
												'<td>&nbsp;</td>' +
												'<td>&nbsp;</td>' +
												'<td>&nbsp;</td>' +
												'<td>&nbsp;</td>' +
											  '</tr>' +
										  '</thead>' +
										  '<tbody class="df_tbody">' +
											  '<tr class="odd">' +
												'<td>Tx PKT </td>' +
												'<td colspan="2">'+ $.DataMap.statsList[0].tx_packets +'</td>' +
												'<td>' + $.DataMap.statsList[1].tx_packets +'</td>' +
												'<td>'+ $.DataMap.statsList[2].tx_packets +'</td>' +
												'<td>'+ $.DataMap.statsList[3].tx_packets +'</td>' +
												'<td>'+ $.DataMap.statsList[5].tx_packets +'</td>' +
												'<td>'+ $.DataMap.statsList[4].tx_packets +'</td>' +
											  '</tr>' +
											  '<tr>' +
												'<td>Rx PKT </td>' +
												'<td colspan="2">'+ $.DataMap.statsList[0].rx_packets +'</td>' +
												'<td>' + $.DataMap.statsList[1].rx_packets +'</td>' +
												'<td>'+ $.DataMap.statsList[2].rx_packets +'</td>' +
												'<td>'+ $.DataMap.statsList[3].rx_packets +'</td>' +
												'<td>'+ $.DataMap.statsList[5].rx_packets +'</td>' +
												'<td>'+ $.DataMap.statsList[4].rx_packets +'</td>' +
											  '</tr>' +
											  '<tr class="odd">' +
												'<td>Tx Err </td>' +
												'<td colspan="2">'+ $.DataMap.statsList[0].tx_Err +'</td>' +
												'<td>' + $.DataMap.statsList[1].tx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[2].tx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[3].tx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[5].tx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[4].tx_Err +'</td>' +
											  '</tr>' +
											  '<tr>' +
												'<td>Rx Err </td>' +
												'<td colspan="2">'+ $.DataMap.statsList[0].rx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[1].rx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[2].rx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[3].rx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[5].rx_Err +'</td>' +
												'<td>'+ $.DataMap.statsList[4].rx_Err +'</td>' +
											  '</tr>' +
											  '<tr class="odd">' +
												'<td>Tx Drop </td>' +
												'<td colspan="2">'+ $.DataMap.statsList[0].tx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[1].tx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[2].tx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[3].tx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[5].tx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[4].tx_Drop +'</td>' +
											  '</tr>' +
											  '<tr>' +
												'<td>Rx Drop </td>' +
												'<td colspan="2">'+ $.DataMap.statsList[0].rx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[1].rx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[2].rx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[3].rx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[5].rx_Drop +'</td>' +
												'<td>'+ $.DataMap.statsList[4].rx_Drop +'</td>' +
											  '</tr>' +
											  '<tr class="odd">' +
												'<td>Tx KB </td>' +
												'<td colspan="2">'+ getnum($.DataMap.statsList[0].tx_bytes)+'</td>' +
												'<td>'+ getnum($.DataMap.statsList[1].tx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[2].tx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[3].tx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[5].tx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[4].tx_bytes) +'</td>' +
											  '</tr>' +
											  '<tr>' +
												'<td>Rx KB</td>' +
												'<td colspan="2">'+ getnum($.DataMap.statsList[0].rx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[1].rx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[2].rx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[3].rx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[5].rx_bytes) +'</td>' +
												'<td>'+ getnum($.DataMap.statsList[4].rx_bytes) +'</td>' +
											  '</tr>' +
										  '</tbody>' +
										  '<tbody class="df_tfoot">' +
											  '<tr>' +
												'<td><span class="legend">'+ Language[$.Language]["misc"]["statistics"]["link_legend"] +'</span></td>' +
												'<td colspan="7">' +
													'<ul>'+
														'<li><div><div class="link link_1000F"></div></div><div>1000F</div></li>' +
														'<li><div><div class="link link_100F"></div></div><div>100F</div></li>' +
														'<li><div><div class="link link_100H"></div></div><div>100H</div></li>' +
														'<li><div><div class="link link_10F"></div></div><div>10F</div></li>' +
														'<li><div><div class="link link_10H"></div></div><div>10H</div></li>' +
														'<li><div><div class="link none"></div></div><div>NONE</div></li>' +
													'</ul>'+
												'</td>' +
											  '</tr>' +
										  '</tbody>' +
										'</table>';
}

//(dBm)= 10lg(mw)
function mw_convert_dBm(value) {
   var dBW, dBm, W;
   W = parseFloat(value/10000000);
   if (isNaN(W)||(W<=0)) {
		return 0;
   }
   dBW = 10 * Math.log(W)/Math.log(10);
   dBm = dBW+30;
   return dBm.toFixed(2);
}
function getnum(num)
{
	num=num/1024
	num=num.toFixed(0)
	return num;
}
/*********************************wireless network******************************************/

function init_wireless_network(){
	if($.DataMap.wlan[0].wlanEnabled==1 && $.DataMap.wlan[6].wlanEnabled==1){
		var obj1 = {},obj2 = {};
	obj1.wlan_idx_num = $.DataMap.wl2g_idx;
	obj2.wlan_idx_num = $.DataMap.wl5g_idx;
	var data = {};
	data.wireless_network_list = [];
	$.lockWin($.CommonLan["wireless_scan"]);
	ajax_sendRequest("skk_survey",obj1,function(data1){
		for(var i in data1)
			data1[i].is_5g = 0;
		ajax_sendRequest("skk_survey",obj2,function(data2){
			for(var i in data2)
				data2[i].is_5g = 1;
			$.unlockWin();
			var tmpData = JQ.merge(data2,data1);
			for(var i=0; i < tmpData.length; i++){
				data.wireless_network_list[i] = {};
				data.wireless_network_list[i].index = i+1;
				data.wireless_network_list[i].wl_ss_ssid = Base64.decode(tmpData[i].wl_ss_ssid) + (tmpData[i].is_5g * 1 ? "<span class=\"tag\">5G</span>" : "");
				data.wireless_network_list[i].wl_ss_bssid = tmpData[i].wl_ss_bssid;
				data.wireless_network_list[i].wl_ss_channel = tmpData[i].wl_ss_channel;
				data.wireless_network_list[i].wl_ss_mode = tmpData[i].wl_ss_mode;
				data.wireless_network_list[i].wl_ss_secen = tmpData[i].wl_ss_secen == 0 ? Language[$.Language][$.CurrentModule]["wireless_network"]["not_encrypted"] : secen_map[tmpData[i].wl_ss_secen];
				data.wireless_network_list[i].wl_ss_sin = tmpData[i].wl_ss_sin;
				
			}
			data.wireless_network_list.sort(function (a, b) {
				var tmpa = parseInt(a.wl_ss_sin.split('%')[0],10);
				var tmpb = parseInt(b.wl_ss_sin.split('%')[0],10);
				return tmpa < tmpb ? 1 : -1;
			});
			setAppTagData(data);
		});
	});
	}else if($.DataMap.wlan[0].wlanEnabled==1 && $.DataMap.wlan[6].wlanEnabled==0){
		init_wireless_network5g();
	}else if($.DataMap.wlan[0].wlanEnabled==0 && $.DataMap.wlan[6].wlanEnabled==1){
		init_wireless_network2g();
	}
	
	
}
function init_wireless_network2g(){
	var obj1 = {};
	var data = {};
	data.wireless_network_list = [];
	$.lockWin($.CommonLan["wireless_scan"]);
	obj1.wlan_idx_num = $.DataMap.wl2g_idx;
	ajax_sendRequest("skk_survey",obj1,function(data1){
		for(var i in data1)
			data1[i].is_5g = 0;
			$.unlockWin();
			var tmpData = data1;
			for(var i=0; i < tmpData.length; i++){
				data.wireless_network_list[i] = {};
				data.wireless_network_list[i].index = i+1;
				data.wireless_network_list[i].wl_ss_ssid = Base64.decode(tmpData[i].wl_ss_ssid) + (tmpData[i].is_5g * 1 ? "<span class=\"tag\">5G</span>" : "");
				data.wireless_network_list[i].wl_ss_bssid = tmpData[i].wl_ss_bssid;
				data.wireless_network_list[i].wl_ss_channel = tmpData[i].wl_ss_channel;
				data.wireless_network_list[i].wl_ss_mode = tmpData[i].wl_ss_mode;
				data.wireless_network_list[i].wl_ss_secen = tmpData[i].wl_ss_secen == 0 ? Language[$.Language][$.CurrentModule]["wireless_network"]["not_encrypted"] : secen_map[tmpData[i].wl_ss_secen];
				data.wireless_network_list[i].wl_ss_sin = tmpData[i].wl_ss_sin;
				
			}
			data.wireless_network_list.sort(function (a, b) {
				var tmpa = parseInt(a.wl_ss_sin.split('%')[0],10);
				var tmpb = parseInt(b.wl_ss_sin.split('%')[0],10);
				return tmpa < tmpb ? 1 : -1;
			});
			setAppTagData(data);
		
	});
}
function init_wireless_network5g(){
	var obj2 = {};
	var data = {};
	data.wireless_network_list = [];
	$.lockWin($.CommonLan["wireless_scan"]);
	obj2.wlan_idx_num = $.DataMap.wl5g_idx;
	ajax_sendRequest("skk_survey",obj2,function(data1){
		for(var i in data1)
			data2[i].is_5g = 1;
			$.unlockWin();
			var tmpData = data2;
			for(var i=0; i < tmpData.length; i++){
				data.wireless_network_list[i] = {};
				data.wireless_network_list[i].index = i+1;
				data.wireless_network_list[i].wl_ss_ssid = Base64.decode(tmpData[i].wl_ss_ssid) + (tmpData[i].is_5g * 1 ? "<span class=\"tag\">5G</span>" : "");
				data.wireless_network_list[i].wl_ss_bssid = tmpData[i].wl_ss_bssid;
				data.wireless_network_list[i].wl_ss_channel = tmpData[i].wl_ss_channel;
				data.wireless_network_list[i].wl_ss_mode = tmpData[i].wl_ss_mode;
				data.wireless_network_list[i].wl_ss_secen = tmpData[i].wl_ss_secen == 0 ? Language[$.Language][$.CurrentModule]["wireless_network"]["not_encrypted"] : secen_map[tmpData[i].wl_ss_secen];
				data.wireless_network_list[i].wl_ss_sin = tmpData[i].wl_ss_sin;
				
			}
			data.wireless_network_list.sort(function (a, b) {
				var tmpa = parseInt(a.wl_ss_sin.split('%')[0],10);
				var tmpb = parseInt(b.wl_ss_sin.split('%')[0],10);
				return tmpa < tmpb ? 1 : -1;
			});
			setAppTagData(data);
		
	});
}
/*************************************** system log ***************************************/
function init_sys_log(){
	getAppData(function(){
		setAppTagData($.SPDataMap);
	});
}
function del_all_sys_log(){
	var obj = getSubmitData([0]);
	if(!confirm($.CommonLan["del_tip"])){ return; }
	setAppData('delete',obj);
}

//网络工具
var diag_timer = null;
var tools_cmd = '1';
function init_diagnostic(){
	setAppTagData($.DataMap);
	if(diag_timer!=null){window.clearInterval(diag_timer);}
	getTag(0,1).btn.entity.value=$.CommonLan["start"];
	getTag(0,1).btn.entity.onclick = function(){
		tools_cmd = (tools_cmd=='1')?'0':'1';
		var str = (tools_cmd=='1')?"start":"end";
		getTag(0,1).btn.entity.value=$.CommonLan[str];
		beginCheck(str);
	}
	var cont = new Element("DIV");
	cont.setClass("df_diag");
	getTag(0,3).append(cont); 
	getTag(0,3).cont = cont;
	getTag(0,3).entity.style.padding="0px 30px 15px";
	getTag(0,3).entity.style.width="680px";
	getTag(0,3).cont.entity.innerHTML="The Router is ready.";
}
function beginCheck(fl){
	if(!checkTag([0])){return;}
	if(diag_timer!=null){window.clearInterval(diag_timer);}
	if($.CommonLan[fl] == $.CommonLan["start"])
		$.CGI_MOUDLE = {tools_set:0};
	else
		$.CGI_MOUDLE = {tools_set:1};
	setAppData(null,[0],function(data){
		if($.CommonLan[fl] == $.CommonLan["start"]) return;
		diag_timer = window.setInterval(function(){
			if($.CurrentApp!="diagnostic"){
				window.clearInterval(diag_timer);
				return;
			}

			getAppData(function(data){
/* 				if (getTag(0,3).cont.entity.innerHTML == parse_diagnostic(data.result)) {
					window.clearInterval(diag_timer);
					getTag(0,1).btn.entity.value=$.CommonLan['end'];
				} */
				getTag(0,3).cont.entity.innerHTML = parse_diagnostic(data.result);
			});
		},500);
	})
}
function parse_diagnostic(data){
	JQ(".df_diag").scrollTop(JQ(".df_diag")[0].scrollHeight);
	var arr = data.split(';');
	var str = '';
	for(var i in arr){
		str += arr[i]+'<br>';
	}
	return str;
}
function setWPSDisable(bo){
	disableDom(getTag(0,1).btn,bo);
	disableDom(getTag(0,"hand_add_show").btn,bo);
	if(bo == true){
		getTag(0,1).btn.setClass("df_btn_disabled");
		getTag(0,"hand_add_show").btn.setClass("df_btn_disabled");
	}else{
		getTag(0,1).btn.setClass("df_btn");
		getTag(0,"hand_add_show").btn.setClass("df_btn");
	}
}

function get_wlan_band()
{
	return ($.CurrentApp.indexOf('5g') == -1)?
		parseInt($.DataMap.wl2g_idx):parseInt($.DataMap.wl5g_idx);
}

function init_wps_hand_add(tag){
	if(tag.panel[0].pin){return;}
	var pin = new DefaultInput(null,"text",'simple_text');
	pin.setID('new_pin');
	pin.entity.maxLength = '8';
	tag.panel[0].push(pin);
	tag.panel[0].pin = pin;
	getTag(1,0).panel[0].radio.checked();
}
function hand_add_show(){
	getPan(1).display = '1';
	$.Apps[$.CurrentApp].Pans[1].show(); 
}
function hand_add_hide(){
	$.Apps[$.CurrentApp].Pans[1].hide();
}
function add_link_pin(){
	var obj = new Object();
	obj.wps_set = "ap";
	if(getTag(1,0).data=='0'){
		if(!checkDom(getTag(1,0).panel[0].pin,"text_pin")){return;}
		obj.wps_mode = "pin";
		obj.pin_host = getTag(1,0).panel[0].pin.entity.value;
	}else
	{
	  obj.wps_mode = "pbc";
	}	
	obj.wl_idx = get_wlan_band();
	
	setAppData('add',obj,function(){
		$.Apps[$.CurrentApp].Pans[1].hide();
	});
}

//验证无线安全设置中的密钥
function check_keyvalue(tag,p){
	var val = tag.text.entity.value;
	var info = (p == 2) ?ch_info_2:ch_info;
	var ch = info.ch;
	var str = info.str.replace(/\(/g,"").replace(/\)/g,"");
	if(!val || val ==''){checkShow(tag.text,str);return false;}

	if(ch.split('-').length != 2){
		if(val.length != parseInt(ch,10) && val.indexOf('%26') =='-1'){
			checkShow(tag.text,str);
			return false;}
	}else{
		var a = parseInt(ch.split('-')[0],10);
		var b = parseInt(ch.split('-')[1],10);
		if(val.length < a || val.length > b){
			checkShow(tag.text,str);
			return false;}
	}
	if (info.type == 'hex' && !checkDom(tag.text,'text_hex',str)){return false;}
	return true;
}

function interface_mode_check(){
	var access_mode = getTag(0,0).data;
	var wireless_type = getTag(0,1).data;
	var band = $.DataMap.wlanBandMode;
	init_ap_scan();
	setTagDomAction(1,[0,1,2,3],null,'hide');
	setPanAction([1,2],'hide');
	if(access_mode == '0'){
		getTag(0,1).hide();
		setPanAction([1,2],'hide');
		setPanArr([1,2],'0');
		setTagDomAction(1,[0,1,2,3],null,'hide');
		setTagDomAction(2,[0,1,2,3,4,5],null,'hide');
		var lan = ($.ShowLan)?CUS.Lang_map[$.DeLanguage]:$.Language;
		var arr = eval("("+Language[lan].network.wan.type_options+")");
		if($.DataMap.chip_flag=='1'){change_conntype_options(arr);}
		getTag(3,'mac').text.entity.value = $.DataMap.wan[0].mac;
	}else if(access_mode == '2'){
		if (band == 3){
			getTag(0,1).show();
		}else{
			getTag(0,1).hide();
		}
		setPanArr([1,2],'1');
		setPanAction([1,2],'show');
		setTagDomAction(1,[0,1],null,'show');
			
//wifi_nums 0
	if($.DataMap.wifi_nums==0){
			var data=$.DataMap.wlan[parseInt($.DataMap.wl2g_idx)+5];
	}else{
		//		wireless_type的1是2.4g,0是5g
		if(parseInt(wireless_type) == 0){
			var data=$.DataMap.wlan[parseInt($.DataMap.wl5g_idx)+5];
		}else{
			var data=$.DataMap.wlan[parseInt($.DataMap.wl2g_idx)+5];
		}
	}
		
//		 var data= $.DataMap.wlan[((parseInt(wireless_type) == 0)?parseInt($.DataMap.wl2g_idx):parseInt($.DataMap.wl5g_idx))+5];
		setAppTagData(data);
		getTag(3,'mac').text.entity.value = data.wlanMacAddr;
		if(data.encrypt == 6) getTag(1,1).select.setData("4");
		if(data.wpaPskType == 3) getTag(2,1).panel[1].radio.setData("2");
		
		// these codes are funny, but for ie7 bug
		window.setTimeout(function(){
			change_wan_sec_mode(getTag(1,'encrypt'));
		},100);
	}
}

//控制无线加密中wan_set安全模式下tag的显示
function change_wan_sec_mode(tag){
	var val = (tag.data=='0')?'0':'1';
	getPan(2).display = val;
	setTagDomAction(2,[0,1,2,3,4,5],null,'hide');
	var opmode = getTag(0,0).data;
	tag.data += "";
	switch(tag.data){
		case '0':setPanAction([2],'hide');break;
		case '1':
			setPanAction([2],'show');
			setTagDomAction(2,[0,2,4],null,'show');
			break;
		default:
			setPanAction([2],'show');
			setTagDomAction(2,[1,3,5],null,'show');
			break;
	}

	var vas  = getTag(1,1).data;
	getPan(2).title.entity.innerHTML=sec_map[vas];
	$.exec(getTag(2,0).action);
}

function change_wan_connect_type(){
	$.Flag = '0';			// let Advanced always hide.
	var tag = getTag(3,0);
	var showArr={			//'1':'IPOE'
		'2':[1,2,8,9,10,14,15,18,19],				//pppoe	2
		'20':[8,12,18,19],							//dhcp
		'21':[5,6,7,8,9,18,19],					//static
		'22':[1,2,4,5,6,8,9,10,14,15,18,19],		//russia pppoe
		'3':[1,2,3,4,5,6,7,8,9,14,15],			//l2tp	3
		'4':[1,2,3,4,5,6,7,8,9,14,15,18,19],	//pptp	4
		'5':[16,17]
	};

	setTagDomAction(3,['1-19'],null,'hide');
	setTagDomAction(3,showArr[tag.select.entity.value],null,'show');

	var max = 1492;
	if ((typeof(mtu_mapping[tag.data])) != 'undefined')
		max = mtu_mapping[tag.data];
	var lan = ($.ShowLan)?CUS.Lang_map[$.DeLanguage]:$.Language;
	getTag(3,9).after.entity.innerHTML = SpanLang(Language[lan].network.wan.mtuSize_after,[max]);
	// set mtu
	var mtu_tmp = '';
	var w_v = $.DataMap.wan[0];
	switch (tag.data){
		case '2':case '22':mtu_tmp=w_v.pppMtu; break;
		case '3':mtu_tmp=w_v.l2tpMtu; break;
		case '4':mtu_tmp=w_v.pptpMtu; break;
		case '20':case '21':mtu_tmp=w_v.ipoeMtu; break;
		default: break;
	}
	getTag(3,'mtuSize').text.entity.value=mtu_tmp;

	show_wan_advance();
	if(tag.data == '3' || tag.data == '4' || tag.data == '22') $.exec(getTag(3,'dhcp').action);
	tag.after.entity.style.color = "red";
	(tag.data==5)?(tag.after.hide()):(tag.after.hide());
	if(tag.data==5) $.exec(getTag(3,'ipv6DsliteMode').action);
	var exfunc = getTag(3,'connType');
	$.exec(exfunc.action,exfunc);
	getTag(3,'dns1').after.entity.style.display=(tag.data=='21')?'none':'block';
	
	
	if(getTag(3,0).data==3 && getTag(3,4).data==1 || getTag(3,0).data==4  && getTag(3,4).data==1){
		setTagDomAction(3,[18],null,"show");
		getTag(3,'dns1').after.entity.style.display='none';
	}
	
}
function change_dslite_mode(){
	var tag = getTag(3,"ipv6DsliteMode");
	var connv6 = $.DataMap.wan[0].ipv6Type;
	if (connv6 == '24') {
		JQ('input[name="ipv6DsliteMode"]')[1].checked = true;
		JQ('input:radio[name=ipv6DsliteMode][value="0"]').prop('disabled', true);
		tag.data = '1';
	}
	var msg = (tag.data == '0')?$.CommonLan["dslite_auto_hint"]:$.CommonLan["dslite_manu_hint"];
	JQ('#v6op_div').html(msg);
	var flag = (tag.data == '0')?'hide':'show';
	setTagDomAction(3,[17],null,flag);
}
function init_ap_scan(){
	var idx = $.DataMap.wlan[get_wlan_band()];
	var tmptag = '';
	var set_ap_scan = function(tag){
		tag.entity.value=$.CommonLan['ap_get'];
		tag.entity.onclick = function(){
			Q_apr_scan();
		}
	};

	if ($.CurrentApp=="wan")
	{
		tmptag = getTag(1,0).btn;
		set_ap_scan(tmptag);
	} else {
		tmptag = getTag(0,4).btn;
		set_ap_scan(tmptag);
		tmptag = getTag(0,5).btn;
		set_ap_scan(tmptag);
	}
}

//network
function init_wan_set(){
	var connv6 = $.DataMap.wan[0].ipv6Type;
	var band = $.DataMap.wlanBandMode;
	init_apr_scan_tbl();
	if (band & 1) $.APCHANNEL.channel = $.DataMap.wlan[parseInt($.DataMap.wl2g_idx)+5].channel;
	if (band & 2) $.APCHANNEL.channel5g = $.DataMap.wlan[parseInt($.DataMap.wl5g_idx)+5].channel;

	var node = document.createElement("div");
	node.id = "v6op_div";
	node.className = "df_context_after";
	node.style.color = "red";
	node.style.float = "left";
	getTag(3,"ipv6DsliteMode").entity.appendChild(node);
//	getTag(3,"ipv6AftrAddr").prefixInfo.hide();
//	getTag(3,"ipv6AftrAddr").prefix.hide();

	setAppTagData($.DataMap.wan[0]);
	getTag(3,3).after.entity.style.display= 'none';
	init_ap_scan();
	init_mac_clone();
	$.exec(getTag(0,'opMode').action);
	$.exec(getTag(3,'type').action);
	var showv6 = false;
	if ($.DataMap.wan[0].ver == 3)
	{
		if (connv6 == '23' || connv6 == '24')
			showv6 = true;
	}
	if (showv6 == false) JQ('#type option[value=5]').remove();
	if (typeof($.DataMap.mapController) == 'string')	{
		JQ('#mode_panel').hide();
		setTagDomAction(0,[0,1],null,'hide');
	}
	

	if($.DataMap.config_name=="FIBRACK"){
		JQ("#type option[value='22']").css("display","none");
		
	}else{
		JQ("#type option[value='22']").css("display","inline-block");
	}
	
}

function check_idletime(tag){
	var t = JQ('#idleTime_t');
	var con = getTag(3,'type').select.entity.value;
	if((con != 20 && con != 21 && con != 5) && tag.data=='1'){
		if(!checkSingleText(t[0],'text_num')){return false;}
		if(t.val()<1 || t.val()>30){
			checkShow(t.text,$.CommonLan['time_err']);
			return false;
		}
	}
	return true;
}
function save_wan_set(){
	var obj = new Object();
	var val = getTag(3,'type').select.entity.value;
	var secmode = getTag(1,1).data;
	var band = $.DataMap.wlanBandMode;
	var chk_pdns = function(){
		if(getTag(3,'dns1').text.entity.value==''&&getTag(3,'dns2').text.entity.value==''){
			checkShow(getTag(3,'dns1').text,$.CommonLan['dns_null_err']);return false;
		}
		return true;
	}

	if(getTag(0,0).data == '2') {
		if(secmode =='1'){
			if(!check_keyvalue(getTag(2,4))){return;}
		}else if(secmode!='0'){
			if(!check_keyvalue(getTag(2,5))){return;}
		}
	}
	if(!checkTag([2,3])){return;}

	if(!check_idletime(getTag(3,'connType'),3)){return;}
	if(val=='21'){ //static
		var s_ip = getTag(3,'ipAddr').text.entity.value;
		var s_mask = getTag(3,'subMask').text.entity.value;
		var s_gw = getTag(3,'defGw').text.entity.value;
		if(!check_ip_mask(s_ip,s_mask,getTag(3,'ipAddr'))){return;}
		if(!check_ip_mask(s_gw,s_mask,getTag(3,'defGw'),s_ip)){return;}
		if(!chk_pdns()){return;}
	}else if(val=='3' && getTag(3,"dhcp").data == '1'){	//l2tp
		var s_ip = getTag(3,'ipAddr').text.entity.value;
		var s_mask = getTag(3,'subMask').text.entity.value;
		var s_gw = getTag(3,'defGw').text.entity.value;
		if(!check_ip_mask(s_ip,s_mask,getTag(3,'ipAddr'))){return;}
		if(!check_ip_mask(s_gw,s_mask,getTag(3,'defGw'),s_ip)){return;}
		if(getTag(3,0).data==3 && getTag(3,4).data==1 || getTag(3,0).data==4  && getTag(3,4).data==1){
			if(!chk_pdns()){return;}
		}
	}else if(val=='4' && getTag(3,"dhcp").data == '1'){	//pptp
		var s_ip = getTag(3,'ipAddr').text.entity.value;
		var s_mask = getTag(3,'subMask').text.entity.value;
		var s_gw = getTag(3,'defGw').text.entity.value;
		if(!check_ip_mask(s_ip,s_mask,getTag(3,'ipAddr'))){return;}
		if(!check_ip_mask(s_gw,s_mask,getTag(3,'defGw'),s_ip)){return;}
		if(getTag(3,0).data==3 && getTag(3,4).data==1 || getTag(3,0).data==4  && getTag(3,4).data==1){
			if(!chk_pdns()){return;}
		}
	}

	obj.id = '1';
	obj.ifIndex = (getTag(0,0).data == '2')?'8':'1';
	if (getTag(0,0).data == '2')
	{
		if (getTag(0,1).data == '1')
			obj.wl_idx = parseInt($.DataMap.wl2g_idx);
		else
			obj.wl_idx = parseInt($.DataMap.wl5g_idx);
		obj.wl_idx += 5;
		obj.wlanEnabled='1';
	} else {
		obj.wlanEnabled='0';
	}
	obj.wispWanId = (band == '3')?getTag(0,1).data:0;

	if(
		getTag(3,'dns1').text.entity.value==''&&
		getTag(3,'dns2').text.entity.value==''
	)
		obj.dnsMode = '0';
	else
		obj.dnsMode = '1';

	if($.Flag=='1' && val!='21' && val!='3' && val!='4') {
		obj.dnsMode = '0';
		obj.dns1 = "";
		obj.dns2 = "";
	}
	
	var mtuSize = getTag(3,'mtuSize').text.entity.value;
	switch (getTag(3,0).data){
		case '2':case '22':obj.pppMtu=mtuSize; break;
		case '3':obj.l2tpMtu=mtuSize; break;
		case '4':obj.pptpMtu=mtuSize; break;
		case '20':case '21':obj.ipoeMtu=mtuSize; break;
		default: break;
	}

	$.CGI_MOUDLE = obj;
	MOD = 'mod';
	if(getTag("mode","opMode").data == '0'){
		setAppData('save',[0,1,3,4]);
	}else{
		setAppData('save',[0,1,2,3,4]);
	}
}
function show_wan_advance(){
	var val = getTag(3,0).data;
	var hideArr={
		'2':[8,9,10,11,18,19],	//pppoe
		'20':[8,9,12,18,19],		//dhcp
		'21':[8,9],				//static
		'22':[8,9,10,11,18,19],	//russia pppoe
		'3':[8,9,18,19],			//l2tp
		'4':[8,9,13,18,19],		//pptp
		'5':null					//dslite
	};
	disableMacClone();
	if ($.Flag==1) {
		setTagDomAction(3,hideArr[val],null,'show'),$.Flag=0;
		if (val == 5) $.exec(getTag(3,'ipv6DsliteMode').action);
	} else
		setTagDomAction(3,hideArr[val],null,'hide'),$.Flag=1;

	getTag(3,8).btn_a.entity.style.display = (getTag(0,0).data == "2")?"none":'';
//	sh_dns_opt();
}
function change_second_in(){
//	sh_dns_opt();
	var tag = getTag(3,'dhcp');
	var ty = (tag.data==1&&tag.entity.style.display=='block')?'show':'hide';
	setTagDomAction(3,[5,6,7],null,ty);
	if (getTag(3,0).data == 22) setTagDomAction(3,[7],null,'hide');
	
	if(getTag(3,4).data==0){
		setTagDomAction(3,[18],null,"hide");
		getTag(3,'dns1').after.entity.style.display='block';
	}
	if(getTag(3,0).data==3 && getTag(3,4).data==1 || getTag(3,0).data==4  && getTag(3,4).data==1){
		setTagDomAction(3,[18],null,"show");
		getTag(3,'dns1').after.entity.style.display='none';
		
	}
	
	
}
/* SJ: for future dnsMode
function sh_dns_opt()
{
	var type = getTag(3,"type").select.entity.value;
	var mode = getTag(3,"dhcp").data;
	if ($.Flag=='0')
	{
		if (type == '3' || type == '4' || type == '22')
			getTag(3,'dns1').after.entity.style.display = (mode == '0')?'block':'none';
		if (type == '2' || type == '20')
			getTag(3,'dns1').after.entity.style.display ='block';
	}
} */

// lan
function init_lan_set(){
	getTag("set","lan_ip_set").btn.entity.style.width = "165px";
	setAppTagData($.DataMap);
	$.exec(getTag(1,'dhcpEnabled').action);
	$.exec(getTag(1,'lanAutoDns').action);
}
function dhcp_disable(){
	var flag = (getTag(1,0).data=='0')?true:false;
	disableDom(getTagDom(1,1,"text"),flag);
	disableDom(getTagDom(1,2,"text"),flag);
	disableDom(getTagDom(1,3,"text"),flag);
	if(flag) {
		getTag("servie","lanAutoDns").panel[0].radio.setData("0");
		$.exec(getTag(1,'lanAutoDns').action);
	}
	JQ("input[name='lanAutoDns']").prop('disabled',flag);
	lan_list_show();
}
function lan_list_show(){
	var show = getTag(2,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		//var start = (tab.page-1)*tab.size + i;
		//var data = tab.data[start];
		var data = show[i].data;
		show[i].entity.cells[3].innerHTML = break_row(data.host, 16);
		show[i].entity.cells[4].innerHTML = (data.type=='0')?$.CommonLan['dynamic']:$.CommonLan['reserved'];
	}
}
function save_lan_set(){
	var tag00 = getTag(0,0);
	if(!checkTag([0])){return;}
	if(!check_ip_mask(tag00.data,getTag(0,1).data,tag00)){return;}
	if(!check_lan_ip_in_range(getTag(0,0))){return;}
	var obj = getSubmitData([0]);
	JQ("#p_menu_misc").click();
	JQ("#c_menu_reboot").click();
	reboot('http://' + tag00.data,obj);
}

// reservation
function reserve_list_show()
{
	var show = getTag(1,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
	}
}
function init_reserve(){
	setAppTagData($.DataMap);
	reserve_list_show();
}
function add_reservation(tag){
	if(!checkTag([0])){return;}
	if(!check_lan_ip(getTag(0,1))){return;}
	if(!check_text_list(getTag(0,1),getTag(1,0))){return;}
	if(!check_text_list(getTag(0,2),getTag(1,0))){return;}
	
	var obj = new Object();
	tag.mode = MOD;
	obj = getSubmitData([0]);
	obj.id = MODData.id;
	
	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_reservation(row){
	getTag(0,3).btn.entity.value = $.CommonLan["mod"];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
}
function del_reservation(row){
	if(!confirm($.CommonLan["del_one_tip"])) return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.dhcpRsvdIpList='del';
	setAppData('delete',obj);
}
function del_all_reservation(){
	if(!confirm($.CommonLan["del_tip"])) return;
	setAppData('delete',[1]);
}
function disableMacClone()
{
	var state = (getTag(0,0).data == '2')?true:false;
	getTag("wan_set","mac").children[1].entity.disabled=state;
	getTag("wan_set","mac").children[2].entity.disabled=state;
	getTag("wan_set","mac").children[3].entity.disabled=state;
}
function init_mac_clone(){
	var btn_a = getTag(3,'mac').btn_a;
	btn_a.setValue($.CommonLan["clone_mac"]);
	btn_a.entity.onclick = function(){
		getTag(3,'mac').text.entity.value = $.DataMap.macClone;
	}
	var btn_b = getTag(3,'mac').btn_b;
	btn_b.setValue($.CommonLan["df_mac"]);
	btn_b.entity.onclick = function(){
		getTag(3,'mac').text.entity.value = $.DataMap.nic1Addr;//$.DataMap.mac_default;
	}
	disableMacClone();
}
//隐藏提示WPS已开启,请不要使用WEP加密 
function wep_tips(){
	var val = getTag(2,0).data;
	var p = ($.CurrentApp=='security'&&val=='4')?'4':'3';
	getTag(p,1).hide();
	if($.DataMap.wscEnabled=='1'){
		(getTag(p,0).data=='1')?getTag(p,1).show():getTag(p,1).hide();
	}
}

/**************************** wireless setting ***************************/
function init_wl_base(){
	var data = $.DataMap.wlan[get_wlan_band()];
	var opmode = $.DataMap.opMode;
	init_ap_scan();
	init_apr_scan_tbl();
	data.rp_ssid = $.DataMap.wlan[get_wlan_band()+5].ssid;

	if ((data.broadSSID == 1) && (data.wscEnabled == 1) && $.Language == "US")
	{
		var node = document.createElement("div");
		node.innerHTML=$.CommonLan["ssid_disable_hint"];
		node.className = "df_context_after";
		node.style.color = "red";
		node.style.float = "left";
		getTag(0,"broadSSID").entity.appendChild(node);
	}
	
	var rpt = 5;
	if ($.CurrentApp == "base"){
		if($.DataMap.wlanBandMode & 1) rpt+=parseInt($.DataMap.wl2g_idx);
	}else if ($.CurrentApp == "base5g"){
		if($.DataMap.wlanBandMode & 2) rpt+=parseInt($.DataMap.wl5g_idx);
	}
	for(var i in $.DataMap.wlan[rpt]){
		data["rp_"+i] = $.DataMap.wlan[rpt][i];
	}
	
	setAppTagData(data);
	if(opmode == '2'){
		getTag(0,2).data = '0';
		getTag(0,2).select.entity.options.length = 1;
	}

	var suffix = ($.CurrentApp == "base")? '':'5g';
	if(data.wlanMode != '0') {
		JQ('#c_menu_multiple_ssid'+suffix).hide();
		JQ('#c_menu_wl_mac_filter'+suffix).hide();
	} else {
		JQ('#c_menu_multiple_ssid'+suffix).show();
		JQ('#c_menu_wl_mac_filter'+suffix).show();
	}
	if(data.wlanMode == "1") getTag(3,0).show();
	if ($.DataMap.opMode == '0')
	{
		JQ('#wlanMode option[value=20]').remove();
		JQ('#wlanMode option[value=1]').remove();
	}
	if ($.DataMap.mapController == '1')	{
		JQ("#wlanBand").prop('disabled',true);
		JQ("input[name='broadSSID']").prop('disabled',true);
		JQ("#regDomain").prop('disabled',true);
		
		JQ("#encrypt").prop('disabled',true);
		JQ("input[name='wpaPskType']").prop('disabled',true);
	}
	
	$.exec(getTag(0,'wlanEnabled').action);
	if($.DataMap.config_name=="FIBRACK"){
		JQ("#regDomain option[value='12']").css("display","none")
	}else{
		JQ("#regDomain option[value='12']").css("display","inline-block")
	}
}

function change_base_display(){
	var data = $.DataMap.wlan[get_wlan_band()];
	if(getTag(0,0).data=="0"){
		setTagDomAction(0,['1-13'],null,'hide');
		wl_base_hide_all();
	}else{
		setTagDomAction(0,['1-13'],null,'show');
		$.exec(getTag(0,'wlanMode').action);
	}
}

function change_base_sel(){
	var band = $.DataMap.wlanBandMode;
	var tag = getTag(0,2);
	var showArr={
		'0':{tag:[1,2,3,4,6,7,8,9,10],pan:[1]},		//ap
		'1':{tag:[1,2,4,7],pan:[1]},					//client
		'20':{tag:[1,2,4,5,7],pan:[1,2]}					//repeater
	};
	wl_base_hide_all();
	setTagDomAction(0,['1-10'],null,'hide');
	setTagDomAction(0,showArr[tag.data].tag,null,'show');
	setPanAction(showArr[tag.data].pan,'show');

	var options = getTag(1,1).select.entity.options;
	var netMode = getTag(0,2).select.entity.value;

	if(netMode==1) JQ('#ssid').show();
	else JQ('#ssid').hide();

	if(netMode==0){
		if(options.length == 4) {
			var lan = ($.ShowLan)?CUS.Lang_map[$.DeLanguage]:$.Language;
			var encrypt = eval("("+Language[lan].wireless.base.encrypt_options+")");
			options.add(new Option(encrypt[4],6));
		}
		JQ('#wpaPskType_ta').show();
	}else {
		if(options.length == 5) options[4].remove();
		if(getTag(1,4).data == 3) getTag(1,4).panel[1].radio.setData("2");
		if(getTag(1,1).data == 6) getTag(1,1).select.setData("4");
		JQ('#wpaPskType_ta').hide();
	}

	$.exec(getTag(0,'wlanBand').action);
	$.exec(getTag(1,'encrypt').action);
	$.exec(getTag(2,'rp_encrypt').action);

	if($.DataMap.opMode == "2" && tag.data == "0"){
		if (band == 3)
		{
			if(($.DataMap.wispWanId == "1" && $.CurrentApp == "base") || 
			($.DataMap.wispWanId == "0" && $.CurrentApp == "base5g")){
				getTag(0,8).hide();
				getTag(0,9).hide();
				getTag(0,10).hide();
			}
		} else {
			if ($.CurrentApp == "base" || $.CurrentApp == "base5g"){
				getTag(0,8).hide();
				getTag(0,9).hide();
				getTag(0,10).hide();
			}
		}
	}
}

//控制无线加密中security,副ap安全模式下tag的显示
function change_wl_sec_modes(p){
	var suffix = ($.CurrentApp == 'base') ? '' : '5g';
	var pan = p == 'rp'?2:1;
	var showArr={
		'0':{ap:null},
		'1':{ap:[2,3,5,7]},
		'2':{ap:[4,6,8]},
		'4':{ap:[4,6,8]},
		'6':{ap:[4,6,8]}
	};
	
	var tag=getTag(pan,1);
	var tagArr=showArr[tag.select.entity.value].ap;
	setTagDomAction(pan,['0-8'],null,'hide');
	switch(tag.data){
		case '0':setTagDomAction(pan,['0-8'],null,'hide');break;
		case '1':setTagDomAction(pan,tagArr,null,'show');break;
		default:setTagDomAction(pan,tagArr,null,'show');break;
	}
	setTagDomAction(pan,[1],null,'show');
	$.exec(getTag(pan,3).action);
	getTag(pan,0).hide();//hide tips
}
function rp_change_wl_sec_modes() {
	change_wl_sec_modes('rp');
}

function change_wl_band(){
	var data = $.DataMap.wlan[get_wlan_band()];
	var mode = getTag(0,2).data;
	var val = getTag(0,3).data;
	
	if (mode==0 && (val & 8 || val & 64)) {
		setTagDomAction(0,[9,10],null,'show');
		if(val&64) {
			JQ('#channelWidth_80').show();
			if(data.channelWidth==2) 
				getTag(0,9).panel[2].radio.checked();
		}
		else {
			JQ('#channelWidth_80').hide();
			if(getTag(0,9).data==2) 
				getTag(0,9).panel[1].radio.checked();
		}
		(getTag(0,9).data=='0')?getTag(0,10).hide():getTag(0,10).show();
	}
	else {
		setTagDomAction(0,[9,10],null,'hide');
	}
	$.exec(getTag(0,'channel').action);
}

function change_wl_channel()
{
	var mode = getTag(0,2).data;
	var width = getTag(0,9).data;
	var bind = getTag(0,10).data;
	var region = getTag(0,7).data;
	var channel = getTag(0,8).data;
	var stand = getTag(0,3).data;
	var sel = getTag(0,8).select.entity;
	var arr = new Array();
	var band = $.CurrentApp=="base"? 0: 1;
	var offset_s = 0, offset_e = 0;

	if(width!=0)
	{
		if((mode == 0 || mode == 2 || mode == 3) && (stand & 8 || stand & 64))
			setTagDomAction(0,[10],null,'show');
		else
			setTagDomAction(0,[10],null,'hide');
		var offset = width * (($.CurrentApp=="base")?4:0);
		if (channel_map[band][region][0].length == 14) offset_e=1;
		(bind=='0')?offset_s+=offset:offset_e+=offset;
	}
	else
		setTagDomAction(0,[10],null,'hide');

	arr.push(0); //channel auto 
	for(var i=0;i<channel_map[band][region].length;i++)
	{
		for(var j=offset_s;j<channel_map[band][region][i].length-offset_e;j++)
		{
			ch = channel_map[band][region][i][j];
			if ($.CurrentApp == "base5g")
			{
				if (region == 16) {arr.push(ch); continue;}
				if (width == "1"){
					if(is40MCHannel(channel_map[band][region][i], channel_map[band][region][i].length, ch) == true){
						arr.push(ch);
					}
				} else if (width == "2"){
					if(is80MChannel(channel_map[band][region][i], channel_map[band][region][i].length, ch) == true){
						arr.push(ch);
					}
				} else {arr.push(ch);}
			} else {arr.push(ch);}
		}
	}

	var found = 0;
	sel.options.length = arr.length;
	for(var i=0;i<arr.length;i++){
		if(arr[i] == 0)
			var opt = new Option($.CommonLan['_auto'],arr[i]);
		else
			var opt = new Option($.CommonLan['_channel']+" "+arr[i],arr[i]);
		
		sel.options[i] = opt;
		
		if(channel == arr[i])
			found = 1;
	}

	if(found == 0)
		getTag(0,8).select.checked(arr[0]);
	else
		getTag(0,8).select.checked(channel);
}

function is40MCHannel(list, num, channel){
	var idx=-1,chNO,baseCH=0;
	if((channel >= CH_40m[CH_40m.length-1]) && ((CH_40m[CH_40m.length-1]+4) >= channel)){
		baseCH = CH_40m[CH_40m.length-1];
	}else{
		for(chNO=0; chNO<CH_40m.length-1;chNO++){
			if(CH_40m[chNO] <= channel && CH_40m[chNO+1] > channel){
				baseCH = CH_40m[chNO];
				break;
			}
		}
	}
	for(idx=0; idx<num; idx++){
		if(list[idx] == baseCH){
			break;
		}
	}
	if(idx == num || idx+1 >= num){
		return false;
	}
	if(list[idx+1] == baseCH+4){
		return true;
	}else{
		return false
	}
}
function is80MChannel(list, num, channel){
	var idx=-1,chNO,baseCH=0;
	if((channel >= CH_80m[CH_80m.length-1]) && ((CH_80m[CH_80m.length-1]+8) >= channel)){
		baseCH = CH_80m[CH_80m.length-1];
	}else{
		for(chNO=0; chNO<CH_80m.length-1;chNO++){
			if(CH_80m[chNO] <= channel && CH_80m[chNO+1] > channel){
				baseCH = CH_80m[chNO];
				break;
			}
		}
	}
	for(idx=0; idx<num; idx++){
		if(list[idx] == baseCH){
			break;
		}
	}
	if(idx == num || idx+3 >= num){
		return false;
	}
	if((list[idx+1] == (baseCH+4)) && 
		(list[idx+2] == (baseCH+8)) && 
		(list[idx+3] == (baseCH+12))){
		return true;
	}else{
		return false
	}
}

function save_wl_base(){
	if(!checkTag([0])){return;}
	$.CGI_MOUDLE = {wl_idx:get_wlan_band(), wscConfigured:1};

	var auth = parseInt(getTag(1,1).data,10);
	if(auth > 0){
		(auth == 1)?t=7:t=8;
		if(!check_keyvalue(getTag(1,t))){return;}
	}
	var netMode = getTag(0,2).select.entity.value;
	if(netMode==20){
		var auth = parseInt(getTag(2,1).data,10);
			if(auth > 0){
				(auth == 1)?t=7:t=8;
				if(!check_keyvalue(getTag(2,t),2)){return;}
			}
		}
	setAppData('save',[0,1,2,3]);
/* 	setAppData('save',[0,1,2,3],function(data){
		if(getTag(0,0).data=='1'){$.Refresh();}
	}); */
}

function wl_base_hide_all(){
	setTagDomAction(1,['0-8'],null,'hide');
	setPanAction([1,2,4],'hide');
}

function set_sec_mode(){
	var data = $.DataMap;
	var option = getTag(3,0).select.entity.options;
	if(data.wlanMode == "3" && data.net_type == "1"){
		for(var i=2;i<option.length;i++){
			option.remove(i);
		}
	}
}

function init_wl_link_list(){
	getAppData(function(data){
		var band = $.DataMap.wlanBandMode;
		var idx = 0;
		if (band == 3)
			idx = ($.DataMap.wlan[get_wlan_band()].phyBand==2)?0:1;
		var list = $.DataMap.wlanInfo[idx];
		setAppTagData(list);
	});
}
function init_wl_mac(){
	var list = $.DataMap.wlan[get_wlan_band()];
	setAppTagData(list);
	wl_mac_list_show()
}
function wl_mac_list_show(){
	var show = getTag(2,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
	}
}
function save_wl_mac_filter(){
	$.CGI_MOUDLE = {wl_idx:get_wlan_band()};
	setAppData('save',[0]);
}
function add_wl_mac(tag){
	if(!checkTag([1])){return;}

	var obj = new Object();
	tag.mode = MOD;
	obj = getSubmitData([1]);
	obj.id = MODData.id;

	$.CGI_MOUDLE = {wl_idx:get_wlan_band()};
	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_wl_mac(row){
	getTag(1,"acl").btn.entity.value = $.CommonLan["mod"];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
}
function del_wl_mac(row){
	if(!confirm($.CommonLan["del_one_tip"]))return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.acl = "del";
	$.CGI_MOUDLE = {wl_idx:get_wlan_band()};
	setAppData('delete',obj);
}
function del_wl_mac_filter_all(){
	if(!confirm($.CommonLan["del_tip"])) return;
	$.CGI_MOUDLE = {wl_idx:get_wlan_band()};
	setAppData('delete',[2]);
}
function init_wl_advance(){
	setAppTagData($.DataMap.wlan[get_wlan_band()]);
}
function save_wl_advance(){
	if(!checkTag([0])){return;}
	$.CGI_MOUDLE = {wl_idx:get_wlan_band()};
	setAppData('save',[0]);
}

/************************************* multiple_ssid *************************************/
function change_ap_select(tag){
	var val = tag.select.entity.value;
	var data = $.DataMap.wlan[get_wlan_band()+parseInt(val)];
	setAppTagData(data);
}
function init_wl_ap(){
	var data = $.DataMap.wlan[get_wlan_band()+1];
	setAppTagData(data);
	getTag(3,1).hide();
	$.exec(getTag(3,'encrypt').action);
}
function save_wl_ap(){
	if(!checkTag([1,3])){return;}
	var val = getTag(0,0).select.entity.value;
	$.CGI_MOUDLE = {wl_idx:get_wlan_band()+parseInt(val)};
	setAppData('save',[0,1,3]);
}
function mod_wl_ap(row){
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
}
function change_wl_sec_mode(){
	setTagDomAction(3,[1,2,3,4,5,6,7],null,'hide');
	switch(getTag(3,0).data){
		case '0':setTagDomAction(3,[1,2,3,4,5,6,7],null,'hide');break;
		case '1':setTagDomAction(3,[1,2,4,6],null,'show');break;
		default:setTagDomAction(3,[7],null,'show');break;
	}
	$.exec(getTag(2,0).action);
}
function change_lan_dns_mode(){
	setTagDomAction(1,[5,6],null,SHRadioAct(1,'lanAutoDns'));
}
function save_dhcp_server(){
	if(!checkTag([1])){return;}
	if(getTag(1,0).data=='2'){
		var data = $.DataMap;
		if(!check_ip_limit(getTag(1,1),getTag(1,2),'dhcp')){return;}
		if(check_ip_lanip(getTag(1,1).data,data.lanIpAddr) == 4 ||　check_ip_segment(getTag(1,1).data,data.lanIpAddr,data.lanSubMask) != 4){
			checkShow(getTagDom(1,1,'text'),$.CommonLan['ip_err']);
			return;
		}
		if(check_ip_lanip(getTag(1,2).data,data.lanIpAddr) == 4 || check_ip_segment(getTag(1,2).data,data.lanIpAddr,data.lanSubMask) != 4){
			checkShow(getTagDom(1,2,'text'),$.CommonLan['ip_err']);
			return;
		}
		if(check_ip_segment(getTag(1,1).data,getTag(1,2).data,data.lanSubMask) != 4){
			checkShow(getTagDom(1,2,'text'),$.CommonLan['ip_err']);
			return;
		}
		var dns1 = getTag(1, "lanDns1").text.entity.value;
		var dns2 = getTag(1, "lanDns2").text.entity.value;
		if((dns1 == '' || dns1 == dns2) && getTag(1,"lanAutoDns").data!='0'){
			checkShow(getTag(1, "lanDns1").text,$.CommonLan['dns_err']);
			return;
		}
	}
	setAppData('save',[1]);
}
// 0:Dynamic
// 1:Reserved
function keep_dhcp(row){
	if(row.data.type != '0'){
		alert( $.CommonLan['reserved_keep']);
		return;
	}
	var obj = new Object();
	obj.comment = Base64.encode(row.data.host);
	obj.macAddr = row.data.mac;
	obj.ipAddr = row.data.ip;
	obj.dhcpRsvdIpList = 'add';
	setAppData('add',obj);
}
function cancel_dhcp(row){
	if(row.data.type == '0'){
		alert($.CommonLan['reserved_cancel']);
		return;
	}

	var obj = new Object();
	obj.comment = Base64.encode(row.data.host);
	obj.macAddr = row.data.mac;
	obj.ipAddr = row.data.ip;
	obj.dhcpRsvdIpList = 'del';
	setAppData('delete',obj);
}
function dhcp_keep_all(){
	var obj = new Object();
	obj.dhcpRsvdIpList = 'keep_all';
	setAppData('save',obj);
}
function check_ip_segment(ip_a,ip_b,mask){
	var count_res=0;
	for(var i=0;i<ip_a.split('.').length;i++){
		var a = ip_a.split('.')[i];
		var b = ip_b.split('.')[i];
		var c = mask.split('.')[i];
		if((parseInt(a) & parseInt(c)) == (parseInt(b) & parseInt(c))){
			count_res++;
		}
	}
	return count_res;
}
function check_ip_lanip(ip,lanIP){
	var count_res=0;
	for(var i=0;i<ip.split('.').length;i++){
		var a = ip.split('.')[i];
		var b = lanIP.split('.')[i];
		if(a == b){
			count_res++;
		}
	}
	return count_res;
}
function check_lan_ip_segment(ip,mask){
	var count_res=0;
	var data = $.DataMap;
	var lanIpAddr = data.lanIpAddr;
	var lanSubMask = data.lanSubMask;
	for(var i=0;i<lanIpAddr.split('.').length;i++){
		var a = ip.split('.')[i];
		var b = mask.split('.')[i];
		var c = lanIpAddr.split('.')[i];
		var d = lanSubMask.split('.')[i];
		if((parseInt(a) & parseInt(b)) == (parseInt(c) & parseInt(d))){
			count_res++;
		}
	}
	return count_res;
}

//輸入text 使 slider 變動
function change_slider_val(tag)
{
  (function($) {
	$("#"+ tag.name + "_t").on("change", function() {
		jQuery("#" + tag.name + "_slider").slider({value:tag.data});
	})
  })(jQuery);
}

/********************************** virtual server *******************************/
function virtual_protocol_sel(tag){
	var i = getTagDom(0,2,"select").entity.selectedIndex;
	var map=[[" "," "," "],[" "," "," "],[" "," "," "],["80","80"," "],["443","443"," "],["21","21"," "],["110","110"," "],["25","25"," "],["53","53"," "],["23","23"," "],["500","500"," "],["1723","1723"," "],["3389","3389"," "],["9292","9292"," "],["1720","1720"," "],["22321","22321"," "]];
	getTagDom(0,3,"text_a").setValue(map[i][0]);
	getTagDom(0,3,"text_b").setValue(map[i][2]);
	getTagDom(0,4,"text_a").setValue(map[i][1]);
	getTagDom(0,4,"text_b").setValue(map[i][2]);
} 
function virtual_list_show()
{
	var show = getTag(1,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
		show[i].entity.cells[3].innerHTML = proto_map[data.proto];
	}
}
function init_virtual(){
	setAppTagData($.DataMap);
	virtual_list_show();
}
function save_virtual(tag){
	var data = $.DataMap;
	if(!checkTag([0])){return;}
	if(check_ip_lanip(getTag(0,1).data,data.lanIpAddr) == 4 ||　check_ip_segment(getTag(0,1).data,data.lanIpAddr,data.lanSubMask) != 4){
		checkShow(getTagDom(0,1,'text'),$.CommonLan['ip_err']);
		return;
	}
	if(!check_port_limit(getTag(0,3),null)){return;}
	if(!check_port_limit(getTag(0,4),null)){return;}
	if(!check_port_len(getTag(0,3),getTag(0,4))){return;}
	if(!check_vir_tab()){return;}

	var obj = new Object();
	tag.mode = MOD;
	obj = getSubmitData([0]);
	obj.id = MODData.id;

	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_virtual(row){
	getTag(0,5).btn.entity.value = $.CommonLan["mod"];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
}

function del_virtual_service(row){
	if(!confirm($.CommonLan["del_one_tip"])) return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.portFwList = "del";
	setAppData('delete',obj);
}
function del_virtual_all(){
	if(!confirm($.CommonLan["del_tip"])) return;
	setAppData('delete',[1]);
}

/********************************** DMZ *******************************/
function change_dmz_txt_state(){
	setTagDomAction(0,[1],null,SHRadioAct(0,0));
}
function save_dmz(){
	if(getTag(0,0).data=='1'){
		var data = $.DataMap;
		if(!checkTag([0])){return;}
		if(check_ip_lanip(getTag(0,1).data,data.lanIpAddr) == 4){
			checkShow(getTagDom(0,1,'text'),$.CommonLan['ip_err']);
			return;
		}
		if(check_ip_segment(getTag(0,1).data,data.lanIpAddr,data.lanSubMask) != 4){
			checkShow(getTagDom(0,1,'text'),$.CommonLan['ip_err']);
			return;
		}
	}
	setAppData('save',[0]);
}
function init_access(){
	var data = $.DataMap;
	setAppTagData(data);
}
function save_access(){
	if(!checkTag([0])){return;}
	MOD = "save";
	setAppData('save',[0]);
}
function save_access_ping(){
	if(!checkTag([1])){return;}
	MOD = "save";
	setAppData('save',[1]);
}

/************************************* IPTV settings *************************************/
function init_iptv_set(){
	setAppTagData($.DataMap);
	if($.SUPPORT_LAN_PORT == 1)
		JQ('#iptvPort option[value=1]').remove()
	
	if($.DataMap.opMode == "2"){
		getTag(0,0).select.entity.options.remove(2);
		getTag(0,0).select.entity.options.remove(1);
		getTag(0,0).select.entity.options.length = 1;
	}
	setTimeout(function(){
	if($.DataMap.opMode == "2"){
		getTag(0,0).select.entity.length = 1;
	}
	},100);
	if($.DataMap.switch_chipset=="8367D"){
		setTagDomAction(2,['3','5','7'],null,'hide');
	}else{
		setTagDomAction(2,['3','5','7'],null,'show');
	}
}
function change_iptv_mode(tag){
//	setTagDomAction(0,[1],null,'show');		//2019.08.19 after function finish, it shoult be enable. And remove iptv_mode display:"0" on config.js
	setTagDomAction(1,[0],null,'hide');
	setTagDomAction(2,['0-7'],null,'hide');
	setTagDomAction(3,['0-3'],null,'hide');
	setPanAction([1,2,3],'hide');
	if(tag.data==1){
		if($.DataMap.opMode != "2") {
			getPan(1).show();
			setTagDomAction(1,[0],null,'show');
		}
		setTagDomAction(0,[1],null,'hide');
	}else if(tag.data==2){
		if($.DataMap.opMode != "2") {
			setPanAction([2,3],'show');
			setTagDomAction(2,['0-7'],null,'show');
			if($.SUPPORT_LAN_PORT == 1)
				setTagDomAction(3,[0],null,'show');
			else if($.SUPPORT_LAN_PORT == 2)
				setTagDomAction(3,['0-1'],null,'show');
			else
				setTagDomAction(3,['0-3'],null,'show');
		}
		getTag(2, "iptv_vlan_id_tr069").hide();
	}
	if($.DataMap.switch_chipset=="8367D"){
		setTagDomAction(2,['3','5','7'],null,'hide');
	}else{
		setTagDomAction(2,['3','5','7'],null,'show');
	}
}
function save_iptv(){
	if(getTag(0,0).data=="2"){
		if(!checkTag([2])){return;}
	}
	var obj = getSubmitData([0,1,2,3,4]);
	setAppData('save',obj);
}
function save_upnp(){
	setAppData('save',[0]);
}

/************************************* opmode *************************************/
function change_op_mode(tag){
	setTagDomAction(0,['1-9'],null,'hide');
	if(tag.data==0) {
		setTagDomAction(0,[7,8],null,'show');
	} else {
		getTag(0,1).show();
		$.exec(getTag(0,'dhcpEnabled').action);
		if($.DataMap.opMode != "1"){
			getTag(0,"dns1").text.entity.value="";
			getTag(0,"dns2").text.entity.value="";
		}
	}
}
function deal_operation_mode(){
	setTagDomAction(0,['1-9'],null,'hide');
	if($.DataMap.opMode==1)
	{
		getTag(0,1).show();
		$.exec(getTag(0,'dhcpEnabled').action);
	}
	else
	{
		setTagDomAction(0,[7,8],null,'show');
	}
}
function init_opmode_set(){
	setAppTagData($.DataMap);
	if ($.DataMap.dhcpEnabled == 0)
		JQ('#dhcpEnabled').val(4);
	if ($.DataMap.dhcpEnabled == 2)
		JQ('#dhcpEnabled').val(6);
	deal_operation_mode();
}
function save_opmode(){
	var obj = getSubmitData([0]);

	if(getTag(0,"opMode").data==1)
	{
		if(!checkTag([0]))return;
		if(getTag(0,"dhcpEnabled").data==4)
		{
			var s_ip = getTag(0,'lanIpAddr').data;
			var s_mask = getTag(0,'lanSubMask').data;
			var s_gw = getTag(0,'lanDefGw').data;

			if(!check_ip_mask(s_ip,s_mask,getTag(0,'lanIpAddr'))){return;}
			if(!check_ip_mask(s_gw,s_mask,getTag(0,'lanDefGw'),s_ip)){return;}
			if(getTag(0,'lanDns1').text.entity.value==''){checkShow(getTag(0,'lanDns1').text,$.CommonLan['dns_null_err']);return;}
			
			if(getTag(0,'lanDns1').text.entity.value!='')
			{
				 if(!checkDom(getTag(0,"lanDns1").text,"text_dns")){return;}
			}
			if(getTag(0,'lanDns2').text.entity.value!='')
			{
				 if(!checkDom(getTag(0,"lanDns2").text,"text_dns")){return;}
			}
		}
		obj.type=0;
	}
	else
	{
		obj.dhcpEnabled=2;
//		obj.lanDns1 = "";
//		obj.lanDns2 = "";
		obj.dhcp=0;
		obj.type=1;
		obj.ctype=0;
	}

	obj.id = 1;
	obj.ifIndex=1;
	obj.wan='mod';
	var lanIpAddr = $.DataMap.lanIpAddr;
	if(!confirm($.CommonLan["reboot_tip"])) return;
	JQ("#p_menu_misc").click();
	JQ("#c_menu_reboot").click();
	reboot('http://' + lanIpAddr,obj);
}
function change_lan_dhcp_type()
{
	setTagDomAction(0,['2-9'],null,'hide');
	if(getTag(0,"dhcpEnabled").data==4)
		setTagDomAction(0,['2-6'],null,'show');
}
function change_modem_display()
{
	if(getTag(0,0).data == '0'){
		setTagDomAction(0,['1-9'],null,'hide');
	}else{
		setTagDomAction(0,['1-8'],null,'show');
		var exfunc = getTag(0,'usb3gConnType');
		$.exec(exfunc.action,exfunc);
	}
}
function change_g_auth_type()
{
	var tag = getTag(0,"usb3gAuthType");
	var flag = (tag.data == '3')?true:false;
	disableDom(getTagDom(0,'usb3gUsername',"text"),flag);
	disableDom(getTagDom(0,'usb3gPassword',"text"),flag);
}
function check_modem_time(tag,val){
	var t = JQ('#usb3gIdleTime_t');
	if (t.val() == '') return true;
	if(tag.data=='1'){
		if(!checkSingleText(t[0],'text_num')){return false;}
		if(t.val()<1 || t.val()>30){
			checkShow(t[0],$.CommonLan['time_err']);
			return false;
		}
	}
	return true;
}
function save_modem_set(){
	if(!checkTag([0])){return;}
	if(!check_modem_time(getTag(0,'usb3gConnType'),16)){return;}
	setAppData('save',[0]);
}

/****************************** ipv6 **************************/

/*** ipv6 status ***/
function init_status6(){
	if(sys_status_timev6!=null){
		window.clearInterval(sys_status_timev6);
	}
	//change_status_showv6($.DataMap);
	$.Apps['ipv6_status'].Pans['status_wan6'].hide();
	$.Apps['ipv6_status'].Pans['status_wanv6'].hide();
	get_sys_statusv6();
	sys_status_timev6 = window.setInterval(get_sys_statusv6,status_time);
}

var sys_status_timev6 = null;
function get_sys_statusv6(){
	if($.CurrentApp != "ipv6_status"){
		window.clearInterval(sys_status_timev6);
		return;
	}

	getAppData(function(data){
		if($.CurrentApp != "ipv6_status"){
			window.clearInterval(sys_status_timev6);
			return;
		}
		setAppTagData(data);
		if ($.SUPPORT_MULTI_WAN == 1)
			eth_wan_status_show6();
		else {
			$.Apps['ipv6_status'].Pans['status_wanv6'].show();
			if(data.wan[0].ver == 3){
				getTagDom(0,0,"context").html($.CommonLan[comm_map[data.wan[0].ipv6Type]]);
			}else{
				getTagDom(0,0,"context").html($.CommonLan['off']);
				getTag(1,"st_ipv6LanIpAddr").context.html("");
			}
			getTag('status_wanv6','connectedv6').btn.entity.onclick = function(){
				$.CGI_MOUDLE = {};
				var obj = new Object();
				var val = (data.connectedv6=='0')?'1':'0';
				obj.connectedv6 = val;
				var ct = (data.connectedv6=='0')?"connect_tip":"disconnect_tip";
				setAppData(null,obj);
			}
			if($.CurrentApp=='ipv6_status'){
				change_status_showv6(data);
				getTag('status_wanv6','connectedv6').btn.entity.value=(data.connectedv6=='0')? $.CommonLan['connect']:$.CommonLan['disconnect'];
			}
		}
	});
}

function eth_wan_status_show6(data){
	$.Apps['ipv6_status'].Pans['status_wan6'].show();
	var show = getTag(2,0).tab.tbody.Rows;
	var lan = ($.ShowLan)?CUS.Lang_map[$.DeLanguage]:$.Language;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		var gettag = show[i].entity.cells[0].innerHTML;
		var con = JQ('#'+ gettag).val();
		var arr = show[i].entity.cells[4].innerHTML.split('/');

		show[i].entity.cells[1].innerHTML = eval("("+Language[lan].network.eth_wan.type_options+")")[data.type];
		show[i].entity.cells[4].innerHTML = ((data.connected=='0')?$.CommonLan['down']:$.CommonLan['up'])+' '+arr[1];
		JQ('#'+ gettag).val(data.connected=='0'?$.CommonLan['connect']:$.CommonLan['disconnect']);
		JQ('#'+ gettag).show();
		JQ('#'+ gettag).on('click', function(){
			$.CGI_MOUDLE = {};
			var show = getTag(2,0).tab.tbody.Rows;
			var obj = new Object();
			obj.ifname = this.id;
			for(var i=0;i<show.length;i++){
				if (show[i].entity.cells[0].innerHTML == this.id)
					obj.connected = (show[i].data.connected=='0')?'1':'0';
			}
			setAppData(null,obj);
		});
	}
}

function change_status_showv6(data){
	var conntype = data.wan[0].ipv6Type;
//	var pd = data.wan[0].ipv6PdEnable;
	getTag(0,"connectedv6").btn.entity.value=(data.connectedv6=='0')? $.CommonLan['connect']:$.CommonLan['disconnect'];
	var val = (data.connectedv6 == "0")?$.CommonLan['disconnected']:$.CommonLan['connected'];
	getTagDom(0,"connectedv6","context").html(val);
	if ((conntype == '23' && data.wan[0].type == '3' && data.ipv6PppSession == '1') || conntype == '6' || conntype == '24')
		JQ('#connectedv6').hide();
	else
		JQ('#connectedv6').show();
//	var flag = (pd == '0')?'show':'hide';
//	setTagDomAction(1,[2],null,flag)
}
function init_lan6(){
	setAppTagData($.DataMap);
	change_ipv6_lan_dhcp();
}
function save_lan6_set(){
	if(!checkTag([0])){return;}
	if(parseInt(getTag(0,1).text.entity.value,16) > parseInt(getTag(0,2).text.entity.value,16)){
		checkShow(getTagDom(0,1,'text'),$.CommonLan['ip_err']);
		return;
	}
	
	setAppData('save',[0]);
}
/*** ipv6 config ***/
function init_ipv6_configure(){
	var connv4 = $.DataMap.wan[0].type;
	var connv6 = $.DataMap.wan[0].ipv6Type;
	JQ('#ipv6Type option[value=6]').remove();
	
	// ipv6_ppp_one_line
		if(connv4 == "2" && /*connv6 == "25" &&*/ (($.DataMap.wan[0].ifIndex & 0xf) == (($.DataMap.wan[0].ifIndex & 0xf0) >> 4)))
		$.DataMap.wan[0].ipv6PppSession = "1";
	else
		$.DataMap.wan[0].ipv6PppSession = "0";

	getTag(1,"ipv6WanDefGw").prefixInfo.hide();
	getTag(1,"ipv6WanDefGw").prefix.hide();
	getTag(1,"ipv6Dns1").prefixInfo.hide();
	getTag(1,"ipv6Dns1").prefix.hide();
	getTag(1,"ipv6Dns2").prefixInfo.hide();
	getTag(1,"ipv6Dns2").prefix.hide();

	var node = document.createElement("div");
	node.id = "v4op_div";
	node.className = "df_context_after";
	node.style.color = "red";
	node.style.float = "left";
	getTag(1,"ipv6rdOption").entity.appendChild(node);

	setAppTagData($.DataMap.wan[0]);
	setAppTagData($.DataMap);
	$.exec(getTag(0,'ver').action);
/* 	if (connv4 != '1' && connv4 !='20' && connv4 !='21')
		JQ('#ipv6Type option[value=6]').remove(); */
	var exfunc = getTag(1,"ipv6Type");
	$.exec(exfunc.action,exfunc);
	disableDom(getTag(1,"ipv6rdMaskLen").text,true);
	getTag(1,"ipv6rdMaskLen").text.setData($.DataMap.st_wanIpAddr);

	change_ipv6_delegation();
}

function show_pppoev6_tag(tag,flag){
	var ppp_doms = ['1-8'];
	setTagDomAction(1, ppp_doms, null, ((tag == "0")?'hide':'show'));
}
function change_ipv6_ppp_one_line(){
	var tag = getTag(1,"ipv6PppSession");
	var ppp_doms = ['2-8'];
	if(tag.data == "1"){
		setTagDomAction(1, ppp_doms, null, "hide");
	}else{
		setTagDomAction(1, ppp_doms, null, "show");
		var exfunc = getTag(1,'ipv6ConnType');
		$.exec(exfunc.action,exfunc);
	}
}
function change_conntype6(tag)
{
	var static_doms = [9,10];
	var rd_doms = ['13-16'];
	var pd_doms = [11,12];
	getTag(1,'ipv6Dns1').after.entity.style.display= 'none';
	
	/*
	if (tag.data < 23)
	{
		comb_wan_type();
		tag.data = $.DataMap.wan[0].ipv6Type;
	}
	*/

	switch(tag.data){
		case '23'://autoconfig
			setTagDomAction(1, static_doms, null, "hide");
			setTagDomAction(1, rd_doms, null, "hide");
			setTagDomAction(1, pd_doms, null, "show");
			getTag(1,"ipv6PdEnable").show();
			$.exec(getTag(1,'ipv6PdEnable').action);
			$.exec(getTag(1,'ipv6DnsAuto').action);
			show_pppoev6_tag("0");
			break;
		case '24'://static
			setTagDomAction(1, static_doms, null, "show");
			setTagDomAction(1, rd_doms, null, "hide");
			show_pppoev6_tag("0");
			getTag(1,"ipv6PdEnable").hide();
			getTag(1,"ipv6LanIpAddr").show();
			getTag(1,"ipv6DnsAuto").hide();
			getTag(1,"ipv6Dns1").show();
			getTag(1,"ipv6Dns2").show();
			getTag(1,"ipv6PdEnable").data = 1;
			getTag(1,'ipv6PdEnable').panel[getTag(1,'ipv6PdEnable').data].radio.checked();
//			getTag(2,"ipv6LanIpAddr").show();
			break;
		case '25'://pppoe
			setTagDomAction(1, static_doms, null, "hide");
			setTagDomAction(1, rd_doms, null, "hide");
			setTagDomAction(1, pd_doms, null, "hide");
			show_pppoev6_tag("1");
			getTag(1,"ipv6PdEnable").show();
			$.exec(getTag(1,'ipv6PdEnable').action);			
			$.exec(getTag(1,'ipv6DnsAuto').action);
			change_ipv6_ppp_one_line();
			if($.DataMap.wan[0].type != "2") getTag(1,1).hide();
			var exfunc = getTag(1,'ipv6ConnType');
			$.exec(exfunc.action,exfunc);
			break;
		case '6'://6rd
//			JQ('#'+getPan(2).name+'_panel').hide();
			setTagDomAction(1, static_doms, null, "hide");
			setTagDomAction(1, rd_doms, null, "show");
			setTagDomAction(1, pd_doms, null, "hide");
			show_pppoev6_tag("0");
			var exfunc = getTag(1,'ipv6rdOption');
			$.exec(exfunc.action,exfunc);
			$.exec(getTag(1,'ipv6DnsAuto').action);
			break;
	}
//	$.exec(getTag(2,'ipv6PdEnable').action);
}
function change_ipv6_enable()
{
	var tag = getTag(0,0);
	var flag = (tag.data == '3')?'show':'hide';
	setPanAction([1],flag);
}
function change_conn_methed(tag)
{
	var type = $.DataMap.wan[0].type;
	if ($.CurrentApp == 'wan' || $.CurrentApp == 'modem')
	{
		var p, t = tag;
		if (tag.name == 'connType') {p=3; t=15; type = getTag(3,'type').data;};
		if (tag.name == 'usb3gConnType') {p=0; t=9;}
	}
	if ($.CurrentApp == 'ipv6_configure') {var p = 1, t = 8;}
	if ($.CurrentApp == 'eth_wan') {var p = 2, t = 4; type = getTag(0,'type').data;}
	var flag = (tag.data == '1')?'show':'hide';
	if (type == '20' || type == '21' || type =='5') flag = 'hide';
	setTagDomAction(p,[t],null,flag);
}
function change_6rd_mode(tag){
	var connv4 = $.DataMap.wan[0].type;
	if (connv4 == '0') {
		JQ('input[name="ipv6rdOption"]')[0].checked = true;
		JQ('input:radio[name=ipv6rdOption][value="0"]').prop('disabled', true);
		tag.data = '1';
	}
	var msg = (tag.data == '0')?$.CommonLan["ipv6_6rd_auto_hint"]:$.CommonLan["ipv6_6rd_manu_hint"]
	JQ('#v4op_div').html(msg);
	setTagDomAction(1,['12-14'],null,SHRadioAct(1,'ipv6rdOption'));
}
function change_ipv6_dns_mode(){
	getTag(1,"ipv6DnsAuto").show();
	setTagDomAction(1,[18,19],null,SHRadioAct(1,'ipv6DnsAuto'));
}
function change_ipv6_delegation()
{
	var val = getTag('wanv6','ipv6PdEnable').data;
	setTagDomAction(1,[12],null,(val == '0')?'hide':'show');

}
function change_ipv6_lan_dhcp()
{
	var val = getTag('lan6_set','ipv6LanDhcp').data;
	if(JQ('#ipv6LanDhcp').is(":hidden"))val = '1';
	setTagDomAction(0,[1,2],null,(val != '2')?'hide':'show');
}
function save_ipv6()
{
	var connv6 = getTag(1,0).data;
	var def_param = function(){
		obj.id = 1;
		obj.ifIndex = 1;
		obj.wan = 'mod';

		if(connv6 == '24')
			obj.ipv6PdEnable = 1;
	}

	if(getTag(0,0).data == 1) {
		var obj = getSubmitData([0,0]);
		def_param();
		setAppData('save', obj);
		return;
	}

	if(!checkTag([1,2])){return;}
	var chk_dns = function(){
		var dns_primary = getTag(1, "ipv6Dns1").text.entity.value;
		var dns_secondary = getTag(1, "ipv6Dns2").text.entity.value;
		if(connv6 != '6')
		{
			if(dns_primary == '' || dns_primary == dns_secondary){
				checkShow(getTag(1, "ipv6Dns1").text,$.CommonLan['dns_err']);return false;
			}
		}
		return true;
	}
	if(connv6 == '23' || connv6 == '25')
	{
		if(getTag(1, "ipv6DnsAuto").data == 1)
			if(!chk_dns()){return;}
	} else if(connv6 == '24')
		if(!chk_dns()){return;}
	var obj = getSubmitData([0,1,2]);
	def_param();

	setAppData('save', obj);
}

/*** ipv6 filtering ***/
function init_ipv6_filter(){
	setAppTagData($.DataMap);
	$.exec(getTag(1,'host').action);
	$.exec(getTag(1,'proto').action);
	init_weekday();
	ipv6_filter_list_show();
}
function ipv6_filter_list_show(){
	var show = getTag(2,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
		show[i].entity.cells[2].innerHTML = rule_list_show(data.rule);
		show[i].entity.cells[3].innerHTML = ip6_list_show(data.host);
		show[i].entity.cells[4].innerHTML = proto_map[data.proto];
		if(data.proto==3 || data.proto==5){
			show[i].entity.cells[5].innerHTML=" ";
		}else{
			show[i].entity.cells[5].innerHTML=data.port;
		}
		show[i].entity.cells[6].innerHTML = dates_list_show(data.day);
		show[i].entity.cells[7].innerHTML = time_list_show(data.time);
	}
}
function save_ipv6_filter(){
	setAppData('save',[0]);
}
function change_ipv6_src_host(tag){
	var val = getTagDom(1,2,'select').entity.value;
	if(val == "0"){
		getTag(1,"host_ip6addr").hide();
	}else{
		getTag(1,"host_ip6addr").show();
	}
	
	if(val == "1"){
		getTag(1,"host_ip6addr").prefix.setValue(128);
		disableDom(getTag(1,"host_ip6addr").prefix,true);
	}else{
		disableDom(getTag(1,"host_ip6addr").prefix,false);
	}
}
function ipv6_disable_proto(){
	var val = getTagDom(1,'proto','select').entity.value;
	var flag=(val=='3'||val=='5')?true:false;
	disableDom(getTagDom(1,5,"text_a"),flag);
	disableDom(getTagDom(1,5,"text_b"),flag);
	getTagDom(1,5,"text_a").entity.value ="";
	getTagDom(1,5,"text_b").entity.value ="";
}
function add_ipv6_filter(tag){
	var obj = new Object();
	if(!checkTag([1])){return;}
	var sel = getTag(1,"proto").children[1].entity.value;
	if(!check_port_limit(getTag(1,5),sel)){return;}
	if(!week_null_check(getTag(1,'day'))){return;}
	if(getTag(1,7).chk_all.entity.checked ==false){
		if(!time_compare(1,7)){return;}
	}

	var obj = new Object();
	tag.mode = MOD;
	obj = getSubmitData([1]);
	obj.id = MODData.id;

	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_ipv6_filter(row){
	getTag(1,"ipv6FilterList").btn.entity.value = $.CommonLan["mod"];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
	$.exec(getTag(1,'host').action);
}
function del_ipv6_filter(row){
	if(!confirm($.CommonLan["del_one_tip"])) return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.ipv6FilterList = 'del';
	setAppData('delete',obj);
}
function del_ipv6_filter_all(){
	if(!confirm($.CommonLan["del_tip"])){return;}
	setAppData('delete',[2]);
}

/****************************** ipv6 end **************************/

/************************************** Remote Management *********************************/
function save_remote_port(){
	if(getTag(0,0).data=='1'){if(!checkTag([0])){return;}}
	getTag(0,1).data += "";
	if(getTag(0,1).data.indexOf(",")!=-1){
		checkShow(getTag(0,1).text,$.CommonLan['port_err']);
		return;
	}
	setAppData('save',[0]);
}

function disable_pro(){
	var val = getTagDom(1,4,'select').entity.value;
	var flag=(val=='0'||val=='3')?true:false;
	disableDom(getTagDom(1,5,"text_a"),flag);
	disableDom(getTagDom(1,5,"text_b"),flag);
	getTagDom(1,5,"text_a").entity.value ="";
	getTagDom(1,5,"text_b").entity.value ="";
}

//访问控制
function init_ip_filter(){
	setAppTagData($.DataMap);
	$.exec(getTag(1,'srcHost').action);
	$.exec(getTag(1,'destHost').action);
	$.exec(getTag(1,'proto').action);
	init_weekday();
	ip_filter_list_show();
}
function ip_filter_list_show(){
	var show = getTag(2,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
		show[i].entity.cells[2].innerHTML = rule_list_show(data.rule);
		show[i].entity.cells[3].innerHTML = ip_list_show(data.srcHost);
		show[i].entity.cells[4].innerHTML = ip_list_show(data.destHost);
		show[i].entity.cells[5].innerHTML = proto_map_ipv4[data.proto];
		show[i].entity.cells[7].innerHTML = dates_list_show(data.day);
		show[i].entity.cells[8].innerHTML = time_list_show(data.time);
	}
}
function ip_disable_pro(){
	var val = getTagDom(1,'proto','select').entity.value;
	var flag=(val=='3'||val=='4')?true:false;
	disableDom(getTagDom(1,'port',"text_a"),flag);
	disableDom(getTagDom(1,'port',"text_b"),flag);
	getTagDom(1,'port',"text_a").entity.value ="";
	getTagDom(1,'port',"text_b").entity.value ="";
}
function save_ip_filter(){
	setAppData('save',[0]);
}
function add_ip_filter(tag){
	if(!checkTag([1])) return;
	var sel = getTag(1,'proto').children[1].entity.value;
	if(sel=='1'||sel=='2'){
		var tag_a = getTagDom(1,'port',"text_a");
		var tag_b = getTagDom(1,'port',"text_b");
		if(!checkDom(tag_a,"text_port")){return;}
		if(!checkDom(tag_b,"text_port_null")){return;}
		if(!port_compare(getTag(1,'port'))){return;}
		if(tag_b.entity.value == ""){
			tag_b.entity.value = tag_a.entity.value;
		}
	}
	if(!week_null_check(getTag(1,'day'))){return;}
	if(getTag(1,'time').chk_all.entity.checked ==false){
		if(!time_compare(1,'time')){return;}
	}
	var host_s = getTagDom(1,'srcHost','select').entity.value;
	var host_d = getTagDom(1,'destHost','select').entity.value;
//	if(host_s=="2"){if(!check_ip_mask(getTag(1,'srcHost_sub_ip').text.entity.value,getTag(1,'srcHost_sub_mask').text.entity.value,getTag(1,'srcHost_sub_ip'))){return;}}
//	if(host_d=="2"){if(!check_ip_mask(getTag(1,'destHost_sub_ip').text.entity.value,getTag(1,'destHost_sub_mask').text.entity.value,getTag(1,'destHost_sub_ip'))){return;}}
	if(host_s=="3"){if(!check_ip_limit(getTag(1,'srcHost_ip_start'),getTag(1,'srcHost_ip_end'))){return;}}
	if(host_d=="3"){if(!check_ip_limit(getTag(1,'destHost_ip_start'),getTag(1,'destHost_ip_end'))){return;}}
	
	var obj = new Object();
	tag.mode = MOD;
	obj = getSubmitData([1]);
	obj.id = MODData.id;

	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_ip_filter(row){
	getTag(1,"ipFilterList").btn.entity.value = $.CommonLan["mod"];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
	$.exec(getTag(1,'srcHost').action);
	$.exec(getTag(1,'destHost').action);
}
function del_ip_filter(row){
	if(!confirm($.CommonLan["del_one_tip"]))return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.ipFilterList = 'del';
	setAppData('delete',obj);
}
function del_ip_filter_all(){
	if(!confirm($.CommonLan["del_tip"])) return;
	setAppData('delete',[2]);
}
function change_ip_src_host(){
	var val = getTagDom(1,'srcHost','select').entity.value;
	setTagDomAction(1,[3,4,5,6,7,8],null,'hide');
	if(val=='1'){
		setTagDomAction(1,[3,4],null,'show');
		var dom = getTagDom(1,'srcHost_mask','text');
		disableDom(dom,false);
		if(MOD!='mod'){dom.setValue(" ");}
		disableDom(dom,true);
		dom.setValue("255.255.255.255");
	}
	else if(val=='2'){
		setTagDomAction(1,[5,6],null,'show');
	}
	else if(val=='3'){
		setTagDomAction(1,[7,8],null,'show');
	}
}
function change_ip_dest_host(){
	var val = getTagDom(1,'destHost','select').entity.value;
	setTagDomAction(1,[10,11,12,13,14,15],null,'hide');
	if(val=='1'){
		setTagDomAction(1,[10,11],null,'show');
		var dom = getTagDom(1,'destHost_mask','text');
		disableDom(dom,false);
		if(MOD!='mod'){dom.setValue(" ");}
		disableDom(dom,true);
		dom.setValue("255.255.255.255");
	}
	else if(val=='2'){
		setTagDomAction(1,[12,13],null,'show');
	}
	else if(val=='3'){
		setTagDomAction(1,[14,15],null,'show');
	}
}
//MAC 过滤
function init_mac_filter(){
	setAppTagData($.DataMap);
	init_weekday();
	mac_filter_list_show();
}
function mac_filter_list_show(){
	var show = getTag(2,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
		show[i].entity.cells[2].innerHTML = rule_list_show(data.rule);
		show[i].entity.cells[4].innerHTML = dates_list_show(data.day);
		show[i].entity.cells[5].innerHTML = time_list_show(data.time);
	}
}
function save_mac_filter(){
	setAppData('save',[0]);
}
function add_mac_filter(tag){
	if(!checkTag([1])) return;
	if(!week_null_check(getTag(1,'day'))){return;}
	if(getTag(1,'time').chk_all.entity.checked ==false){
		if(!time_compare(1,'time')){return;}
	}

	tag.mode = MOD;
	var obj = new Object();
	obj = getSubmitData([1]);
	obj.id = MODData.id;

	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_mac_filter(row){
	getTag(1,"macFilterList").btn.entity.value = $.CommonLan["mod"];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
}
function del_mac_filter(row){
	if(!confirm($.CommonLan["del_one_tip"])) return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.macFilterList = 'del';
	setAppData('delete',obj);
}
function del_mac_filter_all(){
	if(!confirm($.CommonLan["del_tip"])) return;
	setAppData('delete',[2]);
}
function init_dns_filter(){
	setAppTagData($.DataMap);
	init_weekday();
	dns_filter_list_show();
}
function dns_filter_list_show(){
	var show = getTag(2,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
		show[i].entity.cells[2].innerHTML = rule_list_show(data.rule);
		show[i].entity.cells[3].innerHTML = htmlstr(data.url);
		show[i].entity.cells[4].innerHTML = dates_list_show(data.day);
		show[i].entity.cells[5].innerHTML = time_list_show(data.time);
	}
}
function save_dns_filter(){
	setAppData('save',[0]);
}
function add_dns_filter(tag){
	if(!checkTag([1])){return;}
	if(!week_null_check(getTag(1,'day'))){return;}
	if(getTag(1,'time').chk_all.entity.checked ==false){
		if(!time_compare(1,'time')){return;}
	}

	tag.mode = MOD;
	var obj = new Object();
	obj = getSubmitData([1]);
	obj.id = MODData.id;
	
	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_dns_filter(row){
	getTag(1,"urlFilterList").btn.entity.value = $.CommonLan["mod"];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
}
function del_dns_filter(row){
	if(!confirm($.CommonLan["del_one_tip"])) return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.urlFilterList='del';
	setAppData('delete',obj);
}
function del_dns_filter_all(){
	if(!confirm($.CommonLan["del_tip"])) return;
	setAppData('delete',[2]);
}
/*************************************** IGMP ***************************************/
function init_igmp(){
	if($.DataMap.iptvMode != "0"){
		$.DataMap.igmpSnoopEnabled = "1";
		getTag("igmp_snooping", "igmpSnoopEnabled").panel[1].hide();
	}
	setAppTagData($.DataMap);
}
function save_igmp(){
	setAppData('save',[0]);
}
function save_igmp_snooping(){
	setAppData('save',[1]);
}
function save_vpn(){
	setAppData('save',[0]);
}
function save_wakeup(){
	if(!checkTag([0])){return;}
	setAppData('save',[0]);
}

/************************************* ARP List *************************************/
var arp_timer = null;
function init_arp_list(){
	if(arp_timer!=null){window.clearInterval(arp_timer);}
	setAppTagData($.DataMap);
	arp_timer = window.setInterval(function(data){
		if($.CurrentApp != "arp_list"){
			window.clearInterval(arp_timer);
			return;
		}else{
			getAppData(function(data){
				setAppTagData($.DataMap);
			});
		}
	},1000);
}
function refresh_arp_list(){
	init_arp_list();
}

/************************************* routing *************************************/
function init_routing(){
	setAppTagData($.DataMap);
	static_routing_list_show();
}
function static_routing_list_show(){
	var show = getTag(1,0).tab.tbody.Rows;
	var lan = ($.ShowLan)?CUS.Lang_map[$.DeLanguage]:$.Language;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
		show[i].entity.cells[2].innerHTML = 
			eval("("+Language[lan].advanceSetup.routing.type_options+")")[show[i].data.type];
	}
}
function set_routing_type(tag){
	var dom = getTagDom(0,3,"text");
	if(tag.select.entity.selectedIndex == "0"){
		disableDom(dom,false);
		dom.setValue('');
	}else{
		disableDom(dom,true);
		dom.setValue('255.255.255.255');
	}
}

function save_routing(tag){
	if(!checkTag([0])){return;}
	
	tag.mode = MOD;
	var obj = new Object();
	obj = getSubmitData([0]);
	obj.id = MODData.id;
	
	if(obj.type == '1')
		obj.netmask = "255.255.255.255";
	
	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_routing(row){
	getTag(0,'staticRouteList').btn.entity.value = $.CommonLan['mod'];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
}
function del_routing(row){
	if(!confirm($.CommonLan["del_one_tip"]))return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.staticRouteList = 'del';
	setAppData('delete',obj);
}
function del_routing_all(){
	if(!confirm($.CommonLan["del_tip"])) return;
	setAppData('delete',[1]);
}
function init_routing6(){
	getTag(0,"nexthop").prefixInfo.hide();
	getTag(0,"nexthop").prefix.hide();
	setAppTagData($.DataMap);
}
function save_routing6(tag){
	if(!checkTag([0])){return;}

	tag.mode = MOD;
	var obj = new Object();
	obj = getSubmitData([0]);
	obj.id = MODData.id;
	
	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_routing6(row){
	getTag(0,'ipv6StaticRouteList').btn.entity.value = $.CommonLan['save'];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
	SetCancelBtn(getTag(0,3),'1');
}
function del_routing6(row){
	if(!confirm($.CommonLan["del_one_tip"]))return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.ipv6StaticRouteList = 'del';
	setAppData('delete',obj);
}
function del_routing6_all(){
	if(!confirm($.CommonLan["del_tip"])) return;
	setAppData('delete',[1]);
}
function save_mld_proxy(){
	setAppData('save',[0]);
}
/************************************* interface mode *************************************/
function init_interface_mode(){
	setAppTagData($.DataMap);
	if($.SUPPORT_LAN_1G != 1)
		JQ('#wanPortMode option[value=5]').remove();
}
function save_interface_mode(){
	setAppData('save',[0]);
}
/********************************** SNMP *******************************/
function change_snmp_display(){
	setTagDomAction(0,['1-8'],null,SHRadioAct(0,0));
}
function save_snmp(){
	if(!checkTag([0])){return;}
	setAppData('save',[0]);
}

function init_remoteacc(){
	setAppTagData($.DataMap);
	var tagsArr = $.Apps[$.CurrentApp].Pans[0].tags;
	for (var i in tagsArr){
		if (i == tagsArr.length-1) continue;
		let name = tagsArr[i].name;
		if(JQ('#'+name+'_t').val() == 0){
			JQ('#pan_'+name).hide();
			JQ('#'+name+'_t').hide();
		}
	}
	JQ('#lan_PING').prop('disabled', true);
	JQ('#lan_HTTP').prop('disabled', true);
	JQ('#lan_HTTPS').prop('disabled', true);
}
function save_remoteacc(){
	if(!checkTag([0])){return;}
	var obj = new Object();
	obj = getSubmitData([0]);
	obj["remote_set"] = 1;
	setAppData('save',obj);
}

/************************************* QOS *************************************/
function init_qos(){
	var data = $.DataMap;
	setAppTagData(data);
	$.exec(getTag(0,'qosEnabled').action);
	$.exec(getTag(1,'host').action);
	qos_list_show();
	JQ('#qosSpeed_start').val(data.qosSpeed_up);
	JQ('#qosSpeed_end').val(data.qosSpeed_down);
	getTag(0,1).entity.style.height="75px";
	getTag(0,1).label.entity.style.height='75px';
}
function change_qos_state(){
	var flag = (getTag(0,0).data=='0')?true:false;
	JQ('#'+getTag(0,1).name+'_start').prop('disabled',flag);
	JQ('#'+getTag(0,1).name+'_end').prop('disabled',flag);
}
function qos_list_show(){
	var show = getTag(2,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
		show[i].entity.cells[2].innerHTML = ip_list_show(data.host);
	}
}
function save_qos_conf(){
	if(!checkTag([0])){return;}
	if(!checkDom(getTagDom(0,1,"text_a"),"text_qos_band")){return;}
	if(!checkDom(getTagDom(0,1,"text_b"),"text_qos_band")){return;}
	setAppData('save',[0]);
}
function add_qos_rule(tag){
	if(!checkTag([1])){return;}
	if(!checkDom(getTagDom(1,8,"text_a"),"text_qos_band")){return;}
	if(!checkDom(getTagDom(1,8,"text_b"),"text_qos_band")){return;}
	if(!checkDom(getTagDom(1,9,"text_a"),"text_qos_band")){return;}
	if(!checkDom(getTagDom(1,9,"text_b"),"text_qos_band")){return;}
	if(getTagDom(1,9,"text_a").entity.value !="0"){
	if(parseInt(getTagDom(1,8,"text_a").entity.value,10)>parseInt(getTagDom(1,9,"text_a").entity.value,10)){
		checkShow(getTagDom(1,9,"text_a"),$.CommonLan['qos_up_err']);return;
	}}
	if(getTagDom(1,9,"text_b").entity.value !="0"){
	if(parseInt(getTagDom(1,8,"text_b").entity.value,10)>parseInt(getTagDom(1,9,"text_b").entity.value,10)){
		checkShow(getTagDom(1,9,"text_b"),$.CommonLan['qos_down_err']);return;
	}}
	
	var host = getTagDom(1,'host','select').entity.value;
	if(host=="3"){if(!check_ip_limit(getTag(1,'host_ip_start'),getTag(1,'host_ip_end'))){return;}}
	
	tag.mode = MOD;
	var obj = new Object();
	obj = getSubmitData([1]);
	obj.id = MODData.id;
	
	setAppData('add',obj,function(){tag.mode = "add";});
}
function mod_qos_rule(row){
	getTag(1,10).btn.entity.value = $.CommonLan["mod"];
	MOD = "mod";
	setModify(row.data);
	$.exec(getTag(1,'host').action);
	MODData = row.data;
}
function del_qos_rule(row){
	if(!confirm($.CommonLan["del_one_tip"])) return;
	MOD = "del";
	var obj = new Object();
	obj2obj(obj,row.data);
	obj.qosList = "del";
	setAppData('delete',obj);
}

function del_qos_rule_all(){
	if(!confirm($.CommonLan["del_tip"])){return;}
	setAppData('delete',[2]);
}

function change_qos_host(){
	var val = getTagDom(1,'host','select').entity.value;
	setTagDomAction(1,[2,3,4,5,6,7],null,'hide');
	if(val=='1'){
		setTagDomAction(1,[2,3],null,'show');
		var dom = getTagDom(1,'host_mask','text');
		disableDom(dom,false);
		if(MOD!='mod'){dom.setValue(" ");}
		disableDom(dom,true);
		dom.setValue("255.255.255.255");
	}
	else if(val=='2'){
		setTagDomAction(1,[4,5],null,'show');
	}
	else if(val=='3'){
		setTagDomAction(1,[6,7],null,'show');
	}
}
/************************************** DDNS ***************************************/
var sys_ddns_time = null;
var url_map={
	"DynDNS":"<a target='_blank' href='http://www.dyndns.com'>Go to register...</a>",
	"no-ip":"<a target='_blank' href='http://www.noip.com/'>Go to register...</a>"
};
function init_ddns(){
	refresh_ddns();
	reload_ddns();
}
function change_ddns_display(){
	if(getTag(0,0).data == '0'){
		setTagDomAction(0,[1,2,3,4,5],null,'hide');
	}else{
		setTagDomAction(0,[1,2,3,4,5],null,'show');
	}
}
function change_ddns_after(){
	if(getTag(0,1).data == "0"){
		getTagDom(0,1,'after').html(url_map["DynDNS"]);
	}else if(getTag(0,1).data == "5"){
		getTagDom(0,1,'after').html(url_map["no-ip"]);
	}
}
function load_ddns(){
	getAppData(function(data){setDDNSInfo(data);},true);
}
function setDDNSInfo(data){
	var info = getTagDom(0,5,"context");
	info.html($.CommonLan[data.ddnsInfo]);
}
function reload_ddns(){
	if(sys_ddns_time != null){
		window.clearInterval(sys_ddns_time);
	}
	sys_ddns_time = window.setInterval(function(){
		if(sys_ddns_time != "save") {
			if($.CurrentApp == "ddns"){
				load_ddns();
			}else{
				window.clearInterval(sys_ddns_time);
			}
		}
	},5000);
}
function save_ddns(){
	if(!checkTag([0])){return;}
	window.clearInterval(sys_ddns_time);
	sys_ddns_time = "save";
	setAppData('save',[0]);
}
function refresh_ddns(){
	getAppData(function(data){
		setAppTagData($.DataMap);
		$.exec(getTag(0,'ddnsEnabled').action);
		setDDNSInfo($.DataMap);
	});
}

//misc
file_form = null;
file_val=null;
function init_update(){
	
	setAppTagData($.DataMap);
	getPan(2).hide();
	getTagDom(0,0,"label").entity.style.height = "25px";
	getTagDom(0,0,"context").entity.style.height = "25px";
	getTagDom(0,0,"label").entity.style.lineHeight = "25px";
	getTagDom(0,0,"context").entity.style.height = "25px";
	getTagDom(0,1,"file").setAttr({
		"allowtransparency":"yes",
		"width":"460px",
		"height":"25px",
		"scrolling":"no",
		"border":"0",
		"id":"update_frame",
		"src":"./update.htm"
	});
	getTag(0,2).text.entity.style.width="250px";
	disableDom(getTag(0,2).text,true);
	getTagDom(0,1,"file").entity.setAttribute("frameborder","0",0);
	getTag(0,2).btn.entity.value=$.CommonLan['browse'];
	getTag(0,2).btn.entity.onclick = function(){ 
		file_form.update.click();
		file_form.update.onchange =function(){ 
			getTag(0,2).text.entity.value = file_form.update.value;
		}
		getTag(0,2).text.entity.value = file_form.update.value;
	}

	setAppTagData($.DataMap);
	if($.DataMap.autoUpdate){
		getTag(1, 1).btn_b.hide();
	if($.DataMap.new_ver){
		getTag(1, 1).btn_b.entity.style.display = "";
		getTag(1, 1).context.entity.innerText = $.DataMap.new_ver;
	}
	getTagDom(1, 1, "label").entity.style.height = "25px";
	getTagDom(1, 1, "context").entity.style.height = "25px";
	getTagDom(1, 1, "label").entity.style.lineHeight = "25px";
	getTagDom(1, 1, "context").entity.style.height = "25px";
	getTag(1, 1).context.entity.style.width = '240px'
	getTag(1, 1).btn.entity.value = $.CommonLan['detect_fw_ver'];
	getTag(1, 1).btn_b.entity.value = $.CommonLan['update_fw'];

	getTag(1, 1).btn.entity.onclick = function () {
		var r_t = 60;
		$.lockWin($.CommonLan['autoDetectfw_tip'], 'autoFW', r_t);
		var obj = new Object();
		obj.update_act = "0";
		obj.wl_link = "0";
		setTimeout(function () {
		autofw_detect(obj, r_t);
		}, 500);
	}

	getTag(1, 1).btn_b.entity.onclick = function () {
		var r_t = 180;
		$.lockWin($.CommonLan['autoLoad_tip'], 'autoFW', r_t);
		var obj = new Object();
		obj.update_act = "1";
		obj.wl_link = "0";
		setTimeout(function () {
		autofw_upgrade(obj, r_t);
		}, 500);
	}
	}
	else getPan(1).hide();
	
	if($.DataMap.config_name=="GEORGIA"){
		JQ("#c_menu_wireless_network").show();
		
			}else{
		JQ("#c_menu_wireless_network").hide();
		
	}
//	如果为土耳其就隐藏自动升级
	if($.DataMap.config_name=="TURKISH_SEGMENT_ISP" || $.DataMap.config_name=="GEORGIA"){
		getPan(1).hide();
	}else{
		getPan(1).show();
	}
}

function autofw_detect(obj, r_t) {
	var lock_time = r_t;
	// 若超過60秒都無回應 -> 跳出訊息框, 內容為”檢測版本異常.”
	$.LockInterval = window.setInterval(function () {
		if ($.LockTime < lock_time) {
			$.LockTime += 1;
		} else {
			window.clearInterval($.LockInterval);
			$.unlockWin($.CommonLan['auto_fw_error_exception'], '', 3);
		}
	}, 1000);

	try {
		ajax_AutoFWRequest(obj, function (data) {
			console.log(data);
			console.log(typeof(data));
			var res = data[0];
			console.log(res);
			console.log(typeof(res));

			if (res === 'ok') {
				$.unlockWin();
				getAppData(function (data) {
					setAppTagData(data);
					getTag(1, 1).btn_b.entity.style.display = "";
					getTag(1, 1).context.entity.innerText = $.DataMap.new_ver;
				});
			}
			if (typeof ($.CommonLan['auto_fw_' + res]) !== 'undefined')
				$.unlockWin($.CommonLan['auto_fw_' + res], '', 3);

		});
	} catch (e) {
		console.log('autofw_detect error');
	}
}

function autofw_upgrade(obj, r_t) {
	var lock_time = r_t;
	$.LockInterval = window.setInterval(function () {
		if ($.LockTime < lock_time) {
			$.LockTime += 1;
		} else {
			window.clearInterval($.LockInterval);
			$.unlockWin($.CommonLan['auto_fw_download_error'], '', 3);
		}
	}, 1000);

	try {
		ajax_AutoFWRequest(obj, function (data) {
			console.log(data);
			console.log(typeof(data));
			var res = data[0];
			console.log(res);
			console.log(typeof(res));

			// download_success > after 120sec > skk_get 1 次
			if (res === 'download_success') {
				$.lockWin($.CommonLan['autoUpdate_tip'], 'autoFW', 4);
				setTimeout(function () {
					$.lockWin();
				}, 1000 * 3);
				r_t = 120;
				getTag(2, 0).tip.html($.CommonLan['autoUpdate_tip']);
				getPan(2).show();
				getPan(0).hide();
				getPan(1).hide();
				getTag(2, 0).setTimeout(r_t);
			}
		});
	} catch (e) {
		console.log('autofw_upgrade error');
	}
}
function update_set(tag) {
	if (file_val.value == 0) { return false; }
	var band = $.DataMap.wlanBandMode;
	var r_t = 150;
	getPan(2).show();
	getPan(0).hide();
	getPan(1).hide();
	$.lockWin();
	if (band == 3)
		r_t += 10;
	getTag(2, 0).setTimeout(r_t);
	if ($.Debug && $.Emulator) {
		getTag(2, 0).setTimeout(30);
		return;
	} else {
		ajax_update(true, up_url[0]);
	}
}
function auto_update_set() {
	var obj = new Object();
	obj.update_set = "update_set";
	obj.mode_name = "skk_set";
	obj.autoUpdate = get_radio_val('autoUpdate');
	setAppData('save', obj);
}
function show_sys_time(){
	setTagDomAction(0,[2,3,4],null,'hide');
	var val = getTag(0,1).data;
	if(val=='1'){
		getTag(0,4).show();
	}else{
		setTagDomAction(0,[2,3],null,'show');
	}
}
var sys_timer = null;
function init_sys_time(){
	getTag(0,3).text_a.entity.maxLength = '2';
	getTag(0,4).select.entity.style.width = "310px";
	if(sys_timer!=null){window.clearInterval(sys_timer);}
	refresh_sys_time();
	sys_timer = window.setInterval(function(){
		if($.CurrentApp != "sys_time"){
			window.clearInterval(sys_timer);
			return;
		}
		getAppData(function(data){
			getTag(0,0).context.html(data.time_now);
		});
	},1000);
}
function save_sys_time(){
	if(sys_timer!=null){window.clearInterval(sys_timer);}
	$.CGI_MOUDLE = {time_set:1};
	if(getTag(0,1).data=='0'){
		var year = getTag(0,2).text_a.entity.value;
		var mon = getTag(0,2).text_b.entity.value;
		var day = getTag(0,2).text_c.entity.value;
		var hour = getTag(0,3).text_a.entity.value;
		var min = getTag(0,3).text_b.entity.value;
		var sec = getTag(0,3).text_c.entity.value;
		if(!check_YMD(year,mon,day)){return;}
		if(!check_HMS(hour,min,sec)){return;}
	}
	setAppData('save',[0]);
}
function refresh_sys_time(){
	var data = $.DataMap;
	setAppTagData(data);
	$.exec(getTag(0,'ntpEnabled').action);
	getTagDom(0,0,"context").html(data.time_now);
}
function save_ntp_server(){
	if(sys_timer!=null){window.clearInterval(sys_timer);}
	setAppData('save',[1]);
}
function init_passwd(){
	setAppTagData($.DataMap);
	getTag(1,1).text.entity.value = '';
	
	if($.DataMap.config_name=="TURKISH_SEGMENT_ISP"){
		if($.DataMap.superlogin==1){
			getPan(0).show();
			getTag(0,1).text.entity.value = '';
		}else{
			getPan(0).hide();
			getTag(0,1).text.entity.value = '';
		}
		
	}else{
		getPan(0).hide();
	}
	
}
function save_passwd(){
	var obj = new Object();
	var data = $.DataMap;
	if(!checkTag([1])){return;}
	if(getTag(1,1).text.entity.value != Base64.decode(data.password)){
		checkShow(getTag(1,1).text,$.CommonLan['password_err']);
		return;
	}
	if(!checkDomArr(1,[2,3,4],["text_string_len","text_string_len","text_string_len"])){return;};
	if(getTag(1,3).text.entity.value!=getTag(1,4).text.entity.value){
		checkShow(getTag(1,4).text,$.CommonLan['password_err']);
		return;
	}
	if(getTag(1,2).text.entity.value == '' || getTag(1,3).text.entity.value == '')
	{
		$.CGI_MOUDLE.no_pwd = 1;
	}
	
	obj = getSubmitData([1]);
	obj.username = obj.new_user;
	obj.password = obj.new_pwd;
	setAppData('save',obj);
}

function save_passwd_teq(){
	var obj = new Object();
	var data = $.DataMap;
	if(!checkTag([0])){return;}
	
		if(getTag(0,1).text.entity.value != Base64.decode(data.superpassword)){
			checkShow(getTag(0,1).text,$.CommonLan['password_err']);
			return;
		}
		if(!checkDomArr(0,[2,3],["text_string_len","text_string_len"])){return;};
		if(getTag(0,2).text.entity.value!=getTag(0,3).text.entity.value){
			checkShow(getTag(0,3).text,$.CommonLan['password_err']);
			return;
		}
	
		if(getTag(1,3).text.entity.value == '')
		{
			$.CGI_MOUDLE.no_pwd = 1;
		}
		obj = getSubmitData([0]);

		
	obj.superusername = obj.superusername;
	obj.superpassword = obj.new_superpassword;

	setAppData('save',obj);
	
}
function init_sign_out(){
	JQ("#qos_arg_set").css("margin-top","10px")
}
//退出登录
function save_sign_out(){
	param = {"wl_link":"0", "app":"exit"};
	var ajax_param = {
		type: "POST",
		data: param,
		url: "/login_exit.cgi",
		success: function (result) {
			if(result == "[\"SUCCESS\"]"){
					if(sys_status_time!=null)
						window.clearInterval(sys_status_time);
					JQ.ajax({
						async: false,
						url: location.pathname,
						type: 'GET',
						username: 'logout'
					});
                                                window.clearInterval(sys_status_time);
                                        JQ.ajax({
                                                async: false,
                                                url: location.pathname,
                                                type: 'GET',
                                        });
					
			}
		},
		error: function(xhr, ajaxOptions, thrownError){
			console.log("init page error");
		}
	};
	JQ.ajax(ajax_param);
}

function init_backup(){
	getTagDom(1,1,"file").setAttr({
		"allowtransparency":"yes",
		"width":"460px",
		"height":"25px",
		"scrolling":"no",
		"border":"0",
		"src":"./backup.htm"
	});
	getTag(1,2).text.entity.style.width="250px";
	disableDom(getTag(1,2).text,true)
	getTag(1,2).btn.entity.value=$.CommonLan['browse'];
	getTag(1,2).btn.entity.onclick = function(){ 
		file_form.update.click();
		file_form.update.onchange =function(){ 
			getTag(1,2).text.entity.value = file_form.update.value;
		}
		getTag(1,2).text.entity.value = file_form.update.value;
	}
	getPan(2).hide();
}
function save_backup(){
	if ($.Debug && $.Emulator)
	{
		$.lockWin($.CommonLan['lock_save']);
		return;
	}
	setAppData(null,{backup_get:'1'},function(){
		window.open("./config.dat","_blank");
	});
}
function save_restore(){
	if(file_val.value == '')return false;
	getPan(2).show();
	getPan(1).hide();
	getPan(0).hide();
	$.lockWin();
	getTag(2,0).setTimeout(42);
	getTag(2,0).tip.html($.CommonLan['restore'] +"...");
	if($.Debug && $.Emulator) {
		getTag(1,0).setTimeout(30);
		return;
	} else {
		ajax_update(true, up_url[1]);
	}
}

function init_default(){getPan(1).hide();}
function default_set(){
	getPan(1).show();
	getPan(0).hide();
	$.lockWin();
	setAppData(null,{default_get:1},function(data){
		reboot('http://' + data.ip,{default_set:1});
	});
}
function init_reboot(){getPan(1).hide();}
function reboot(ip,obj){
	if (typeof(obj) == 'undefined') var obj = new Object;
	getPan(1).show();
	getPan(0).hide();
	$.lockWin();
	if(ip && typeof ip == 'string'){
		getTag(1,0).setTimeout(60,ip);
	}else{
		getTag(1,0).setTimeout(60);
	}
	getTag(1,0).tip.html($.CommonLan['reboot'] +"...");
	if(typeof(obj.default_set) == 'undefined')
		obj.reboot_set = 1;
	setAppData(null,obj);
}
function init_schedule(){
	setAppTagData($.DataMap);
	init_weekday();
	$.exec(getTag(0,0).action);
	schedule_list_show();
}
var type_arr = ['Disable','reboot'];
function schedule_list_show(){
	var show = getTag(2,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		show[i].entity.cells[1].innerHTML = htmlstr(data.comment);
		show[i].entity.cells[2].innerHTML = type_arr[data.type];
		show[i].entity.cells[3].innerHTML = dates_list_show(data.day);
		show[i].entity.cells[4].innerHTML = time_list_show(data.time);
	}
}
function sch_type_act()
{
	var val = getTag(1,1).data;
	var st = (val != 0)?false:true;
	JQ('#time').prop('disabled',true);
//	if (JQ('#time').is(':disabled') == true && val == '0') {
		getTagDom(1,3,"s_hour").entity.disabled = false;
		getTagDom(1,3,"s_min").entity.disabled = false;
		getTagDom(1,3,"e_hour").entity.disabled = true;
		getTagDom(1,3,"e_min").entity.disabled = true;
		getTagDom(1,3,"e_hour").entity.value = getTagDom(1,3,"s_hour").entity.value;
		getTagDom(1,3,"e_min").entity.value = getTagDom(1,3,"s_min").entity.value;
		JQ('#time').attr('checked',false);
//	}
//	if (JQ('#time').is(':disabled') == false) {
//	//if (JQ('#time').is(':checked') == false) {
//		getTagDom(1,3,"e_hour").entity.disabled = false;
//		getTagDom(1,3,"e_min").entity.disabled = false;
//	}
}
function add_schedule(tag){
	if(!checkTag([1])) return;
	if(!week_null_check(getTag(1,'day'))){return;}
	if(getTag(1,'time').chk_all.entity.checked ==false){
		if(!time_compare(1,'time')){return;}
	}
	tag.mode = MOD;
	var obj = new Object();
	obj = getSubmitData([1]);
	obj.id = MODData.id;

	setAppData('add',obj,function(){tag.mode = "add";});
}

function mod_schedule_rule(row){
	getTag(1,'scheduleList').btn.entity.value = $.CommonLan['mod'];
	MOD = "mod";
	setModify(row.data);
	MODData = row.data;
}
function del_schedule_rule(row){
	if(!confirm($.CommonLan["del_one_tip"])) return;
	MOD = "del";
	var obj = new Object();
	obj.schedule_set = "del";
	obj2obj(obj,row.data);
	obj.scheduleList = 'del';
	setAppData('delete',obj);
}
function del_schedule_all(){
	if(!confirm($.CommonLan["del_tip"])){return;}
	setAppData('delete',[2]);
}
function save_interval(tag){
	if(!checkTag([0])){return;}
	MOD = "save";
	setAppData('save',[0]);
}
function interval_set(){
	setTagDomAction(0,[1],null,SHRadioAct(0,0));
}
function save_watchdog(){
	if(!checkTag([0])){return;}
	setAppData('save',[0]);
}
function change_wd_state()
{
	setTagDomAction(0,['1-4'],null,SHRadioAct(0,0));
}

function rule_list_show(data){
	return  data == '0'? $.CommonLan['forbid_s']:$.CommonLan['allow_s'];
}
function dates_list_show(data){
	var week_str = '';
	for(var j=0;j<7;j++){
		var day = 64 >> j & data;
		if(day != 0)
			week_str += JQ('input[ID*="day'+j+'"]').next().text()+' ';
	}
	if(data == '127') week_str = $.CommonLan["everday"];
	return week_str;
}
function time_list_show(data){
	return data == 'all'? $.CommonLan['all_day']:data;
}
function ip_list_show(data){
	var data = data.split(" ");
	var str = null;
	if(data[0] == "0")
		str = $.CommonLan['all'];
	else 
		str = data[1] +"<br/>/"+ data[2];
	return str;
}
function ip6_list_show(data){
	var data = data.split(" ");
	var str = null;
	if(data[0] == "0")
		str = $.CommonLan['all'];
	else 
		str = data[1];
	return str;
}
function scroll_type()
{
	JQ("body").eq(0).css("overflow",Scroll_ST == false?"hidden":"");
	return Scroll_ST;
}

function set_radio(name,value){
	var flag=true;
	var collection = JQ('input:radio[name=\"'+name+'\"]');
	for (i=0;i<collection.length;i++){
		if(collection[i].value == value){
			collection[i].checked =true;
			flag=false;
		}
	}
	if(flag && collection.length >1){
		collection[0].checked =true;
	}
}

function get_radio_val(name){
	var collection= JQ('input:radio[name=\"'+name+'\"]');
	for(var i=0;i<collection.length;i++){
		if(collection[i].checked==true)
			return collection[i].value;
	}
	return collection[0].value;
}

/***---------------------------copy from 5G action---------------------------------***/
//根据返回状态给运行状态页面赋值
function change_status_show(data){
	var data = $.DataMap;
	var band = parseInt(data.wlanBandMode,10);

// wan
	if ($.SUPPORT_MULTI_WAN == 1)
		eth_wan_status_show();
	else {
		var conn_type = data.wan[0].type;
		$.Apps["status"].Pans["wanConfList"].hide();
		if($.DataMap.opMode == '1'){
			$.Apps["status"].Pans["status_l2tp"].hide();
			$.Apps["status"].Pans["status_pptp"].hide();
			$.Apps["status"].Pans["status_wan"].hide();
		}

	//L2TP/PPTP/Russia
		setTagDomAction(2,['2-8'],null,'show');
		(conn_type==3)?getPan(0).show():getPan(0).hide();
		(conn_type==4)?getPan(1).show():getPan(1).hide();
		var secd = (conn_type==22)?'show':'hide';
		setTagDomAction(2,[7,8],null,secd);
		getTag(2,"connected").btn.entity.value=(data.connected=='0')? $.CommonLan['connect']:$.CommonLan['disconnect'];
	//L2TP/PPTP Dynamic
		if(conn_type==3){
			getTagDom(0,0,"context").html(data.st_wanIpAddr2);
			getTagDom(0,1,"context").html(data.st_wanSubMask2);
			getTagDom(0,2,"context").html(data.st_wanDefGw2);
		}else if(conn_type==4){
			getTagDom(1,0,"context").html(data.st_wanIpAddr2);
			getTagDom(1,1,"context").html(data.st_wanSubMask2);
			getTagDom(1,2,"context").html(data.st_wanDefGw2);
		}else if(conn_type==5){
			setTagDomAction(2,['2-8'],null,'hide');
		}
	//连接类型
		getTagDom(2,0,"context").html(comm_map[conn_type]);
		if (typeof(a_connect) != 'undefined') {
			a_connect(conn_type);
		}

	//连接状态 
		var con = data.connected;
		var val = (con == 0)?$.CommonLan['disconnected']:$.CommonLan['connected'];
		getTagDom(2,"connected","context").html(val);
		var disab = ((conn_type==1 || conn_type==20 || conn_type==21) &&  data.wan[0].dhcp == '1')?true:false;
		getTag(2,'connected').btn.setClass((disab == true)?"df_btn_disabled":"df_btn");
		getTag(2,'connected').btn.entity.disabled=disab;
		if (conn_type==5)
			JQ('#connected').hide();
		else
			JQ('#connected').show();
	}
 
//DHCP服务器 
	var dhcp = data.dhcpEnabled;
	var dhcp_v = (dhcp == '0')?$.CommonLan['off']:$.CommonLan['on'];
	getTagDom(3,3,"context").html(dhcp_v);
	getTag(3,3).context.setAttr({"style":"width:65px;"});
	var dhcp_f = (dhcp == '2')?(" ("+$.DataMap.dhcpClientStart+"-"+$.DataMap.dhcpClientEnd+")"):"";
	getTagDom(3,3,"after").html(dhcp_f);
	if(data.opMode == "1"){
		setTagDomAction(3,[3],null,'hide');
		getTagDom(3,1,"context").html(data.st_lanIpAddr);
		getTagDom(3,2,"context").html(data.st_lanSubMask);
	}

//wifi
	if (band & 1) change_wl_status_show(data.wlan[$.DataMap.wl2g_idx], band);
	if (band & 2) change_wl_status_show(data.wlan[$.DataMap.wl5g_idx], band);

//modem
	if ($.SUPPORT_3g4g == 1 && data.usb3gEnabled == 1)
		usb_status_show(data);
	else
		$.Apps["status"].Pans["modemList"].hide();
}
function eth_wan_status_show()
{
	var show = getTag(6,0).tab.tbody.Rows;
	var lan = ($.ShowLan)?CUS.Lang_map[$.DeLanguage]:$.Language;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		var gettag = show[i].entity.cells[0].innerHTML;
		var con = JQ('#'+ gettag).val();
		var arr = show[i].entity.cells[4].innerHTML.split('/');

		show[i].entity.cells[1].innerHTML = eval("("+Language[lan].network.eth_wan.type_options+")")[data.type];
		show[i].entity.cells[4].innerHTML = ((data.connected=='0')?$.CommonLan['down']:$.CommonLan['up'])+' '+arr[1];

		JQ('#'+ gettag).val(data.connected=='0'?$.CommonLan['connect']:$.CommonLan['disconnect']);
		JQ('#'+ gettag).show();
		JQ('#'+ gettag).on('click', function(){
			$.CGI_MOUDLE = {};
			var show = getTag(6,0).tab.tbody.Rows;
			var obj = new Object();
			obj.ifname = this.id;
			for(var i=0;i<show.length;i++){
				if (show[i].entity.cells[0].innerHTML == this.id)
					obj.connected = (show[i].data.connected=='0')?'1':'0';
			}
			setAppData(null,obj);
		});
	}
}
function usb_status_show(data)
{
	var show = getTag(7,0).tab.tbody.Rows;
	for(var i=0;i<show.length;i++){
		var data = show[i].data;
		var gettag = show[i].entity.cells[0].innerHTML;
		var con = JQ('#'+ gettag).val();
		var disab = (data.connected=='0')?true:false;
		var val = (con == "0")?$.CommonLan['disconnected']:$.CommonLan['connected'];
	
		var arr = show[i].entity.cells[4].innerHTML.split('/');
		show[i].entity.cells[4].innerHTML = ((arr[0]=='0')?$.CommonLan['down']:$.CommonLan['up'])+' '+arr[1];

		JQ('#'+ gettag).val(val);
		JQ('#'+ gettag).attr('class',((disab == true)?"df_btn_disabled":"df_btn"));
		JQ('#'+ gettag).attr('disabled',disab);
		JQ('#'+ gettag).on('click', function(){
			$.CGI_MOUDLE = {};
			var obj = new Object();
			var val = (data.connected=='0')?'1':'0';
			obj.ifname = this.id;
			obj.connected = val;
			if(true){
				setAppData(null,obj);
			}else{return;}
		});
	}
}

function change_wl_status_show(data, band)
{
	var band = parseInt($.DataMap.wlanBandMode);
	var p = 4;
	var idx = (band==3)?((data.phyBand==2)?0:1):0;
	if (band == 3) p = (data.phyBand==1)?4:5;
	var wl_v = (data.wlanEnabled == '0')?$.CommonLan['off']:$.CommonLan['on'];
	var net_mode = data.wlanMode;
	var mode_v = net_map[net_mode];
	var wps_v = (data.wscEnabled == '0')?$.CommonLan['off']:$.CommonLan['on'];
	setTagDomAction(p,['1-7'],null,'show');
	getTagDom(p,0,"context").html(wl_v);
	getTagDom(p,1,"context").html(Base64.decode(data.ssid));
	getTagDom(p,2,"context").html(mode_v);
	getTagDom(p,3,"context").html(sec_map[data.encrypt]);
	getTagDom(p,4,"context").html($.DataMap.wlanInfo[idx].st_channel);
	getTagDom(p,5,"context").html(data.wlanMacAddr);
	getTagDom(p,6,"context").html(wps_v);

	if(net_mode==2) setTagDomAction(p,[1],null,'hide');
	if(net_mode==1 || net_mode==4)
	{
		con = $.DataMap.wlanInfo[idx].st_wlconn;
		val = (con == "0")?$.CommonLan['disconnected']:$.CommonLan['connected'];
		getTagDom(p,7,"context").html(val);
	}
	else
		setTagDomAction(p,[7],null,'hide');
	if (data.wlanEnabled == '0')
		setTagDomAction(p,['1-7'],null,'hide');
	if ($.DataMap.mapController == '2' && $.DataMap.wlanInfo[idx].st_channel == '')
		setTagDomAction(p,['1-7'],null,'hide');
}

/************************** wps **************************/
function init_wps(){
	var data = $.DataMap.wlan[get_wlan_band()];
	getTag(0,4).children[1].children[0].hide();
	if(data.broadSSID == 0 || data.wl_mac_filter_enable== 1)
		data.wscEnabled = 0;

	if(data.wlanMode==1)
		getTag(0,"wps_status").hide();

	var _data = new Object();
	setAppTagData(data);

	setWPSButtonAction(data);
	setButtonLanguage(data);
	var obj = new Object();
	obj.wl_wps = "1";

	getTag(0,2).btn.entity.style.width = "138px";
	if(data.wlanMode == "20" || data.wlanMode == "1"){
		getTag(0,1).entity.style.display = "none";
		getTag(0,2).entity.style.display = "none";
		getTag(0,3).entity.style.display = "none";
		getTag(0,4).entity.style.display = "none";
	}

	hand_add_hide();
	$.Apps[$.CurrentApp].Pans[2].hide();
}

function setWPSButtonAction(data)
{
	var wps_config = data.wscConfigured;
	var wps_enable = data.wscEnabled;
	var wps_lockdown = $.DataMap.wscLock;

	var wps = getTag(0,0).btn;
	wps.entity.onclick = function(){
		var obj = new Object();
		obj.wl_idx = get_wlan_band();
		obj.wps_set = "ap";
		obj.wscEnabled = (data.wscEnabled=='0')?'1':'0';
		setAppData('save',obj,function(data){
			$.Apps[$.CurrentApp].Pans[1].hide();
		});
	}
	var pin = getTag(0,1).btn;
	pin.entity.onclick = function(){
		var obj = new Object();
		obj.wl_idx = get_wlan_band();
		obj.wps_set = "mkpin";
		setAppData('save',obj);
	}

	var wps_status=getTag(0,2).btn;
	wps_status.entity.onclick = function(){
		var obj = new Object();
		obj.wl_idx = get_wlan_band();
		obj.wps_set = "uncfg";
		setAppData('save',obj);
	}
	if(wps_config==0 || getTag("wps_security", "wscEnabled").data == '0')
	{
		wps_status.entity.disabled=true;
		wps_status.setClass("df_btn_disabled");
	}else{
		wps_status.entity.disabled=false;
		wps_status.setClass("df_btn");
	}
	var wps_lock = getTag(0,3).btn;
	wps_lock.entity.onclick = function(){
		var obj = new Object();
		obj.wl_idx = get_wlan_band();
		obj.wps_set = "unlock";
		setAppData('save',obj);
	}

	if(wps_lockdown==0||wps_enable==0)
	{
		wps_lock.entity.disabled=true;
		wps_lock.setClass("df_btn_disabled");
	}else{
		wps_lock.setClass("df_btn");
		wps_lock.entity.disabled=false;
	}

	var wps_stop_wsc = getTag(0,4).btn;
		wps_stop_wsc.entity.onclick = function(){
		var obj = new Object();
		obj.wl_idx = get_wlan_band();
		obj.wps_set ="stopwsc";
		setAppData('save',obj);
	}
	if(wps_enable==0)
	{
		wps_stop_wsc.entity.disabled=true;
		wps_stop_wsc.setClass("df_btn_disabled");
	}else{
		wps_stop_wsc.setClass("df_btn");
		wps_stop_wsc.entity.disabled=false;
	}
}
function setButtonLanguage(data)
{
	setWPSStyle(getTag(0,0).btn,data);
	setWPSStatus(getTag(0,2).btn,data);
	setWPSlock(getTag(0,3).btn,data);
	setWPSstop(getTag(0,4).btn);
}

function setWPSStyle(wps,data){
	var wps_config = data.wscConfigured;
	var wps_enable = data.wscEnabled;
	var wps_lockdown = $.DataMap.wscLock;
	var wps_localpin = data.wscPin;

	if(wps_enable == "0"){
		getTag(0,0).context.html( R($.CommonLan["wps_off_s"], $.CommonLan['off']) );//for UA language
		getTag(0,0).context.entity.style.color = "red";
		wps.setValue($.CommonLan["wps_on"]);
		setWPSDisable(true);
	}else if(wps_enable == "1"){
		getTagDom(0,0,"context").html($.CommonLan["on"]);
		getTag(0,0).context.entity.style.color = "green";
		wps.setValue($.CommonLan["wps_off"]);
		setWPSDisable(false);
	}
	getTag(0,1).context.entity.innerHTML=wps_localpin;
	getTag(0,1).btn.entity.value = $.CommonLan["new_pin"];
}

function setWPSStatus(wps_status,data){
	var wps_config = data.wscConfigured;
	var wps_enable = data.wscEnabled;
	var wps_lockdown = $.DataMap.wscLock;

	wps_status.setValue($.CommonLan["wps_status_btn"]);
	if(wps_config == "1")
	{
		getTag(0,2).context.html($.CommonLan["wps_status_on"]);
		getTag(0,2).context.entity.style.color = "green";
	}
	else
	{
		getTag(0,2).context.html($.CommonLan["wps_status_off"]);
		getTag(0,2).context.entity.style.color = "red";
	}
}
function setWPSlock(wps_lock,data)
{
	var wps_config = data.wscConfigured;
	var wps_enable = data.wscEnabled;
	var wps_lockdown = $.DataMap.wscLock;

	if(wps_lockdown=='0')
	{
		getTag(0,3).context.html($.CommonLan["wps_lock_off"]);
		getTag(0,3).context.entity.style.color = "red";
		wps_lock.setValue( R($.CommonLan["wps_lock_off_btn"], $.CommonLan["wps_lock_off"]) ); //for UA language
	}
	else
	{
		getTag(0,3).context.html($.CommonLan["wps_lock_on"]);
		getTag(0,3).context.entity.style.color = "green";
		wps_lock.setValue($.CommonLan["wps_lock_off"]);
	}
}
function setWPSstop(wps_stop_wsc)
{
	wps_stop_wsc.setValue($.CommonLan["stop_wsc"]);
}

function save_pin_config(){
	var obj = new Object();
	if(JQ('#wps_ap_mac').val() != '')
	{
		if(!checkDom(getTag(2,"wps_ap_mac").text,"text_mac")){return;}
		obj.wps_ap_mac=JQ('#wps_ap_mac').val();
	}
	if(JQ('#wps_ap_ssid').val() != '')
	{
		if(!checkDom(getTag(2,"wps_ap_ssid").text,"text_string_ssid")){return;}
		obj.wps_ap_ssid=JQ('#wps_ap_ssid').val();
	}
	obj.wps_mode="cpin";
	setAppData('add',obj,function(){
		$.Apps[$.CurrentApp].Pans[1].hide();
		$.Apps[$.CurrentApp].Pans[2].hide();
	});
}
/************************** end of wps **************************/

var ch_info = '', ch_info_2 = '';
function add_wep_wpa_after(){
	var p = 3;
	var t = ($.CurrentApp=='multiple_ssid'||$.CurrentApp=='multiple_ssid5g')?'6':'4';
	var SET = function(p){
		var v = null;
		if(secmode == "1"){ //wep
			if(keysize == "1"){
				v = (keymode == "1")?(after_map[$.after_map]['a']):(after_map[$.after_map]['b']);
			}else{
				v = (keymode == "1")?(after_map[$.after_map]['c']):(after_map[$.after_map]['d']);
			}
			if($.CurrentApp != "wan_set_shortcut") {
				getTag(p,t).text.entity.maxLength=v.ch;
				after.html(v.str);
			} else {
				JQ('#wepKey_t').prop('maxLength',v.ch);
				JQ('#wepKey_tip').html(v.str);
			}
		}else{  // none , wpa , wpa2
			v = (wpamode == "1")?(after_map[$.after_map]['e']):(after_map[$.after_map]['f']);
			var maxlen = (v.ch.indexOf('-')!=-1)?v.ch.split('-')[1]:v.ch;
			if($.CurrentApp != "wan_set_shortcut") {
				getTag(p,parseInt(t)+1).text.entity.maxLength=maxlen;
				after_wpa.html(v.str);
			} else {
				JQ('#wpaPsk_t').prop('maxLength',maxlen);
				JQ('#wpaPsk_tip').html(v.str);
			}
		}
		if (p == 2 && ($.CurrentApp == "base"||$.CurrentApp == "base5g")) ch_info_2 = v;
		else ch_info = v;
	}

	if($.CurrentApp == "wan"){
		t = 4; p = 2;
		var secmode = getTag(1,1).data;
		var keysize = getTag(p,0).data; 
		var keymode = getTag(p,2).data; 
		var wpamode = getTag(p,3).data;
		var after = getTagDom(p,4,"after");
		var after_wpa = getTagDom(p,5,"after");
	} else if($.CurrentApp == "base"||$.CurrentApp == "base5g"){
		t = 7; p = 1;
		while (p < 3) {
			var secmode = getTag(p,1).data;
			var keysize = getTag(p,3).data;
			var keymode = getTag(p,5).data;
			var wpamode = getTag(p,6).data;
			var after = getTagDom(p,7,"after");
			var after_wpa = getTagDom(p,8,"after");
			SET(p);
			p += 1;
		}
		return;
	} else if($.CurrentApp == "wan_set_shortcut"){
		var secmode = JQ('#encrypt').val();
		if (typeof(check_login_pwd) == 'undefined' && (get_radio_val("apr_mode") != 20))
			var secmode = get_radio_val("enable_wire");
		var keysize = get_radio_val("wepKeySize");
		var keymode = get_radio_val("keyFormat");
		var wpamode = get_radio_val("keyFormat");
	} else {
		var secmode = getTag(p,0).data;
		var keysize = getTag(p,2).data;
		var keymode = getTag(p,4).data;
		var wpamode = getTag(p,5).data;
		var after = getTagDom(p,6,"after");
		var after_wpa = getTagDom(p,7,"after");
	}
	SET(p);
}
/**
*
*  Base64 encode / decode
*  http://www.webtoolkit.info/
*
**/
 
var Base64 = {
	// private property
	_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

	// public method for encoding
	encode : function (input) {
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;
		input = Base64._utf8_encode(input);

		while (i < input.length)
		{
			chr1 = input.charCodeAt(i++);
			chr2 = input.charCodeAt(i++);
			chr3 = input.charCodeAt(i++);

			enc1 = chr1 >> 2;
			enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
			enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
			enc4 = chr3 & 63;

			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}

			output = output +
					this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
					this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
		}
		return output;
	},

	// public method for decoding
	decode : function (input) {
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;
		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

		while (i < input.length)
		{
			enc1 = this._keyStr.indexOf(input.charAt(i++));
			enc2 = this._keyStr.indexOf(input.charAt(i++));
			enc3 = this._keyStr.indexOf(input.charAt(i++));
			enc4 = this._keyStr.indexOf(input.charAt(i++));

			chr1 = (enc1 << 2) | (enc2 >> 4);
			chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			chr3 = ((enc3 & 3) << 6) | enc4;
			output = output + String.fromCharCode(chr1);

			if (enc3 != 64) {
				output = output + String.fromCharCode(chr2);
			}
			if (enc4 != 64) {
				output = output + String.fromCharCode(chr3);
			}
		}

		output = Base64._utf8_decode(output);
		return output;
	},

	// private method for UTF-8 encoding
	_utf8_encode : function (string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";

		for (var n = 0; n < string.length; n++)
		{
			var c = string.charCodeAt(n);

			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}
		}
		return utftext;
	},

	// private method for UTF-8 decoding
	_utf8_decode : function (utftext) {
		var string = "";
		var i = 0;
		var c = c1 = c2 = 0;

		while ( i < utftext.length )
		{
			c = utftext.charCodeAt(i);

			if (c < 128) {
				string += String.fromCharCode(c);
				i++;
			}
			else if((c > 191) && (c < 224)) {
				c2 = utftext.charCodeAt(i+1);
				string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
				i += 2;
			}
			else {
				c2 = utftext.charCodeAt(i+1);
				c3 = utftext.charCodeAt(i+2);
				string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}
		}
		return string;
	}
}

/****************************tr069 ***************************/
function init_tr069()
{
	setAppTagData($.DataMap);
	$.exec(getTag(0,'cwmpEnabled').action);
	$.exec(getTag(1,'cwmpInformEnabled').action);
	$.exec(getTag(3,'cwmpStunEnabled').action);
}
function change_tr069_enable(){
/* 	show_hide_radio(0,'cwmpEnabled');
	var act = (getTag(0,'cwmpEnabled').data == '0')?'hide':'show';
 */
	setPanAction([1,2,3],SHRadioAct(0,'cwmpEnabled'));
}
function change_tr069_inform_enable(){
	setTagDomAction(1,[4],null,SHRadioAct(1,'cwmpInformEnabled'));
}
function change_stun_enable(){
	setTagDomAction(3,[1,2,3,4],null,SHRadioAct(3,'cwmpStunEnabled'));
}
function save_tr069_config()
{
	var obj = getSubmitData([0,4]);
	if(obj.cwmpEnabled == "1"){
		if(!checkTag([1,3])){return;}
		var obj = getSubmitData([0,1,2,3,4]);
	}
	setAppData('save',obj);
}

/*********************************samba & ftpd ********************/
function init_usb(){
	setAppTagData($.DataMap);
	$.exec(getTag(0,1).action);
	$.exec(getTag(0,0).action);
}
function init_media_server(){}
function save_media_server(){
	setAppData('save',[0]);
}
function set_remove_usb(){
	MOD = 'remove';
	setAppData('save',[0]);
}
function change_smb_endable()
{
	if(getTag(0,0).data == '0')
	{
		setTagDomAction(0,[1,2,3],null,'hide');
	}else{
		setTagDomAction(0,[1],null,'show');
		change_samba_security();
	}
}
function save_smb_conf()
{
	if(!checkTag([0])){return;}
	setAppData('save',[0]);
}
function change_samba_security()
{
	setTagDomAction(0,[2,3],null,SHRadioAct(0,1));
}
function save_ftpd_conf()
{
	if(!checkTag([0])){return;}
	setAppData('save',[0]);
}
function change_ftpd_endable()
{
	if(getTag(0,0).data == '0')
	{
		setTagDomAction(0,[1,2,3],null,'hide');
	}else{
		setTagDomAction(0,[1],null,'show');
		change_ftp_server_security();
	}
}
function change_ftp_server_security()
{
	setTagDomAction(0,[2,3],null,SHRadioAct(0,1));
}
function init_weekday()
{
	JQ('#day6').next().next().click();
	JQ('#end').next().click();
	JQ('#time').click();
	if ($.CurrentApp == 'schedule' && getTag(1,1).data == '0') {
		JQ('#time').prop('disabled',true);
		JQ('#time').removeAttr('checked');
		$.exec(getTag(1,1).action);
	} else {
		JQ('#time').prop('disabled',false);
	}
}
/*************************************** multi-wan eth ***************************************/
var vdsl_ip_pro = false;
var eth_act = 'mod';
function init_ethwan_set()
{
	add_multi_opt();
	setAppTagData($.DataMap.wan[getEthIdx()]);
	$.exec(getTag(0,2).action,getTag(0,2));
	$.exec(getTag(0,0).action,getTag(0,0));
	getTag(5,"ipv6rdMaskLen").text.setData($.DataMap.wanConfList[getEthIdx()].ipAddr);
	disableDom(getTag(5,"ipv6rdMaskLen").text,true);
	getTag(3,1).prefixInfo.hide();
	getTag(3,1).prefix.hide();
	getTag(6,1).prefixInfo.hide();
	getTag(6,1).prefix.hide();
	getTag(6,2).prefixInfo.hide();
	getTag(6,2).prefix.hide();
	JQ("#mapping_panel").attr("style","height:75px");
}

function conn_mode_change(tag){
	setTagDomAction(0,['5-6'],null,'hide');
	//hide all
	for (var i=1; i<=($.Apps[$.CurrentApp].Pans.len-3);i++)
	{
		JQ('#'+getPan(i).name+'_panel').hide();
		for (var j=0; j<($.Apps[$.CurrentApp].Pans[i].Tags.len);j++)
		{
			$.Apps[$.CurrentApp].Pans[i].Tags[j].hide();
		}
	}

	if(tag.data != '0')
		setTagDomAction(0,['5-6'],null,'show');
	$.exec(getTag(0,'vlan').action);
	JQ('#'+getPan(4).name+'_panel').html(Language[$.Language][$.CurrentModule][$.CurrentApp][getPan(4).name+'_panel']);

	switch(tag.data)
	{
		case '1':	//DHCP+Static
		case '2':	//pppoe
			vdsl_ip_pro = ($.DataMap[getTag(1,0).name] == '1')?false:true;
			JQ('#'+getPan(1).name+'_panel').show();
			setTagDomAction(1,[0],null,'show');
			var exfunc = getTag(1,'ver');
			$.exec(exfunc.action,exfunc);
		break;
		case '3':
		case '4':
			ipSettings(true,2);
			ipSettings(true,4);
			setTagDomAction(2,[0],null,'show');
			JQ('#'+getPan(4).name+'_panel').hide();
			var exfunc = getTag(4,'dhcp');
			$.exec(exfunc.action,exfunc);
			break;
		case '5':	//DS-Lite
			ipSettings(true,3);
			ipSettings(true,4);
			JQ('#'+getPan(4).name+'_panel').hide();
			$.exec(getTag(3,0).action);
			ipSettings(true,6);
			JQ('#'+getPan(6).name+'_panel').hide();
			var exfunc = getTag(6,'ipv6Dhcp');
			$.exec(exfunc.action,exfunc);
		break;
		case '6':	//6rd
			ipSettings(true,4);
			ipSettings(true,5);
			ipSettings(true,6);
			JQ('#'+getPan(4).name+'_panel').html(Language[$.Language][$.CurrentModule][$.CurrentApp][getPan(5).name+'_panel']);
			JQ('#'+getPan(5).name+'_panel').hide();
			JQ('#'+getPan(6).name+'_panel').hide();
			var exfunc = getTag(4,'dhcp');
			$.exec(exfunc.action,exfunc);
		break;
		default: break;
	}
}

function vlanSel(){
	setTagDomAction(0,['3-4'],null, SHRadioAct(0,2));
}
function protocolChange(tag){
	acm = getTag(0,0).data;
	if (acm == '5' || acm == '6') return;
	
	switch (tag.data){
		case '0': tag.select.setData('1');
		case '1':
			if(acm == 1){
				ipSettings(true,4);
				var exfunc = getTag(4,'dhcp');
				$.exec(exfunc.action,exfunc);
			}
			if(acm == 2) ipSettings(true,2);
			ipSettings(false,6);
			vdsl_ip_pro = false;
		break;
		case '2':
			if(acm == 1) ipSettings(false,4);
			if(acm == 2) ipSettings(true,2);
			ipSettings(true,6);
			var exfunc = getTag(6,'ipv6Dhcp');
			$.exec(exfunc.action,exfunc);
			vdsl_ip_pro = true;
		break;
		case '3':
			if(acm == 1){
				ipSettings(true,4);
				var exfunc = getTag(4,'dhcp');
				$.exec(exfunc.action,exfunc);
			}
			if(acm == 2 || acm == 3 || acm == 4) ipSettings(true,2);
			ipSettings(true,6);
			var exfunc = getTag(6,'ipv6Dhcp');
			$.exec(exfunc.action,exfunc);
			vdsl_ip_pro = true;
		break;
	}
}
function ipSettings(act,p)
{	var pArr={
		'2':['1-3'],	//pppoe
		'3':['0-1'],	//dslite
		'4':['0-3'],	//ipoe
		'5':['0-3'],	//6rd
		'6':['0-2']		//v6
	};
	var pan = JQ('#'+getPan(p).name+'_panel');
	if (act==true) pan.show(); else pan.hide();
	var flag = (act==true)?'show':'hide';
	setTagDomAction(p,pArr[p],null,flag);
	if (p == 2){
		var exfunc = getTag(p,'connType');
		$.exec(exfunc.action,exfunc);
	}
}
function ipTypeSel(tag)
{
	var line = $.Apps[$.CurrentApp].Pans[4].Tags;
	for (var j=1; j<(line.len);j++)
	{
		setTagDomAction(4,[j],null,SHRadioAct(4,0));
		if(typeof(getTag(4,j).prefix) != 'undefined')
			setTagDomAction(4,[j],null,SHRadioAct(4,0));
	}

	if(getTag(0,0).data == '6') {
		var exfunc = getTag(5,0);
		$.exec(exfunc.action,exfunc);
	}
}
function ipTypeSelv6()
{
	if(getTag(0,0).data == 2) {
		JQ('#'+getPan(6).name+'_panel').hide();
		setTagDomAction(6,[0,1,2],null,'hide');
	} else {
		JQ('#'+getPan(6).name+'_panel').show();
		setTagDomAction(6,[1,2],null,SHRadioAct(6,0));
	}
}
function dsliteSel(tag)
{
	setTagDomAction(4,[0],null,'hide');
	var act = SHRadioAct(3,0);
	setTagDomAction(3,[1],null,act);
	setTagDomAction(4,['1-3'],null,act);
}
function sixrdSel(tag)
{
	if(getTag(4,0).data == '1') tag.panel[1].radio.checked();
	setTagDomAction(6,['0-2'],null,'hide');
	setTagDomAction(5,[0],null,(getTag(4,0).data == '1')?'hide':'show');
	setTagDomAction(5,['1-3'],null,SHRadioAct(5,0));
}
function add_multi_opt()
{
	JQ('#eth_base_panel').append( "<div id='multi_opt_menu'></div>" );
	var sel = JQ('#multi_opt_menu');
	var option = new Array();
	var obj = $.DataMap.wan;
	for(var i in obj){
		if (obj[i].ifname != '' && obj[i].ifidx == '1')
			option.push(obj[i].ifname);
	}
	var select = new CreateSelect(option,'multi');
	if (option.length <8)
		select.entity.options.add(new Option($.CommonLan['new_link'],select.entity.length));
	sel.append(select.entity);
}
function sel_multi_opt(that)
{
	if (getEthIdx() == -1)
	{
		getTag(0,0).select.setData('0');
		getTag(0,1).select.setData('1');
		getTag(0,6).panel[1].radio.checked();
		reinit_mapping_tbl();
	} else {
	setAppTagData($.DataMap.wan[getEthIdx()]);
	}
	var exfunc = getTag(0,0);
	$.exec(exfunc.action,exfunc);
}
function reinit_mapping_tbl()
{
	var Obj = JQ("input[id='map']");
	for (var i=0; i< Obj.length; i++)
	{
		Obj[Obj.length-i-1].checked = true;
	}
}
function save_eth(tag){
	if ((JQ('#'+getTag(0,6).name).is(':visible')) == true)
	{
	var found = -1;
	if(getTag(0,6).data == 1) {
		for(var i in $.DataMap.wan){
			if ($.DataMap.wan[i].route == 1) {
				found = i;
				break;
			}
		}

		if(found != -1) {
			if(eth_act=="add") return;
			if(getEthIdx()!= i) return;
			}
		}
	}

	if(!checkTag([0,1,2,3,4,5,6,7,8])){return;}
	switch(getTag(0,0).data){
		case '1': case '3': case '4': case '6':
		if (getTag('base',0).data == 1)
		{
			var s_ip = getTag(4,'ipAddr').text.entity.value;
			var s_mask = getTag(4,'subMask').text.entity.value;
			var s_gw = getTag(4,'defGw').text.entity.value;
			if(!check_ip_mask(s_ip,s_mask,getTag(4,'ipAddr'))){return;}
			if(!check_ip_mask(s_gw,s_mask,getTag(4,'defGw'),s_ip)){return;}
		}
		break;
		default: break;
	}
	MOD = eth_act;
	var obj = getSubmitData([0,1,2,3,4,5,6,7,8]);
	obj.id = getEthIdx()+1;
	obj.ifIndex = 1;
	obj.ipv6Type = obj.type;
	switch(getTag(0,0).data){
	case '0': obj.ver = 1; break;
	case '2': obj.pppMtu = obj.ipv6MtuSize = 1492; obj.ipv6Username = obj.pppUsername; obj.ipv6Password = obj.pppPassword; obj.ipv6ServName = obj.servDomain; obj.ipv6AcName = obj.acName; obj.dhcp = 2;break;
		case '3': obj.ver = 1; obj.l2tpMtu = obj.ipv6MtuSize = 1460; break;
		case '4': obj.ver = 1; obj.pptpMtu = obj.ipv6MtuSize = 1400; break;
	case '5': obj.ver = 3; break;
	case '6': obj.ver = 3; break;
	default: obj.ipoeMtu = 1500; break;
	}

	setAppData('save',obj);
}
function del_eth()
{
	if(!confirm($.CommonLan["del_one_tip"])) return;
	var obj = new Object();
	obj.wan='del';
	obj.id=getEthIdx()+1;
	obj.ifIndex = 1;
	setAppData('delete',obj);
}
function getEthIdx()
{
	getTag(8,0).btn_a.entity.value = $.CommonLan["save"];
	eth_act = "mod";
	var chk = -1;
	var act = false;
	var cl = 'df_btn';
	var getobj = $.DataMap.wan;
	for(var i in getobj){
		if (getobj[i].ifname == JQ('#multi option:selected').text())
			chk = i;
	}

	if (chk == -1)
	{
		eth_act = "add";
		act = true;
		cl = 'df_btn_disabled';
		getTag(8,0).btn_a.entity.value = $.CommonLan[eth_act];
	}
	disableDom(getTag(8,0).btn_b,act);
	getTag(8,0).btn_b.setClass(cl);
	return parseInt(chk,10);
}

function init_easymesh()
{
	var mapController = $.DataMap.mapController;
	var ndev = getTag(0,2).btn;
	getTag(0,2).children[1].children[0].hide();
	setAppTagData($.DataMap);

	if(mapController==0)
	{
		ndev.entity.disabled=true;
		ndev.setClass("df_btn_disabled");
	}else{
		ndev.setClass("df_btn");
		ndev.entity.disabled=false;
	}
	ndev.setValue($.CommonLan["connect"]);

	ndev.entity.onclick = function(){
		var obj = new Object();
		obj.easymesh_set ="add";
		setAppData('save',obj);
	}
}
function save_easymesh()
{
	if(getTag(0,0).data == '1') {
		for(var i=0; i < $.DataMap.wlanNum; i++){
			var idx = i?$.DataMap.wl5g_idx:$.DataMap.wl2g_idx;
			if($.DataMap.wlan[idx].encrypt != '4' || $.DataMap.wlan[idx].wpaPskType != '2') {
				alert("Only support wireless WPA2+AES");
				return;
			}
		}
	}
	setAppData('save',[0]);
}
var easymesh_list_time = null;
function init_easymesh_list()
{
	if(easymesh_list_time!=null){
		window.clearInterval(easymesh_list_time);
	}

	get_easymesh_list();
	easymesh_list_time = window.setInterval(get_easymesh_list,status_time);
}

function get_easymesh_list()
{
	if($.CurrentApp != "easymesh_list"){
		window.clearInterval(easymesh_list_time);
		return;
	}
	getAppData(function(data){
		var array = new Array();
		var list = $.DataMap.easymesh.child_devices;
		for(var i=0; i < list.length; i++){
			var obj = new Object();
			obj.id = i+1;
			obj.device_name = list[i].device_name;
			obj.ip_addr = list[i].ip_addr;
			obj.mac_address = list[i].mac_address;
			array.push(obj);
		}

		if(getTag(0,0).tab.tbody){
			getTag(0,0).tab.data = array;
			getTag(0,0).tab.tbody.refresh();
		}else{
			getTag(0,0).tab.createTable(array);
		}
	});
}

/************************* APR scan *************************/
function init_apr_scan_tbl()
{
	JQ("[data-toggle='popover']").popover();
	if (typeof(check_login_pwd) != 'undefined')
	{
		JQ('#result_tit').html($.CommonLan['select_ext']);
		JQ('#btn_connect').html($.CommonLan['_extend']);
	} else {
		JQ('#btn_connect').html($.CommonLan['connect']);
	}
	JQ('#btn_refresh').html($.CommonLan['_rescan']);
	JQ('#btn_close').html($.CommonLan['_back']);
}
function Q_connect(){
	if (APRData.length == 0) return;
	var tmp_sec = (APRData[5] == '6')?'4':APRData[5];
	var tmp_secen = '';
	for (let i in secen_map)
		if (APRData[6] == secen_map[i]) tmp_secen = i;
	if (tmp_secen == '3') tmp_secen='2';
	switch($.CurrentApp){
		case 'wan_set_shortcut':
			JQ('#apr_ssid').val(APRData[1]);
			JQ('#encrypt').val(tmp_sec);
			set_radio("wepKeySize",2);
			set_radio("keyFormat",1);
			set_radio("wpaPskType",tmp_secen);
			if (typeof(check_login_pwd) != 'undefined') {
				var band = (parseInt(APRData[3].split(' ')[0],10) <14)?1:0;
				var band_str = (band == 1) ?'_2.4G_EXT':'_5.0G_EXT';
				JQ('#apr_ssid').val(APRData[1]+band_str);
				band_str = (band == 1) ?$.WLang['wlan2']:$.WLang['wlan5'];
				JQ("#l_apr_ssid_tip").html(SpanLang($.WLang['apr_ssid_tip_1'], [band_str]));
				JQ("#s_apr_ssid_tip").html($.WLang['apr_ssid_tip_2'] + APRData[1]);
				JQ("#apr_ssidext_tip").show();
				JQ("#l_apr_ssidext_tip").html(SpanLang($.WLang['apr_ssidext_tip'], [band_str]));
				JQ("#s_apr_pwd_tip").html($.WLang['apr_pwd_tip']);
			}

			apr_hide_clean();
			repeater_sh();
			apr_sec_sel_sh();
			break;
		case 'base':
		case 'base5g':
			getTagDom(0,4,'text').setValue(APRData[1]);
			getTagDom(1,1,'select').setValue(tmp_sec);
			getTag(1,1).data=tmp_sec;
			$.exec(getTag(1,'encrypt').action);

			getTagDom(0,5,'text').setValue(APRData[1]);
			getTagDom(2,1,'select').setValue(tmp_sec);
			getTag(2,1).data=tmp_sec;
			$.exec(getTag(2,'rp_encrypt').action);
			break;
		case 'wan':
			APCHAN = APRData[3].split(' ')[0];
			var band = (parseInt(APCHAN,10) <14)?1:0;
			set_radio("wispWanId",band);
			getTag(2,0).data = 2;
			getTag(2,1).data = tmp_secen;
			getTag(2,2).data = 1;
			getTag(2,3).data = 0;
			set_radio("wepKeySize",2);
			set_radio("wpaPskType",tmp_secen);
			set_radio("wepKeyFormat",1);
			set_radio("wpaPskFormat",0);
			getTag(0,1).data = band;
			getTagDom(1,0,'text').setValue(APRData[1]);
			getTagDom(1,1,'select').setValue(tmp_sec);
			getTag(1,1).data=tmp_sec;
			$.APCHANNEL.channel = APCHAN;
			change_wan_sec_mode(getTag(1,1));
			break;
		default: break;
	}

	JQ('#scan_result').modal('hide');
	JQ("#list_search_result").bootstrapTable('removeAll');
}

function Q_get_ap_info(id){
	var data = SortAPRDataMap[id];
	APRData = [];
	for (let i in data) {
		if (i == 'btn') continue;
		if (i == 'wl_ss_secmo') {APRData.push(JQ('#secmo_'+id).html()); continue;}
		APRData.push(data[i]);
	}
	APRData.unshift(APRData[7]);
	APRData.pop();
	if($.CurrentApp == 'wan_set_shortcut'){
		JQ('#wpaPsk_tip').show();
		JQ('#wepKey_tip').show();
	}
}

function Q_apr_scan(act)
{
	APRData = [];
  (function($) {
	$('.modal-body > .container-fluid').css('margin-top','0');
	$('.modal-body > .container-fluid').css('min-width','0');
  })(jQuery);

	JQ("#list_search_result").bootstrapTable('removeAll');
	JQ("#list_search_result tr:eq(0)").css('display','none');
	JQ("#list_search_result").bootstrapTable('load', '');
	JQ('#records_msg td').html($.CommonLan['msg_search']);
	if (typeof(check_login_pwd) != 'undefined')
		JQ('#records_msg td').prepend('<img id="img_search" src="./images/searching.png"><br />')
	JQ('#records_msg td').append('<br />'+
	'<div class="progress" id="searching_bar">'+
	'  <div class="progress-bar progress-bar-striped progress-bar-animated progress-bar-search" role="progressbar" style="width: 100%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>'+
	'</div>'
	);
	if (act != true)
	{
		JQ('#scan_result').modal('toggle');
		Q_getAPInfo();
	}
}
function Q_getAPInfo(act){
	if (act == true) Q_apr_scan(act);
	var sel = 0;
	var band = $.DataMap.wlanBandMode;
	if($.CurrentApp == 'wan_set_shortcut')
		sel = (band == 2)?parseInt($.DataMap.wl5g_idx):parseInt($.DataMap.wl2g_idx);
	else if($.CurrentApp == "base" || $.CurrentApp=='base5g')
		sel = get_wlan_band();
	else{ //"wan_set"
		if (getTag(0,0).data == '2')
		{
			sel = (band == 2)?parseInt($.DataMap.wl5g_idx):parseInt($.DataMap.wl2g_idx);
		}
	}

	var formData = {
		'wlan_idx_num':sel,
		'wl_link':0
	};
	if ($.Debug == true){
		$.DataMap = debugData;
		setTimeout(function(){
			show_scan($.DataMap.apr_scan);
			JQ("#list_search_result tr:eq(0)").css('display','');
		},1000);
		return;
	}

	if (band == 3 && ($.CurrentApp == 'wan_set_shortcut' || $.CurrentApp == 'wan'))
	{
		ajax_sendRequest("skk_survey",formData,function(data){
			var data2 = data;
			formData.wlan_idx_num = parseInt($.DataMap.wl5g_idx);
			ajax_sendRequest("skk_survey",formData,function(data){
				try{
					var obj = JQ.merge(data2,data)
					show_scan(obj);
					JQ("#list_search_result tr:eq(0)").css('display','');
				}catch(e){
					if (data2){
						show_scan(data2);
						JQ("#list_search_result tr:eq(0)").css('display','');
					} else {
						JQ("#list_search_result tr:eq(0)").css('display','none');
						JQ('#records_msg td').html($.CommonLan['_timeout']);
					}
					//console.log(e)
				};
			});
		});
	} else {
		ajax_sendRequest("skk_survey",formData,function(data){
			try{
				show_scan(data);
				JQ("#list_search_result tr:eq(0)").css('display','');
			}catch(e){
				JQ("#list_search_result tr:eq(0)").css('display','none');
				JQ('#records_msg td').html($.CommonLan['_timeout']);
				//console.log(e)
			};
		});
	}
}

function show_scan(formdata)
{
	var _width = ['5%','50%','100px','100px','10%'];
	var lang_ap_get = eval(Language[$.Language]["network"].wan.ap_get_thead);
	var tit = new Array();
	tit.push(lang_ap_get[0]);
	tit.push(lang_ap_get[1]);
	tit.push(lang_ap_get[5]);
	tit.push(lang_ap_get[7]);
	tit.push($.CommonLan['_select']);
	lang_ap_get = tit;
	
	for(let i=0,d=0;i<lang_ap_get.length;i++,d+=2){
		JQ('#list_search_result tr th div')[d].innerHTML=lang_ap_get[i];
		JQ('#list_search_result tr th')[i].style.width=_width[i];
	}
	var nObj = formdata.sort(function (a, b) {
		var tmpa = parseInt(a.wl_ss_sin.split('%')[0],10);
		var tmpb = parseInt(b.wl_ss_sin.split('%')[0],10);
		return tmpa < tmpb ? 1 : -1;
	});
	var _data = new Array();
	for(let i=0;i<nObj.length;i++){
		let obj = new Object();
		obj2obj(obj,nObj[i]);
		obj.id = i;
		obj.wl_ss_ssid = Base64.decode(obj.wl_ss_ssid);
		let btn = '<input type="radio" name="wlanEnabled_" id='+i+' onclick="Q_get_ap_info(this.id)"/>';
		obj.btn = btn;
		let secmo = (obj.wl_ss_secmo == 0)?'img_unlock':'img_lock';

		var tmpsh ='';
		if (typeof(check_login_pwd) == 'undefined' && secmo == 'img_unlock') {
			tmpsh =' style="display:none"';
		}
		obj.wl_ss_secmo ='<label class="'+secmo+'"' +tmpsh+ '></label>'+
						'<span id="secmo_'+i+'" style="display:none">'+obj.wl_ss_secmo+'</span>';

		obj.wl_ss_secen = secen_map[obj.wl_ss_secen];
		let singnal = parseInt(obj.wl_ss_sin.split('%')[0],10);
		let sinimg = 'signal-4';
		if (singnal <= 25)
			sinimg = 'signal-1';
		else if (singnal > 25 && singnal <=50)
			sinimg = 'signal-2';
		else if (singnal > 50 && singnal <=75)
			sinimg = 'signal-3';
		obj.wl_ss_sin ='<label class="'+sinimg+'"></label>';
		_data.push(obj);
	}
	SortAPRDataMap = _data;
	JQ("#list_search_result").bootstrapTable('load', _data);
}
