var CUS = {
Lang_map:{'0':'BRW','1':'US','2':'ES','3':'PT','4':'FR','5':'IT','6':'DE','7':'PL','8':'NL','9':'TR','10':'RU','11':'CS','12':'TW','13':'CN','14':'KO','15':'UK'},
Lang_map_re:{'Select Language':'0','English':'1','Español':'2','Português':'3','Français':'4','Italiano':'5','Deutsch':'6','Polski':'7','Nederlands':'8','Türkçe':'9','Русский':'10','Čeština':'11','繁體中文':'12','简体中文':'13','한국어':'14','Україна':'15'},
Lang_opt:"['Select Language','English','Español','Português','Français','Italiano','Deutsch','Polski','Nederlands','Türkçe','Русский','Čeština','繁體中文','简体中文','한국어','Україна']"
}

SKK.init({
	emulator:false,
	debug:false,
	language:'US',
	showlang:true,
	lock:true,
	maxLockTime:15,
	cgi_path:'/cgi-bin/',
	menu:ID('menu_layer'),
	content:ID('content_layer'),
	encoding_fieleds:false,
	config:{
		SUPPORT_MOBLIE:1,
		SUPPORT_3g4g:1
	},
	company:{
		name:'Netis',
		url:'http://www.netis-systems.com',
		email:'info@netis-systems.com'
	},
	help:null
},initMenu);
