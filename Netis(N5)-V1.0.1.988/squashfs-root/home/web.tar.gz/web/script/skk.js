var isMobile = false; //initiate as false
var APCHAN = '';
var MOD = "add";
var MODData = '';
var SortAPRDataMap = new Object();
var APRData = new Array();
var JQ = jQuery.noConflict();
jQuery.noConflict();

channel_map = 
[
	[
		[[],[]],
		[[1,2,3,4,5,6,7,8,9,10,11],[]],	//1 FCC	0,1,0
		[[1,2,3,4,5,6,7,8,9,10,11],[]],	//2 IC
		[[1,2,3,4,5,6,7,8,9,10,11,12,13],[]],	//3 ETSI	EU
		[[1,2,3,4,5,6,7,8,9,10,11,12,13],[]],	//4 SPAIN
		[[10,11,12,13],[]],	//5 FRANCE
		[[1,2,3,4,5,6,7,8,9,10,11,12,13,14],[]],	//6 MKK
		[[3,4,5,6,7,8,9,10,11,12,13],[]], //7 ISRAEL
		[[1,2,3,4,5,6,7,8,9,10,11,12,13,14],[]],	//8 MKK1
		[[1,2,3,4,5,6,7,8,9,10,11,12,13,14],[]],	//9 MKK2
		[[1,2,3,4,5,6,7,8,9,10,11,12,13,14],[]],	//10 MKK3
		[[1,2,3,4,5,6,7,8,9,10,11],[]],	//11 NCC (Taiwan)
		[[1,2,3,4,5,6,7,8,9,10,11,12,13],[]], //12 RUSSIAN
		[[1,2,3,4,5,6,7,8,9,10,11,12,13],[]],	//13 CN
		[[1,2,3,4,5,6,7,8,9,10,11,12,13,14],[]],	//14 Global
		[[1,2,3,4,5,6,7,8,9,10,11,12,13],[]],	//15 World_wide
		[[1,2,3,4,5,6,7,8,9,10,11,12,13,14],[]],	//16 Test
		[[],[]], //17 5M10M
		[[1,2,3,4,5,6,7,8,9,10,11],[]], // 18 SG
		[[1,2,3,4,5,6,7,8,9,10,11,12,13],[]], //19 KR
		[[1,2,3,4,5,6,7,8,9,10,11,12,13],[]], //20 DLINK
		[[1,2,3,4,5,6,7,8,9,10,11,12,13],[]], //21 MA
	],
	[
		[[],[]],
		[[36,40,44,48,149,153,157,161,165],[]],	// 1FCC
		[[36,40,44,48,149,153,157,161],[]],	// 2 IC
		[[36,40,44,48],[]],	//3 ETSI
		[[36,40,44,48],[]], //4 SPAIN
		[[36,40,44,48],[]], //5 FRANCE
		[[36,40,44,48],[]],	//6 MKK
		[[36,40,44,48],[]],	//7 ISREAL
		[[34,38,42,46],[]], //8 MKK1
		[[36,40,44,48],[]], //9 MKK2
		[[36,40,44,48],[]], //10 MKK3
		[[56,60,64,149,153,157,161,165],[]], //11 NCC (Taiwan)
		[[36,40,44,48,149,153,157,161,165],[]], //12 RUSSIAN
		[[36,40,44,48,149,153,157,161,165],[]], //13 CN
		[[36,40,44,48,149,153,157,161,165],[]], //14 Global
		[[36,40,44,48,149,153,157,161,165],[]], //15 World_wide
		[[36,40,44,48,52,56,60,64,100,104,108,112,116,120,124,128,132,136,140,144,149,153,157,161,165,169,173,177],[]],	//16 Test mode all channel
		[[146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170],[]], //17 5M10M
		[[36,40,44,48,149,153,157,161,165],[]], //18 SG
		[[36,40,44,48,149,153,157,161,165],[]], //19 KR
		[[149,153,157,161],[]], //20 DLINK
		[[36,40,44,48],[]], //21 MA
	]
];
var CH_40m = [36, 44, 52, 60, 100, 108, 116, 124, 132, 140, 149, 157, 165, 173];
var CH_80m = [36, 52, 100, 116, 132, 149, 165];
var wl_currApp = {'0':['base','wds','wl_mac_filter','wps','advance','multiple_ssid'] ,'1':['base5g','wds5g','wl_mac_filter5g','wps5g','advance5g','multiple_ssid5g']};
var run_callback = ['backup','default','reboot','diagnostic'];

(function(window){
var document = window.document,
	navigator = window.navigator,
	location = window.location;
	CurrIP = window.location.protocol+'//'+window.location.host;
	brwlang = (navigator.language || navigator.browserLanguage).toUpperCase();
var SKK = {
	CGI_MOUDLE:{},
	APCHANNEL:{channel:0,channel5g:0},
	WLANZMODE:'1',
	ContentLayer:{},
	MenuLayer:{},
	HelpLayer:{},
	CurrentModule:{},
	CurrentApp:{},
	CurrentData:{},
	MessagePanel:{},
	Debug:false,
	Refresh:function(){
		$.load($.CurrentApp);
	},
	WRefresh:function(){
		window.location.reload();
	},
	BrowserVersionArray:[
		{str:"MSIE 7.0",type:"IE7"},
		{str:"MSIE 8.0",type:"IE8"},
		{str:"MSIE 9.0",type:"IE9"},
		{str:"MSIE 10.0",type:"IE10"},
		{str:"rv:11.0) like Gecko",type:"IE11"},
		{str:"Firefox",type:"Firefox"},
		{str:"Chrome",type:"Chrome"},
		{str:"Safari",type:"Safari"},
		{str:"Opera",type:"Opera"}
	],
	IFLock:{},
	BrowserVersion:{},
	Modules:{},
	Apps:{},
	Language:"US",
	after_map:"US",
	PATH:"",
	FLAG:false,
	DataMap:{},
	SPDataMap:{},
	Log:{},
	CommonLan:{},
	WLang:{},
	LLang:{},
	getLan:function(name){
		return $.Apps[$.CurrentApp].Lan[name];
	},
	debug:function(n,o){
		var ret = true;
		if(o == undefined){
			ret = $.showDebug(n);
		}
		return ret;
	},
	showDebug:function(s){
		if($.Debug){
			alert(s);
		}
		return false;
	},
	exec:function(fname,data){
		if(!fname){
			return;
		}
		try{
			return eval(fname + "(data)");
		}catch(e){
			$.showDebugErr(fname + ' is undefined! 请检查你的action.js中' + fname + '函数是否定义！');
		}
	},
	showDebugErr:function(msg){
		if($.Debug){
			$.Debug.showErr(msg);
		}
	},
	load:function(name,callback,menu){
		$.ContentLayer.innerHTML = " ";
		$.initPage(name,menu);
		setArgMenu(name);
		AJAX_STATUS = false;
//		debug_multi_single();	//SJ
		if(callback){
			callback();
		}
	},
	lang:function(name,callback,menu){
		$.MenuLayer.innerHTML = '';
		$.Language = ($.ShowLang)?CUS.Lang_map[menu]:'US';
		$.after_map = ($.ShowLang)?CUS.Lang_map[menu]:'US';
		initLanguage(($.ShowLang)?CUS.Lang_map[menu]:'US');
		menu_n.init();
		setArgMenu(name);
		//hideMenu($.DataMap);
	},
	ready:function(){

	},
	init:function(param,callback){
		$.Emulator = param.emulator;
		$.Debug = param.debug;
		$.DeLanguage = param.language;
		$.IFLock = param.lock;
		$.MaxLockTime = param.maxLockTime;
		$.PATH = param.cgi_path;
		$.ContentLayer = param.content;
		$.MenuLayer = param.menu;
		$.HelpLayer = param.help;
		$.ShowLang = param.showlang;
		$.EncodingF = param.encoding_fieleds;
		$.CO = param.company;
		initBrowser(navigator.userAgent,$.BrowserVersionArray);
		if($.Debug) {
			var winaddr = window.location.pathname.split('/');
			CurrIP += '/'+winaddr[1];
			if (winaddr[2] == '')
			window.location.href = CurrIP + '/index.htm';
		}
		for(var i in param.config){
			$[i] = param.config[i];
		}
		if($.MenuLayer)
			ajax_get_lang("./script/debug.js");
		if(!initConfig()){
			return;
		};

		if(callback){
			getAppData(function(data){
				if($.MenuLayer) display_lang_sel(data);
				var sys_lang = data.language;
				if (data.language == '0')
					sys_lang = lang_str_mapping(brwlang);

				var use = !$.ShowLang?param.language:CUS.Lang_map[sys_lang];
				$.Language = use
				$.after_map = use;
				initLanguage(use);

				if (typeof(set_appname) != 'undefined') {
					init_welcome();
				} else if($.CurrentApp != 'wan_set_shortcut') callback(true);
			});
		}
	},
	initPage:function(name,menu){
		if(menu){
			$.MenuLayer.innerHTML = '';
			$.Language = ($.ShowLang)?CUS.Lang_map[menu]:'US';
			$.after_map = ($.ShowLang)?CUS.Lang_map[menu]:'US';
			initLanguage(($.ShowLang)?CUS.Lang_map[menu]:'US');
			menu_n.init();
			hideMenu($.DataMap);
		}
		if($.HelpLayer){
			initHelp(name);
		}
		$.CGI_MOUDLE = {};
		var Pans = $.Apps[name].Pans;
		var tempTag = new Array();
		for(var i in Pans){
			if(checknobj(i)){
				continue;
			}
			var panel = InitAppPanel(Pans[i]);
			obj2obj(Pans[i],panel);
			panel.showIn($.ContentLayer);
			var Tags = Pans[i].Tags;
			for(var j in Tags){
				if(checknobj(j)){
					continue;
				}
				if(j=="key_wpa")
					j="key_wpa";
				var tag = InitAppTag(Tags[j]);
				if(!tag){
					tag = new DefaultTag(Tags[j]);
					tag.html('<div style="color:red">[ initPage ]tag:'+Tags[j].name +' init error!</div>');
					tag.showIn(panel.children[1].entity);
					continue;
				}
				if(!$.debug(Tags[j].name + "init failed!--[initPage]",tag)){
					panel.children[1].html('<div style="color:red">[ initPage ]tag:'+Tags[j].name +' init error!</div>');
					continue;
				}
				tag.showIn(panel.children[1].entity);
				if(tag.display == '0'){
					tag.hide();
				}
				tempTag.push(tag);
			}
		}
		var Len = getLen();
		if(Len=='0'){
			getAppData(function(){
				initAppFunction(tempTag,name);
			});
			return;
		}
		initAppFunction(tempTag,name);
		initSliderFunction(tempTag,name);
		init_version();
		before_func_init();
	},
	HelpMore:{},
	Lock:{},
	LockInterver:{},
	LockTime:0,
	MaxLockTime:null,
	lockWin:function(msg,type,countonly,iswelcome){
		Scroll_ST = false;
		scroll_type(Scroll_ST);
		window.document.body.scrollTop = 0;
		if(!$.IFLock){
			return;
		}
		if(!$.Lock.bg){
			var lock_bg = new Element("DIV:df_lock_bg");
			lock_bg.setID("lock_bg");
			document.body.appendChild(lock_bg.entity);
			$.Lock.bg = lock_bg;
		}
		var height = document.documentElement.scrollHeight;
		var width = screen.width;
		var scrollY = 0;
		if (document.documentElement && document.documentElement.scrollTop){
			scrollY = document.documentElement.scrollTop;
		}
		$.Lock.bg.entity.style.top = scrollY + "px";
		$.Lock.bg.entity.style.height = height + "px";
		$.Lock.bg.entity.style.width = width + "px";

		if(!$.Lock.load){
			var lock_load = new Element("DIV:df_lock_load");
			lock_bg.setID("lock_load");
			document.body.appendChild(lock_load.entity);
			$.Lock.load = lock_load;
		}
		if(type){
			$.Lock.load.entity.style.width = '200px';
		}else{
			$.Lock.load.entity.style.width = '180px';
			$.Lock.load.entity.style.minWidth = '180px';
		}
		$.Lock.load.entity.style.left = (parseInt((document.body.offsetWidth),10)/2 - 100) + 'px';
		$.Lock.load.entity.style.top =(200 + scrollY) +'px';
		$.Lock.load.html(msg);

		$.Lock.bg.show();
		$.Lock.load.show();
		if ($.Debug)
		{
			if (!$.Emulator) { $.unlockWin(); return;}
			else {
				if (msg == " " || msg == $.CommonLan['msg_search'])
				{
					var close = new Element("DIV:df_h_close");
					close.entity.onclick = function(){
						$.unlockWin();
					}
					$.Lock.load.append(close);
					return;
				}
				if(!msg){
					$.Lock.load.hide();
					return;
				}

				$.LockTime = 0;
				var timeoutID_emu = "";
				clearTimeout(timeoutID_emu);
				timeoutID_emu = setTimeout(function(){emu_countdown(msg);},1000);
			}
			return;
		}

		var lock_time = (typeof(countonly) != "undefined") ? countonly : 58;
		if(!type && msg){
		$.LockInterval = window.setInterval(function(){
			if($.LockTime < lock_time){
				var dispmsg = msg;
/* 				if (typeof(countonly) != "undefined") {
					if ($.LockTime % 2 == 0 && $.CurrentApp == 'lan')
						$.exec($.Apps[$.CurrentApp].init);
						//console.log($.LockTime);
				} else {
					dispmsg += ":"+ $.LockTime + ' ' + $.CommonLan['seconds'];
				} */
				dispmsg += ":"+ $.LockTime + ' ' + $.CommonLan['seconds'];
				$.Lock.load.html(dispmsg);
				$.LockTime += 1;
			}else{
				window.clearInterval($.LockInterval);
				if (typeof(countonly) != "undefined")
					$.unlockWin($.CommonLan['_save_success']);
				else
					$.unlockWin($.CommonLan['_timeout']);
			}
		},1000);
			} else if (type !== 'autoFW') {
			var close = new Element("DIV:df_h_close");
			close.entity.onclick = function(){
				$.unlockWin();
			}
			$.Lock.load.append(close);
		}
		if(!msg){
			$.Lock.load.hide();
		}
	},
	unlockTimeOut:null,
		unlockWin: function (msg, flag, time) {
		Scroll_ST = true;
		scroll_type(Scroll_ST);
		if(!$.IFLock){
			return;
		}
		$.LockTime = 0;
		window.clearInterval($.LockInterval);
		(flag)?$.Lock.win.html(msg):$.Lock.load.html(msg);
		//$.HelpMore.splice(0,$.HelpMore.length);
		$.HelpMore = {};
		if(!msg){
			$.Lock.bg.hide();
			$.Lock.load.hide();
			return;
		}
			time = (typeof (time) === 'undefined') ? 1000 : time;
		$.unlockTimeOut = window.setTimeout(function(){
			if(flag){
				$.Lock.win.hide();
			}else{
				$.Lock.bg.hide();
				$.Lock.load.hide();
			}
		},1000);
	},
	Drag:function(obj,e,fun){
		if($.BrowserVersion.toString().indexOf('IE') != -1){
			var e = window.event;
		}
		var l = e.clientX;
		var t = e.clientY; 
		var e_top = parseInt(obj.style.top);
		var e_left = parseInt(obj.style.left);
		document.onmousemove = function(){
			var e = arguments[0]||window.event;
			var _l = e.clientX;
			var _t = e.clientY;
			var left = _l-l;
			var top = _t - t;
			var _top = e_top + top + "px";
			var _left = e_left + left + "px";
			obj.style.top = _top;
			obj.style.left = _left;
			if(fun != undefined){
				fun();
			}
		}
	}
};

var initAppFunction = function(tempTag,name){
	try{
		if($.DataMap){
			$.CurrentData = $.DataMap;
		}else{
			if($.Apps[name].request){
				for(var i in tempTag){
					tempTag[i].bindFun();
				}
				$.exec($.Apps[name].init);
				return;
			}
			getAppData(function(data){
				$.DataMap = data;
				for(var i in tempTag){
					tempTag[i].bindFun();
				}
				$.exec($.Apps[name].init);
			});
		}
	}catch(e){
		$.CurrentData = null;
	};

	for(var i in tempTag){
		if(tempTag[i] != null)
			tempTag[i].bindFun();
	}
	$.exec($.Apps[name].init);
	MOD = "add";
}
var initBrowser = function(s,br){
	for(var i=0;i<br.length;i++){
		if(s.indexOf(br[i].str)!=-1){
			$.BrowserVersion = br[i].type;
			break;
		}
	}
};
var initLanguage = function(lan){
	lang_import(lan);
	var Lan = Language[lan];
	for(var i in Lan){
		if(i == "common"){
			obj2obj($.CommonLan,Lan[i]);
			continue;
		}
		if(i == "welcome"){
			obj2obj($.WLang,Lan[i]);
			continue;
		}
		if(i == "network"){
			obj2obj($.LLang,Lan[i]);
		}
		for(var j in Lan[i]){
			if(!$.Modules[i]){
				continue;
			}
			if(j == "txt"){
				$.Modules[i].Lan = {};
				$.Modules[i].Lan.txt = Lan[i][j];
			}else{
				if(!$.Apps[j]){
					continue;
				}
				$.Apps[j].Lan = {};
				obj2obj($.Apps[j].Lan,Lan[i][j]);
			}
		}
	}
	setMapLang();
};
var setArgMenu = function(n){
	var arr = ["p_menu_qos",
				"p_menu_forward",
				"p_menu_management",
				"p_menu_ddns",
				"p_menu_advanceSetup",	//5
				"c_menu_lan",
				"c_menu_wan",
				"c_menu_address_reservation",
				"c_menu_iptv",
				"c_menu_remote",	//10
				"c_menu_access",
				"p_menu_tr069_config",
				"p_menu_ipv6",
				"c_menu_modem"
			];
	var easymeshAgentArr = [
				"p_menu_network",
				"p_menu_wireless",
				"p_menu_wireless5g",
				"c_menu_easymesh_list",
				"c_menu_lan",
				"p_menu_wireless5g",
				"p_menu_wireless"
		];
	var easymeshArr = [
				"c_menu_wl_mac_filter",
				"c_menu_wl_mac_filter5g",
				"c_menu_multiple_ssid",
				"c_menu_multiple_ssid5g"
		];
	additionalData();

	var band = parseInt($.DataMap.wlanBandMode);
	if (band & 1) {
		var data2 = $.DataMap.wlan[$.DataMap.wl2g_idx];
		var flag = (data2.wlanMode=='1' || data2.wlanMode =='5')?'none':'block';
		ID("c_menu_wps").style.display = flag;
	}
	if (band & 2) {
		var data5 = $.DataMap.wlan[$.DataMap.wl5g_idx];
		var flag = (data5.wlanMode=='1' || data5.wlanMode =='5')?'none':'block';
		ID("c_menu_wps5g").style.display = flag;
	}
	if(band != 3) {
		$.Apps["status"].Pans["status_wireless5g"].hide();
	}
	if(band == 1) {
		hideMenu(["p_menu_wireless5g"],1);
	}
	if(band == 2) {
		hideMenu(["p_menu_wireless"],1);
	}

	if($.DataMap.opMode=='1' && $.SUPPORT_MULTI_WAN != 1){ //Bridge
		hideMenu(arr,1);
		if($.CurrentApp=="status"){
			getPan(2).hide();
			getPan(1).hide();
			getPan(0).hide();
			$.Apps["status"].Pans["modemList"].hide();
		}
	}else{
		hideMenu(arr,0);
		if($.CurrentApp=="status"){
			if ($.SUPPORT_MULTI_WAN == 1) {getPan(0).hide(); getPan(1).hide(); getPan(2).hide(); getPan(6).show();}
			else {getPan(2).show(); getPan(6).hide();}
			getPan(3).show();
		}
	}
	if ($.SUPPORT_3g4g != 1){
		hideMenu(["c_menu_modem"],1);
		$.Apps["status"].Pans["modemList"].hide();
	}
	if (isMobile == true && $.SUPPORT_MOBLIE == 1 && JQ.cookie('AccFrom') != 1) acc_terminal();
	if ($.SUPPORT_MULTI_WAN == 1)
	{
		hideMenu(["c_menu_wan"],1);
		hideMenu(["c_menu_opmode"],1);
		hideMenu(["c_menu_ipv6_configure"],1);
	} else
		hideMenu(["c_menu_eth_wan"],1);
	
	//如果等于土耳其版本
	if($.DataMap.config_name=="TURKISH_SEGMENT_ISP"){
		if($.DataMap.firstSetup==1 && $.DataMap.superlogin==0){
			hideMenu(["c_menu_wan"],1);
		}
	}else{
		hideMenu(["c_menu_sign_out"],1);
	}
	
	if (typeof($.DataMap.mapController) == 'string') {
		if($.DataMap.mapController != '0') hideMenu(easymeshArr,1);
		else hideMenu(easymeshArr,0);
		
		if($.DataMap.mapController == '2') hideMenu(easymeshAgentArr,1);
		else hideMenu(easymeshAgentArr,0);
	}
};
var initHelp = function(app){
	var layer = $.HelpLayer;
	layer.innerHTML = '';
	var help = Help[app];
	if(!help){
		return;
	}
	for(var i=0;i<help.length;i++)
	{
		var title = help[i].title;
		var context = help[i].context;
		var tpanel = new Element("DIV:df_h_tpanel");
		tpanel.html(title);
		var cpanel = new Element("DIV:df_h_cpanel");
		cpanel.html("&nbsp;&nbsp;&nbsp;&nbsp;" + context);
		layer.appendChild(tpanel.entity);
		var clear = new Element("DIV:clear");
		layer.appendChild(clear.entity);
		layer.appendChild(cpanel.entity);
		if(!help[i].more){
			continue;
		}
		var mbtn = new Element("DIV:df_h_mbtn");
		mbtn.setID(i);
		mbtn.html($.CommonLan['help_more_btn']);
		layer.appendChild(mbtn.entity);
		mbtn.entity.onclick = function(){
			if(!help[this.id].more){
				help[this.id].more = $.CommonLan['help_more_null'];
			}else{
				$.HelpMore[this.id] = createMoreHelpContent(help[this.id].more);
			}
			$.lockWin($.HelpMore[this.id],true);
		}
	}
};
var createMoreHelpContent = function(m){
	var rows = m.split('#');
	if(rows.length <= 1){
		return m;
	}
	var layer = document.createElement("DIV");
	var table = document.createElement("TABLE");
	table.className = 'more_h_table';
	table.setAttribute("cellspacing","1");
	table.setAttribute("cellpadding","3");
	for(var i=1;i<rows.length;i++){
		var row = document.createElement("TR");
		var cells = rows[i].split('-');
		var head= document.createElement("TD");
		head.className = "more_h_head";
		head.innerHTML = cells[0];
		var content= document.createElement("TD");
		content.className = "more_h_content";
		if(i == rows.length-1){
			content.className = "more_h_content_after";
		}
		content.innerHTML = cells[1];
		row.appendChild(head);
		row.appendChild(content);
		table.appendChild(row);
	}
	layer.appendChild(table);
	return layer.innerHTML;
};
var initConfig = function()
{
	$.Modules.len = 0;
	$.Apps.len = 0;
	for(var i=0;i<Modules.length;i++){
		initModule(Modules[i]);
	}
	for(var i in Applications){
		if(!$.Modules[i]){
			continue;
		}
		if(!Applications[i].length){
			initApp(i,Applications[i]);
			continue;
		}
		for(var j=0;j<Applications[i].length;j++){
			initApp(i,Applications[i][j]);
		}
	}
	for(var i in Panels){
		if(!$.Apps[i]){
			continue;
		}
		for(var j=0;j<Panels[i].length;j++){
			var pan = initPanel(i,Panels[i][j]);
			for(var k=0;k<pan.tags.length;k++){
				initTag(pan,pan.tags[k]);
			}
		}
	}
	return true;
};
var initSliderFunction = function(tempTag,name){
	for(var i in tempTag){
		if ( tempTag[i].type == "simple_slider" ) {
		  (function($) {
			$(function() {
				var name = tempTag[i].name;
				if (name.indexOf('update_time') != -1) {
					$("#" + name + "_slider").slider({
						//orientation: "horizontal",
						value: tempTag[i].data,
						min: 100,
						max: 9000,
						step: 10,
						slide: function(event, ui) {
							show_slider_value(tempTag, name, ui);
						}
					});
				} else if (name.indexOf('ack_timeout') != -1) {
				$("#" + name + "_slider").slider({
					value: tempTag[i].data,
					min: 0,
					max: 255,
					step: 1,
					slide: function(event, ui) {
						show_slider_value(tempTag, name, ui);
					}
				});
				} else if (name.indexOf('rfPower') != -1) {
					$("#" + name + "_slider").slider({
						value: tempTag[i].data,
						min: 1,
						max: 100,
						step: 1,
						slide: function(event, ui) {
							show_slider_value(tempTag, name, ui);
						}
					});
				}
			});
		  })(jQuery);
		}
	}
};
function show_slider_value(tempTag, name, ui){
	for(var i in tempTag){
		if ( tempTag[i].type == "simple_slider" && tempTag[i].name == name ) {
			JQ("#"+ tempTag[i].name + "_t").val(ui.value);
		}
	}
};
function Module(m){
	this.name = m.name;
	this.mode = m.mode;
	this.Apps = {};
	this.Apps.len = 0;
	$.Modules.len += 1;
}
function App(n,a){
	this.name = a.name;
	if(a.request){
		this.request = a.request;
	}
	if(a.init){
		this.init = a.init;
	}
	this.parent = $.Modules[n];
	this.Pans = {};
	this.Pans.len = 0;
	$.Modules[n].Apps.len += 1;
	$.Apps.len += 1;
}
function Panel(n,p){
	this.name = p.name;
	this.type = p.type;
	this.parent = $.Apps[n];
	this.tags = p.tags;
	this.Tags = {};
	this.Tags.len = 0;
	if(p.display){
		this.display = p.display;
	}
	$.Apps[n].Pans.len += 1;
}
function Tag(p,t){
	this.name = t.name;
	this.type = t.type;
	this.mode = t.mode;
	this.tag = t.tag;
	if(t.len){
		this.len = t.len;
	}
	if(t.key){
		this.key = eval(t.key);
	}
	if(t.value){
		this.value = eval(t.value);
	}
	if(t.init){
		this.init = t.init;
	}
	if(t.action){
		this.action = t.action;
	}
	if(t.df){
		this.df = t.df;
	}
	if(t.check){
		this.ch_key = t.check;
	}
	if(t.display){
		this.display = t.display;
	}
	if(t.value2){
	
	  this.value2 = t.value2;
	}
	if(t.wisp){
	
	  this.wisp = t.wisp;
	}
	if(t.width){
		this.width=t.width;
	}
	if(t.split){
		this.split = t.split;
	}
	if(t.rows){
		this.rows = t.rows;
	}
	this.parent = p;
	p.Tags.len += 1;
}
var initModule = function(m){
	var len = $.Modules.len;
	$.Modules[m.name] = $.Modules[len] = new Module(m);
};
var initApp = function(n,a){
	var len = $.Modules[n].Apps.len;
	$.Modules[n].Apps[a.name] = $.Modules[n].Apps[len] = $.Apps[a.name] = $.Apps[$.Apps.len] = new App(n,a);
};
var initPanel = function(n,p){
	var len = $.Apps[n].Pans.len;
	return $.Apps[n].Pans[p.name] = $.Apps[n].Pans[len] = new Panel(n,p);
};
var initTag = function(p,t){
	var len = p.Tags.len;
	p.Tags[t.name] = p.Tags[len] =	new Tag(p,t);
};
window.$n = (function(selector){
	var match,
	quickExpr = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/;
	if(typeof selector === "string"){
		if(selector.charAt(0) === "<" && selector.charAt( selector.length - 1 ) === ">" && selector.length >= 3 ){
			match = [ null, selector, null ];
		} else {
			match = quickExpr.exec(selector);
		}
		if(match){
			if(match[1]){
			}else{
				return document.getElementById(match[2]);
			}
		}
	}
});
window.SKK = window.$ = SKK;
})(window);

function additionalData()
{
	$.DataMap.wispWanId = ($.DataMap.wlanBandMode == 1)?1:0;
	if ($.DataMap.wan[0].type == 0) {
		$.DataMap.opMode = 1;
		$.DataMap.wispWanId = ($.DataMap.wlan[parseInt($.DataMap.wl2g_idx)+5].wlanEnabled == "1")?1:0;
	}
	else {
		$.DataMap.opMode = 0;
		if ($.DataMap.wan[0].ifidx =='8') {
			$.DataMap.opMode = 2;
			$.DataMap.wispWanId = ($.DataMap.wan[0].ifIndex & 0xf00)?1:0;
		}
	}
}
function reloadDebug(callback)
{
	var src = "./script/debug.js"
	JQ('script[src="' + src + '"]').remove();
	JQ('<script>').attr('src', src).appendTo('head');
	if ($.CurrentApp == "sys_log" || $.CurrentApp == "diagnostic")
		$.SPDataMap = debugData;
	else {
		$.CurrentData = debugData;
		$.DataMap = debugData;
	}
	if ($.SUPPORT_MULTI_WAN != 1) comb_wan_type();
	if(callback) callback(debugData);
}
var getAppData = function(callback,is_sync){
	if($.Debug){
		reloadDebug(callback);
		return;
	}

	var param = new Object();
	param = {"wl_link":"0"};
	if ($.CurrentApp == "sys_log" || $.CurrentApp == "diagnostic")
		param.app = $.CurrentApp;
	is_sync = (typeof(is_sync) != 'undefined')? is_sync:false;
	ajax_sendRequest("skk_get",param,function(data){
		if(callback){callback(data);}
	},is_sync);
};

var ajax_time = null;
var setAppData = function(type,obj,callback){
	AJAX_STATUS = false;
	if($.Debug){
		if(obj.length){
			var parame = getSubmitData(obj);
		}else{
			var parame = obj;
		}
		if($.DataMap.firstSetup==0){
			parame.firstSetup=1;
		}
		obj2obj(parame, $.CGI_MOUDLE);

		if(callback){ callback();}
		if (!$.Emulator) { testInfo(parame); return;}
		else {
			if (type != null)
				$.lockWin($.CommonLan['lock_save']);
			return;
		}
	}
	switch(type){
		case null:
		case 'pwd': break;
		case 'add':
		case 'delete': $.lockWin($.CommonLan['lock_' + type]); break;
		case 'lang': $.lockWin($.CommonLan['lock_save'],'',1); break;
		default: $.lockWin($.CommonLan['lock_save']); break;
	}

	try{
		if(obj.length){
			var parame = getSubmitData(obj);
		}else{
			var parame = obj;
		}
		if($.DataMap.firstSetup==0){
			parame.firstSetup=1;
		}
		
		obj2obj(parame, $.CGI_MOUDLE);
		obj2obj(parame,{"app":$.CurrentApp,"wl_link":"0"});
		$.CGI_MOUDLE = {};
		ajax_sendRequest("skk_set",parame,function(data){
			for (let i in run_callback)
			{
				if ($.CurrentApp == run_callback[i] && callback) {
					callback(data);
					return;
				}
			}
			if ($.CurrentApp == 'wan_set_shortcut') {
				if (type == 'quick_f')
				{
					if (rp_password_times != 'undefined')
						rp_password_times = 0;
					if (typeof(check_login_pwd) != 'undefined' && get_radio_val("apr_mode") == 20) {
						check_rp_password();
					} else {
						Q_finish();
						$.unlockWin($.CommonLan['_save_success']);
					}
				}else if(type != 'lang')
					$.unlockWin($.CommonLan['_save_success']);
				return;
			}
			if ($.CurrentApp == 'passwd') {
				$.unlockWin($.CommonLan['_save_success']);
				$.Refresh();
				return;
			}
			if (typeof(data) != "undefined")
			{
				if (type != null && type != 'lang' && type != 'pwd') {
					if (callback) callback();
					let ref_time = 2000;
					if(ajax_time != null){
						window.clearInterval(ajax_time);
					}
					ajax_time = window.setInterval(function(){
						window.clearInterval(ajax_time);
						AJAX_STATUS = false;
						getAppData(function(){},true);
					},ref_time);
				}
			} else {
				$.unlockWin($.CommonLan['unlock_error']);
			}
		});
	}catch(e){
		$.unlockWin($.CommonLan['unlock_error']);
	}
};

function imgError(image){
	JQ(image).hide();
}
function setMapLang()
{
	proto_map_ipv4 = {'3':$.CommonLan["all"], '1':"TCP", '2':"UDP",'4':"ICMP"};
	proto_map = {'3':$.CommonLan["all"], '1':"TCP", '2':"UDP",'5':"ICMPv6"};
	protoval_map = {"TCP":1,"UDP":2,"ICMP":4};
	protoval_map[$.CommonLan["all"]] = 3;
}
function break_row(str,len){
	var temp_str="",n=1;
	if(str.length<=len)
	{
		temp_str=str;
	}
	else
	{
		var temp_arr=new Array();
		for(var i=0;i<str.length;i++)
		{
			temp_arr[i]=str.charAt(i);
			if(n%len==0){
				temp_arr[i]=temp_arr[i]+"<br>";
			}
			n++;
			temp_str +=temp_arr[i];
		}
	}
	return temp_str;
}

function get_err_map(str){ //msg from Cgi_info
	switch(str){
		case "The item is already exist !":return "item_exist";
		default:return "unlock_error";
	}
}

/*公共函数部分*/
var obj2obj = function(a,b){
	for(var i in b){
		a[i] = b[i];
	}
	for(var i in a){
		b[i] = a[i];
	}
};
var checknobj = function(str){
	if(str == "len"){
		return true;
	}
	var count = 0;
	var cmp = "0123456789";
	for(var i=0;i<str.length;i++){
		var num = str.substring(i,i+1);
		if(cmp.indexOf(num) >= 0){
			count +=1;
		}
	}
	if(count == str.length){
		return true;
	}
	return false;
};
function Element(type,params,t){
	var _this = this;
	var st = type.split(':')[1];
	if(t && t.type.indexOf('radio') != -1 && ($.BrowserVersion.toString().indexOf("IE7") != -1)){
		this.entity = document.createElement('input');
		this.entity.type = "radio";
		this.entity.name = t.name;
	}else{
		this.entity = (type.split(':').length > 1)?createByTag(type.split(':')[0]):createByTag(type);
	}
	this.children = new Array();
	this.parent = {};
	this.setClass = function(classname){
		_this.entity.className = classname;
	}
	this.setAttr = function(parame){
		for(var i in parame){
			_this.entity.setAttribute(i,parame[i]);
		}	
	};
	this.set = function(o){
		var cs = o.css;
		var h = o.html;
		if(cs){
			for(var i in cs){
				_this.entity.style[i] = cs[i];
			}
		}
		if(h){
			_this.html(h);
		}
	}
	this.setName = function(name){
		_this.entity.setAttribute("name",name);
		_this.Name = name
	}
	this.setID = function(id){
		_this.entity.setAttribute("id",id);
		_this.ID = id;
	}
	this.setValue = function(val){
		this.entity.value = val;
		this.value = val;
	}
	this.append = function(child){
		this.entity.appendChild(child.entity);
		this.children.push(child);
		child.parent = this;
	}
	this.push = function(){
		var eles = arguments;
		for(var i=0;i<eles.length;i++){
			this.append(eles[i]);
		}
	};
	this.html = function(inner){
		_this.entity.innerHTML = inner;
	}
	this.show = function(){
		if(this.display == '0'){
			return;
		}
		_this.entity.style.display = "block";
	}
	this.hide = function(){
		_this.entity.style.display = "none";
	}
	this.showIn = function(dom){
		dom.appendChild(this.entity);
		this.parent = parent;
	}
	this.bindFun = function(){
		initBindFunction(_this);
		if(_this.init){
			$.exec(_this.init,_this);
		}
	}
	if(params){
		obj2obj(this,params);
	}
	if(st){
		_this.setClass(st);
	}
};
function initBindFunction(ele){
	if(ele.eleType == "tag"){
		switch(ele.type){
			case "simple_context": initSimpleContextFunction(ele);break;
			case "simple_context_encode": initSimpleContextFunction(ele);break;
			case "simple_text": initSimpleTextFunction(ele);break;
			case "simple_text_encode": initSimpleTextFunction(ele);break;
			case "simple_wifi_pwd": initSimpleTextFunction(ele);break;
			case "simple_pwd": initSimpleTextFunction(ele);break;
			case "simple_select": initSimpleSelectFunction(ele);break;
			case "radio_group": initRadioGroupFunction(ele);break;
			case "simple_file": initSimpleFileFunction(ele);break;
			case "simple_slider": initSimpleTextFunction(ele);break;
			case "simple_host": initSimpleSelectFunction(ele);break;
			case "simple_host6": initSimpleSelectFunction(ele);break;
			case "simple_context_text": initSimpleTextFunction(ele);break;
			default:break;
		}
	}
}
function InitAppPanel(pan){
	switch(pan.type){
		case 0: return initDefaultPanel(pan); break;
		default: break;
	}
}
function DefaultSlider(tag){
	Element.call(this,"DIV:df_slider");
	var _this = this;
	this.tag = tag;
	_this.setID(tag.name + "_slider");
	_this.setClass("df_bar_slider");
}
function DefaultSpan(tag){
	Element.call(this,"SPAN");
	var _this = this;
	this.tag = tag;
	this.setData = function(val){
		if(val){
			this.html(val);
			_this.tag.data = val;
		}
	};
}
function DefaultLabel(tag,sp,type){
	if (type == 'shbtn')
		Element.call(this,"LABEL:switch-btn");
	else {
		Element.call(this,"LABEL:df_label");
		var lab = $.getLan(tag.name + "_label");
		if(!lab){
			lab = "<span style='color:red'>" + tag.name + " - Failed to create structure label</span>"
		}
		if (sp == "sp")
			this.html("");
		else
			this.html(lab + " :");
		if(tag.tag == 'ipv6')
			this.entity.style.width = "280px";
	}
}
function DefaultInput(tag,type,tt){
	if(!tag){
		tag = new DefaultTag();
		tag.type = tt;
	}
	Element.call(this,"INPUT",null,tag);
	var input = this;
	input.tag = tag;
	if (type == "slider")
		this.entity.type = "text";
	else if (type == "showhidebtn")
		this.entity.type = "checkbox";
	else
		this.entity.type = type;
	switch(type){
		case "hidden":
			input.setValue = function(val){
				if(val){
					input.entity.value = val;
					input.tag.data = val;
				}
			}
			break;
		case "text":
			input.setClass("df_text");
			if(input.tag.len){
				input.entity.maxLength = input.tag.len;
			}
			if(input.tag.ch_key){
				input.setName(input.tag.ch_key);
			}else{
				input.setName("text_common");
				input.tag.ch_key = "text_common";
			}
			input.setID(tag.name + "_t");
			input.getCheck = function(type){
				if(!type){
					type = input.tag.ch_key;
				}
				return checkText(input,type);
			}
			input.setValue = function(val){
				if(typeof(val) != "undefined"){
					input.entity.value = val;
					input.tag.data = val;
				}
			}
			input.setData = function(val){
				input.setValue(val);
				input.tag.data = val;
			};
			input.entity.onkeyup = function(){
				input.tag.data =this.value;
				//setCurrentData(this.value,input.tag.name);
				$.CurrentData[tag.name] = this.value;
			}
			input.entity.onfocus = function(){
				this.style.border = "solid 1px #8fc7fa";
				if(this.value == ' '){
					this.value = this.value.replace(/^\s+|\s+$/g,'');
					input.tag.data = this.value;
				}
			}
			input.entity.onblur= function(){
				this.style.border = "solid 1px #d2d2d2";
			}
			break;
		case "password":
			input.tag.data = "";
			input.entity.value = "";
			input.setClass("df_text");
			if(input.tag.len){
				input.entity.maxLength = input.tag.len;
			}
			if(input.tag.ch_key){
				input.setName(input.tag.ch_key);
			}else{
				input.setName("text_common");
				input.tag.ch_key = "text_common";
			}
			input.setID(tag.name);
			input.getCheck = function(type){
				if(!type){
					type = input.tag.ch_key;
				}
				return checkText(input,type);
			}
			input.setValue = function(val){
				if(typeof(val) != "undefined"){
					input.entity.value = val;
					input.tag.data = val;
				}
			}
			input.setData = function(val){
				if(typeof(val) != "undefined"){
					input.setValue(val);
					input.tag.data = val;
				}
			};
			input.entity.onkeyup = function(){
				input.tag.data =this.value;
			}
			input.entity.onfocus = function(){
				this.style.border = "solid 1px #8fc7fa";
			}
			input.entity.onblur= function(){
				this.style.border = "solid 1px #d2d2d2";
			}
			break;
		case "radio":
			input.setName(tag.name);
			input.setClass("df_radio");
			input.entity.onclick = function(){
				input.checked();
				if(tag.action){
					$.exec(tag.action,tag);
				}
			};
			input.checked = function(){
				this.entity.checked = true;
				this.entity.setAttribute("checked",true);
				input.tag.data = this.entity.value;
				//$.CurrentData[tag.name] = this.entity.value;
			};
			input.setData = function(val){
				if(val == this.value){
					this.checked();
				}
			};
			break;
		case "checkbox":
			this.setClass("df_checkbox");
			this.entity.checked = false;
			input.setID(tag.name);	//SJ
			input.entity.onclick = function(){
				if(this.checked){
					//this.checked = false;
					this.name = 'true';
					input.tag.data = "1";
				}else{
					//this.checked = true;
					this.name = 'false';
					input.tag.data = "0";
				}
				if(tag.action){
					$.exec(tag.action,tag);
				}
			};
			break;
		case "button":
			this.setClass("df_btn");
			input.setID(tag.name);
			this.entity.onclick = function(){
				if(input.tag.action){
					$.exec(input.tag.action,input.tag);
				}
			};
			break;
		case "showhidebtn":
			this.setClass("checked-switch");
			input.setID(tag.name+'_shbtn');
			input.entity.onclick = function(){
				if(JQ(this).is(':checked') ^ true)
					JQ('input#'+tag.name).prop('type', 'password');
				else
					JQ('input#'+tag.name).prop('type', 'text');
			};
			break;
		default:
			break;
	}

}
function DefaultAfter(tag,flag){
	Element.call(this,"SPAN:df_after");
	var str = "_after";
	if(flag){
	switch(flag){
		case 1: str="_after1";break;
		case 2: str="_after2";break;
		case 3: str="_after3";break;
		default: str="_after";break;
	}}
	if($.getLan(tag.name + str)){
		if(tag.name == "key_wpa")
			tag.name = "key_wpa";
		var lang = $.getLan(tag.name + str);
		this.html($.getLan(tag.name + str));
	}
}
function DefaultSelect(tag,type){
	if($.BrowserVersion.toString().indexOf('IE')!= -1){
		if(tag.name == 'ipv6')
			Element.call(this,"SELECT:df_select_ie_ipv6");
		else
			Element.call(this,"SELECT:df_select_ie");
	}else{
		if(tag.name == 'ipv6')
			Element.call(this,"SELECT:df_select_ipv6");
		else
			Element.call(this,"SELECT:df_select");
	}
	var _this = this;
	this.tag = tag;
	this.setID(tag.name);
	if (tag.name == 'time')
	{
		this.setID(tag.name+type);
		var options ='';
		this.setClass('df_select df_select_time');
		if (type.indexOf('h')>=0)
		{
			for(var i=0,j=0;i<24;i++){
				j =(i<10)?('0'+i):i;
				this.entity.options.add(new Option(j,j));
			}
		}
		if (type.indexOf('m')>=0)
		{
			for(var i=0,j=0;i<60;i++){
				j =(i<10)?('0'+i):i;
				this.entity.options.add(new Option(j,j));
			}
		}
	} else {
		var options = eval($.getLan(tag.name + "_options"));
		for(var i in options){
			if(!tag.value){
				this.entity.options.add(new Option(options[i],i));
			}else{
				this.entity.options.add(new Option(options[i],tag.value[i]));
			}
		}
	}
	this.entity.onchange = function(){
		var ch = false;
		for(var i=0;i<this.options.length;i++){
			var opt = this.options[i];
			if(opt.value == this.value){
				this.setAttribute("selected",this.value);
				ch = true;
			}
		}
		if(!ch && $.BrowserVersion.toString().indexOf('IE')!= -1){
			_this.tag.data = this.options[0].value;
			_this.data = this.options[0].value;
			_this.checked(_this.data);
		}
		_this.tag.data = this.value;
		_this.data = this.value;
		$.CurrentData[_this.tag.name] = this.value;
		if(tag.action){
			$.exec(tag.action,tag);
		}
	}
	this.checked = function(val){
		this.entity.value = val;
		this.entity.onchange();
	}
	this.setData = function(val){
		if(val){
			this.checked(val);
			_this.tag.data = val;
			this.data = val;
		}	
	};
	if(!tag.data){
		_this.tag.data = this.entity.value;
		this.data = this.entity.value;
	}
}

function DefaultFile(tag){
	Element.call(this,"IFRAME:df_file");
	this.entity.setAttribute('frameBorder', 0); 

}
//默认Panel
function DefaultPanel(pan){
	Element.call(this,"DIV:df_panel");
	this.eleType = "panel";
	var title = new DefaultPanelTitle(pan);
	var content = new DefaultPanelContent(pan);
	this.push(title,content);
	this.title = title;
	this.content = content;
	if(pan.display == '0'){
		this.hide();
	}
}
function DefaultPanelTitle(pan){
	Element.call(this,"DIV:df_panel_title");
	var title = $.getLan(pan.name + "_panel");
	this.setID(pan.name + "_panel");
	if(!title){
		this.hide();
		return;
	}
	this.html(title);
}
function DefaultPanelContent(pan){
	Element.call(this,"DIV:df_panel_content");
}
function initDefaultPanel(pan){
	var panel = new DefaultPanel(pan);
	return panel;
}
function InitAppTag(tag){
	switch(tag.type){
		case "simple_three":	return initSimpleThree(tag); break;
		case "simple_text":		return initSimpleText(tag); break;
		case "simple_text_encode":		return initSimpleText(tag); break;
		case "simple_wifi_pwd":		return initSimpleText(tag); break;
		case "simple_pwd":		return initSimpleText(tag,"p"); break;
		case "text_limit":		return initTextLimit(tag); break;
		case "text_two":		return initTextTwo(tag); break;
		case "radio_group":		return initRadioGroup(tag); break;
		case "simple_check":	return initSimpleCheck(tag); break;
		case "simple_context":	return initSimpleContext(tag); break;
		case "simple_context_encode":	return initSimpleContext(tag); break;
		case "info_context":	return initInfoContext(tag); break;
		case "note_context":	return initNoteContext(tag); break;
		case "simple_btn":		return initSimpleButton(tag); break;
		case "btn_array":		return initButtonArray(tag); break;
		case "simple_select":	return initSimpleSelect(tag); break;
		case "simple_week":		return initSimpleWeek(tag); break;
		case "simple_time":		return initSimpleTime(tag); break;
		case "simple_file":		return initSimpleFile(tag); break;
		case "simple_load":		return initSimpleLoad(tag); break;
		case "simple_table":	return initSimpleTable(tag); break;
		case "simple_slider":	return initSimpleText(tag,"s"); break;
		case "simple_context_text":	return initSimpleText(tag,"ct"); break;
		case "simple_host":		return initSimpleSelect(tag); break;
		case "simple_host6":	return initSimpleSelect(tag); break;
		case "simple_remote":		return initSimpleRemote(tag); break;
		case "mapping_table":	return initMappingTable(tag); break;
		default: 
			var t = new DefaultTag(tag);
			obj2obj(tag,t);
			return t; 
		break;
	}	
}
//默认Tag
function DefaultTag(tag){
	Element.call(this,"DIV:df_tag");
	this.eleType = "tag";
}
function ShowHideBtn(tag)
{
	var span_ = new Element("DIV:d_showhidebtn");
	var label_ = new DefaultLabel(tag,'','shbtn');
	var shbtn = new DefaultInput(tag,"showhidebtn");
	var btn1 = new Element("SPAN:text-switch");
	var btn2 = new Element("SPAN:toggle-btn");
	label_.push(shbtn,btn1,btn2);
	span_.push(label_);
	return span_;
}
//SJ
function show_password_context(tag,flag) {
	var val  = tag.text.entity.value;
	var disabled = tag.text.entity.disabled;
	if(flag == 1){
		var text = new DefaultInput(tag,"text");
	}else{
		var text = new DefaultInput(tag,"password");
	}
	text.setValue(val);
	text.entity.disabled = disabled;
	tag.pwd_f.entity.innerHTML = "";
	tag.pwd_f.append(text);
	tag.text = text;
	
}
//默认文本框
function SimpleTextTag(tag,sta){
	DefaultTag.call(this,tag);
	var label = new DefaultLabel(tag);
	if(sta == "p"){
		var pwd_f = new Element("span");
		pwd_f.setID("show_password" + tag.name);
		var text = new DefaultInput(tag,"password");
		pwd_f.append(text);
	}else if (sta == "w"){
		var text = new DefaultInput(tag,"password");
		var append_shbtn = ShowHideBtn(tag);
	}else if (sta == "s"){
		var text = new DefaultInput(tag,"text");
		text.setClass("df_text_slider");
		var _slider = new DefaultSlider(tag);
	}else if (sta == "ct"){
		var context = new DefaultSpan(tag);
		context.setClass("df_context");
		context.setID(sta+'_'+tag.name);
		context.entity.style.width='auto';
		var text = new DefaultInput(tag,"text");
		text.entity.style.width='50px';
	}else{
		var text = new DefaultInput(tag,"text");
	}
	if(tag.df){
		text.setValue(tag.df);
		tag.data = tag.df;
	}
	var check = new Element("DIV:df_check_panel");
	var layer = new Element("DIV:df_check_layer");
	var info = new Element("DIV:df_check_info");
	var p = new Element("DIV:df_check_p");
	layer.push(info,p);
	check.push(layer);
	check.info = info;
	var after = new DefaultAfter(tag);
	if(tag.mode=='1'){
		var btn = new DefaultInput(tag,'button');
		if (sta == "s")
			this.push(label,_slider,text,btn,check,after);
		else if (sta == "p")
			this.push(label,text,btn);
		else 
			this.push(label,text,btn,check,after);
	}else if(tag.mode=='2'){
		var btn_a = new DefaultInput(tag,'button');
		var btn_b = new DefaultInput(tag,'button');
		btn_a.entity.value = $.CommonLan['current'];
		btn_b.entity.value = $.CommonLan['device'];
		after.setClass("df_after_three");
		if (sta == "s")
			this.push(label,_slider,text,btn_a,btn_b,check,after);
		else
			this.push(label,text,btn_a,btn_b,check,after);
	}else if(tag.mode=='3'){
		label.setClass("df_label_two");
		after.setClass("df_after_two");
		if (sta == "s")
			this.push(label,_slider,text,check,after);
		else
			this.push(label,text,check,after);
	}else if(tag.mode == "5"){	//SJ
		var btn = new DefaultInput(tag,'button');
		btn.entity.value = $.CommonLan['details'];
		btn.entity.style.border = "0px";
		btn.entity.style.textDecoration="underline";
		btn.entity.style.backgroundColor="#f7f7f7";
		this.push(label,btn);
	}else{
		if (sta == "s") {
			this.push(label,_slider,text,check,after);
		} else if (sta == "p") {
			var show_text = new DefaultInput(tag,"button");
			show_text.entity.style.float = "left";
			show_text.entity.style.minWidth = "20px";
			show_text.entity.style.background = "url(./images/show_pwd.png) no-repeat";
			show_text.entity.style.marginTop = "3px";
			show_text.entity.style.border = "none";
			show_text.entity.onmousedown = function() {
				show_password_context(tag,1);
			};
			if (isMobile == true && $.SUPPORT_MOBLIE == 1)
			{
				show_text.entity.onmouseup = function() {
					setTimeout(function(){show_password_context(tag,2);},2000);
				};
			} else {
				show_text.entity.onmouseup = function() {
					show_password_context(tag,2);
				};
			}
			this.pwd_f = pwd_f;
			this.push(label,pwd_f,show_text,check);

			//this.push(label,text,check,after);
		} else if (sta == "w") {
			this.push(label,text,append_shbtn,check,after);
		} else if (sta == "ct"){
			context.entity.innerHTML='xxxx:xxxx:xxxx:xxxx::'
			this.push(label,context,text,check,after);
		} else
			this.push(label,text,check,after);
	}
	if(tag.split){
		if (tag.mode != 'v4sp')
			text.entity.style.width = "300px";
		var split = new Element("span:df_after");
		split.entity.innerHTML = tag.split;
		split.entity.style.fontWeight = "bold";
		split.entity.style.fontSize = "14px";
		this.append(split);
		this.prefixInfo = split;
		var prefix = new DefaultInput(tag,"text");
		prefix.entity.id = tag.name + "prefix";
		prefix.entity.style.width = "30px";
		prefix.entity.maxLength = 3;
		prefix.entity.value = 0;
		this.prefix = prefix;
		this.append(prefix);
	}
	if(tag.mode=='1'){
		this.btn=btn;
	}else if(tag.mode=='2'){
		this.btn_a=btn_a;
		this.btn_b=btn_b;
	}else if(tag.mode =="5"){
		this.btn = btn;
	}
	this.label = label;
	if(tag.mode != 5){
		this.text = text;
		this.check = check;
		this.after = after;
	}
	if (sta == "s")
		this._slider = _slider;
	if (sta == "w")
		this.append_shbtn = append_shbtn;
	obj2obj(tag,this);
}
function initSimpleText(t,sta){
	var tag = new SimpleTextTag(t,sta);
	return tag;
}
function initSimpleTextFunction(tag){
	setTagData(tag.text,tag);
}
function SimpleThreeTag(tag){
	DefaultTag.call(this,tag);
	var label = new DefaultLabel(tag);
	this.append(label);
	var text_a = new DefaultInput(tag,"text");
	text_a.entity.id = tag.name;
	text_a.entity.maxLength = '4',
	text_a.setClass("df_time_text");
	var after_a = new DefaultAfter(tag);
	var text_b = new DefaultInput(tag,"text");
	text_b.entity.id = tag.name+"2";
	text_b.entity.maxLength = '2',
	text_b.setClass("df_time_text");
	var after_b = new DefaultAfter(tag,2);
	var text_c = new DefaultInput(tag,"text");
	text_c.entity.id = tag.name+"3";
	text_c.entity.maxLength = '2',
	text_c.setClass("df_time_text");
	var after_c = new DefaultAfter(tag,3);
	
	this.push(text_a,after_a,text_b,after_b,text_c,after_c);
	
	this.label = label;
	this.text_a = text_a;
	this.after_a = after_a;
	this.text_b = text_b;
	this.after_b = after_b;
	this.text_c = text_c;
	this.after_c = after_c;
	obj2obj(tag,this);
}
function initSimpleThree(tag){
	var tag = new SimpleThreeTag(tag);
	return tag;
}
function TextLimitTag(tag){
	DefaultTag.call(this);
	var label = new DefaultLabel(tag);
	this.append(label);
	if(tag.mode){
		var select = new DefaultSelect(tag);
		this.append(select);
		this.select = select;
	}
	var text_a = new DefaultInput(tag,"text");
	text_a.entity.id = tag.name+'_start';
	text_a.entity.style.width = '72px';//40px
	text_a.entity.maxLength = "5";
	var text_b = new DefaultInput(tag,"text");
	text_b.entity.id = tag.name+'_end';
	text_b.entity.style.width = '72px';
	text_b.entity.maxLength = "5";
	var line = new Element("SPAN");
	//line.setAttr({"style":"float:left;height:25px;line-height:25px;"});
	line.setClass('df_limit_line');
	line.html("-");
	this.push(text_a,line,text_b);
	this.label = label;
	this.text_a = text_a;
	this.text_b = text_b;
	obj2obj(tag,this);
}
function initTextLimit(tag){
	var tag = new TextLimitTag(tag);
	return tag;
}
function TextTwoTag(tag){
	DefaultTag.call(this);
	var _this = this;
	this.value = tag.value;
	this.mode = tag.mode;
	var label =	new DefaultLabel(tag); 
	label.entity.style.height = 25 * 3 + "px";
	label.entity.style.lineHeight = 25 * 3 + "px";
	this.append(label);
	this.label = label;
	var panel = new Element("DIV:radio_panel");
	panel.setClass("two_panel_line");
	var label_a = new Element("SPAN:txt_two");
	label_a.html($.getLan(tag.name + "_label_a"));
	var text_a = new DefaultInput(tag,"text");
	text_a.entity.style.width = '43px';
	text_a.entity.id = tag.name+'_start';
	if(tag.df){
		text_a.setData(eval("("+tag.df+")").toString());
	}
	text_a.getCheck = function(type){
		if(!type){
			type = text_a.ch_key;
		}
		return checkText(text_a,type);
	}
	var label_c = new Element("label");
	label_c.setClass("df_two_after");
	label_c.html($.getLan(tag.name + "_label_c"));
	panel.push(label_a,text_a,label_c);
	this.label_a = label_a;
	this.text_a = text_a;
	this.label_c = label_c;

	var panel_b = new Element("DIV:radio_panel");
	panel_b.setClass("two_panel_line");
	var label_b = new Element("SPAN:txt_two");
	label_b.html($.getLan(tag.name + "_label_b"));
	var text_b = new DefaultInput(tag,"text");
	text_b.entity.style.width = '43px';
	text_b.entity.id = tag.name+'_end';
	if(tag.df){
		text_b.setData(eval("("+tag.df+")").toString());
	}
	text_b.getCheck = function(type){
		if(!type){
			type = text_b.ch_key;
		}
		return checkText(text_b,type);
	}

	var label_c2 = new Element("label");
	label_c2.setClass("df_two_after");
	label_c2.html($.getLan(tag.name + "_label_c"));
	panel_b.push(label_b,text_b,label_c2);
	this.label_b = label_b;
	this.text_b = text_b;
	this.label_c2 = label_c2;

	var panel_d = new Element("DIV:radio_panel");
	panel_d.setClass("two_panel_line");
	var label_d = new Element("SPAN:txt_two");
	label_d.html($.getLan(tag.name + "_label_d"));
	panel_d.push(label_d);
	this.label_d = label_d;
	
	_this.append(panel);
	_this.append(panel_b);
	_this.append(panel_d);
	obj2obj(tag,this);
}
function initTextTwo(tag){
	var tag = new TextTwoTag(tag);
	return tag;
}

//默认单选按钮组
function RadioGroupTag(tag){
	DefaultTag.call(this);
	var _this = this;
	this.name = tag.name;
	this.key = tag.key;
	this.value = tag.value;
	this.mode = tag.mode;
	if(this.mode != "1"){
		var label =	new DefaultLabel(tag); 
		if(this.mode == "2"){
			label.entity.style.height = 25 * this.key.length + "px";
			label.entity.style.lineHeight = 25 * this.key.length + "px";
		}
		this.append(label);
		this.label = label;
	}
	this.panel = new Array();;
	for(var i=0;i<_this.key.length;i++){
		var panel = new Element("DIV:radio_panel");
		if(_this.mode == "1"){
			panel.setClass("radio_panel_single");
		}else if(_this.mode == "2" && tag.tag == null){
			panel.setClass("radio_panel_line");
//		}else if(_this.mode == "2" && tag.tag == 'ipv6'){
//			panel.setClass("radio_panel_line_s");
		}

		panel.entity.setAttribute('id',tag.name + "_" + _this.key[i]);
		var radio =	new DefaultInput(tag,"radio"); 
		radio.setID(tag.name + i);
		radio.setValue(_this.value[i]);
		var txt = new Element("label");
		txt.setClass("df_radio_txt");

		if(tag.name == "out_power" || tag.name == "out_power5g"){
			txt.entity.style.width = "65px";
		}
		if(tag.name == "access_mode" && $.CurrentApp == "wan"){
			txt.entity.style.width = "85px";
		}
		if(_this.mode=="2"||_this.mode=="1"){
			txt.setClass("df_two_after");
		}
		txt.entity.setAttribute("for",tag.name + i);
		if($.CommonLan[_this.key[i]] != undefined){
			txt.html($.CommonLan[_this.key[i]]);
		}else{
			txt.html($.getLan(_this.key[i] + "_r"));
		}
		panel.push(radio,txt);
		panel.radio = radio;
		panel.txt = txt;
		_this.append(panel);
		_this.panel[i] = panel;
	}
	if(tag.mode=='3'){
		var after = new DefaultAfter(tag);
		_this.append(after);
		var text = new Element("INPUT:text_after");
		text.setID(tag.name);
		text.entity.maxLength = '4';
		//text.entity.id = tag.name; 
		text.getCheck = function(type){
			return checkText(text,type);
		}
		_this.append(text);
		var span = new Element("SPAN");
		span.html($.CommonLan["text_after"]);
		_this.append(span);
		this.after=after;
		this.text = text;
	}
	if(tag.mode == '4')
	{
		var after = new DefaultAfter(tag);
		if($.BrowserVersion.indexOf('IE')!=-1){after.setClass("df_after_ie");}
		_this.append(after);  
		this.after=after;
	}
	this.panel[0].radio.checked();
	obj2obj(tag,this);
}
function initRadioGroup(tag){
	var tag = new RadioGroupTag(tag);
	return tag;
}
function initRadioGroupFunction(tag){
	for(var i=0;i<tag.panel.length;i++){
		setTagData(tag.panel[i].radio,tag)
	}
}

function SimpleCheckTag(tag){
	DefaultTag.call(this,tag);
	var label = new DefaultLabel(tag);
	var checkbox = new DefaultInput(tag,"checkbox");
	var after = new DefaultAfter(tag);
	checkbox.setID(tag.name);
	this.push(label,checkbox,after);
	this.checkbox = checkbox;
	this.after = after;
	obj2obj(tag,this);
}
function initSimpleCheck(tag){
	var tag = new SimpleCheckTag(tag);
	return tag;
}

//默认文本行
function SimpleContextTag(tag){
	DefaultTag.call(this);
	var label = new DefaultLabel(tag);
	var context = new DefaultSpan(tag);
	context.setClass("df_context");
	var after = new Element("DIV:df_context_after");
	if(tag.mode == '1'){
		var con = new DefaultSpan(tag);
		con.setClass("df_con");
		var btn = new DefaultInput(tag,'button');
		context.push(con,btn);
	}else if(tag.mode=='2'){
		var con = new DefaultSpan(tag);
		con.setClass("df_con");
		var btn = new DefaultInput(tag,'button');
		var btn_b = new DefaultInput(tag,'button');
		context.push(con,btn,btn_b);
	}else if(tag.mode=='3'){
		var con = new DefaultSpan(tag);
		var con_after = new DefaultSpan(tag);
		con.setClass("df_con");
		con_after.setClass("df_con_after");
		context.push(con,con_after);
	}
	this.push(label,context);
	this.label = label;
	if(tag.mode == '1'){
		this.context = con;
		this.btn = btn;
	}else if(tag.mode=='2'){
		this.context = con;
		this.btn = btn;
		this.btn_b = btn_b;
	}else if(tag.mode=='3'){
		this.context = con;
		this.con_after = con_after;
	}else{
		this.context = context;
		this.push(label,context,after);
	}
	this.after = after;
	obj2obj(tag,this);
}
function initSimpleContext(tag){
	var tag = new SimpleContextTag(tag);
	return tag;
}
function initSimpleContextFunction(tag){
	var html = tag.context.entity.innerHTML;
	if(html != '' || html != ' '){
		setTagData(tag.context,tag);
	}
}
function InfoContextTag(tag){
	DefaultTag.call(this);
	var context = new Element("DIV:df_i_context");
	context.html($.getLan(tag.name + "_info"));
	this.push(context);
	this.context = context;
	obj2obj(tag,this);
}
function initInfoContext(tag){
	var tag = new InfoContextTag(tag);
	return tag;
}
function NoteContext(tag){
	DefaultTag.call(this);
	var note = new Element("DIV:df_note_info");
	if($.getLan(tag.name + "_note")){
		note.html($.getLan(tag.name + "_note"));
	}else{
		note.html("");
	}
		
	this.push(note);
	this.note = note;
	obj2obj(tag,this);
}
function initNoteContext(tag){
	var tag = new NoteContext(tag);
	return tag;
}
//默认button
function SimpleBtnTag(tag){
	DefaultTag.call(this);
	this.setClass("df_btn_tag");
	var btn = new DefaultInput(tag,"button");
	btn.setValue($.CommonLan[tag.mode]);
	btn.entity.style.width = "165px";
	this.push(btn);
	this.btn = btn;
	obj2obj(tag,this);
}
function initSimpleButton(tag){
	var tag = new SimpleBtnTag(tag);
	return tag;
}
function ButtonArrayTag(tag){
	DefaultTag.call(this);
	this.setClass("df_btn_tag");
	var _this = this;
	var ms = eval("("+tag.mode+")");
	var ac = eval("("+tag.action+")");
	for(var i=0;i<ms.length;i++){
		var btn = new DefaultInput(tag,"button");
		var _btn = btn;
		btn.setValue($.CommonLan[ms[i]]);
		btn.setID(ac[i]);
		btn.setName(ms[i]+"_" + i);
		btn.entity.onclick = function(){
			if(tag.action){
				$.exec(eval("("+tag.action+")")[this.name.substring(this.name.length-1)],tag);
			}
		}
		if(i==0)
			this.btn_a = btn;
		else
			this.btn_b = btn;
		this.push(btn);
	}
	if(ms[0]=='add'){this.btn_b.entity.style.display = "none";}
	obj2obj(tag,this);
}
function initButtonArray(tag){
	var tag = new ButtonArrayTag(tag);
	return tag;
}
//默认下拉列表
function SimpleSelectTag(tag){
	DefaultTag.call(this);
	var label = new DefaultLabel(tag);
	var select = new DefaultSelect(tag);
	var after = new DefaultAfter(tag);
	this.push(label,select,after);
	this.label = label;
	this.select = select;
	this.after = after;
	obj2obj(tag,this);
}
function initSimpleSelect(tag){
	var tag = new SimpleSelectTag(tag);
	return tag;
}
function initSimpleSelectFunction(tag){
	if(!tag.data){
		setTagData(tag.select,tag);
	}
}
//默认时间控件
function SimpleTimeTag(tag){
	DefaultTag.call(this);
	var label = new DefaultLabel(tag);
	var time_panel = new Element("DIV");
	time_panel.setClass("df_checkbox_panel");
	var s_hour = new DefaultSelect(tag,'hs');
	var s_min = new DefaultSelect(tag,'ms');
	var e_hour = new DefaultSelect(tag,'he');
	var e_min = new DefaultSelect(tag,'me');
	var line = new Element("SPAN");
	line.html(" - ");
	line.setClass("df_line");
	var sp = new Element("SPAN");
	sp.html(" : ");
	sp.setClass("df_line");
	var sp2 = new Element("SPAN");
	sp2.html(" : ");
	sp2.setClass("df_line");
	time_panel.push(s_hour,sp,s_min,line,e_hour,sp2,e_min);
	this.s_hour = s_hour;
	this.s_min = s_min;
	this.e_hour = e_hour;
	this.e_min = e_min;

	var chk_all = new DefaultInput(tag,"checkbox");
	if($.BrowserVersion.toString().indexOf('IE') >= 0){
		chk_all.setClass("df_checkbox_ie");
	}else{
		chk_all.setClass("df_checkbox");
	}
	chk_all.entity.onclick = function(){
		if(this.checked == true){
			s_hour.entity.disabled = true;
			s_min.entity.disabled = true;
			e_hour.entity.disabled = true;
			e_min.entity.disabled = true;
			s_hour.entity.value="00";
			s_min.entity.value="00";
			e_hour.entity.value="00";
			e_min.entity.value="00";
			this.name = 'true';
		}else{
			s_hour.entity.disabled = false;
			s_min.entity.disabled = false;
			e_hour.entity.disabled = false;
			e_min.entity.disabled = false;
			this.name = 'false';
		}
		$.exec(getTag(1,1).action);
		s_hour.entity.onclick = function(){
			$.exec(getTag(1,1).action);
		}
		s_min.entity.onclick = function(){
			$.exec(getTag(1,1).action);
		}
	}
	var chk_all_label = new Element("SPAN");
	chk_all_label.setClass("df_checkbox_label");
	chk_all_label.html($.CommonLan["all_day"]);
	time_panel.push(chk_all,chk_all_label);
	time_panel.chk_all = chk_all;
	this.push(label,time_panel);
	this.time_panel = time_panel;
	this.chk_all = chk_all;
	obj2obj(tag,this);
}
function initSimpleTime(tag){
	var tag = new SimpleTimeTag(tag);
	return tag;
}
function SimpleWeekTag(tag){
	DefaultTag.call(this);
	var label = new DefaultLabel(tag);
	var week_panel = new Element("DIV");
	week_panel.setClass("df_checkbox_panel");
	week_panel.chk_arr = new Array();
	for(var i=0;i<7;i++){
		var checkbox = new DefaultInput(tag,"checkbox");
		if($.BrowserVersion.toString().indexOf('IE') >= 0){
			checkbox.setClass("df_checkbox_ie");
		}else{
			checkbox.setClass("df_checkbox");
		}
		checkbox.setID(tag.name+i)
		checkbox.setValue(1);
		var checkbox_label = new Element("SPAN");
		checkbox_label.setClass("df_checkbox_label");
		checkbox_label.html($.CommonLan["week_" + i]);
		week_panel.push(checkbox,checkbox_label);
		week_panel.chk_arr.push(checkbox);
	}
	var chk_all = new DefaultInput(tag,"checkbox");
		if($.BrowserVersion.toString().indexOf('IE') >= 0){
			chk_all.setClass("df_checkbox_ie");
		}else{
			chk_all.setClass("df_checkbox");
		}
	chk_all.entity.onclick = function(){
		for(var i=0;i<week_panel.chk_arr.length;i++){
			if(this.checked == true){
				week_panel.chk_arr[i].entity.checked = true;
				disableDom(week_panel.chk_arr[i],true);
			}else{
				week_panel.chk_arr[i].entity.checked = false;
				disableDom(week_panel.chk_arr[i],false);
			}
		}	
	}
	var chk_all_label = new Element("SPAN");
	chk_all_label.setClass("df_checkbox_label");
	chk_all_label.html($.CommonLan["everday"]);
	week_panel.push(chk_all,chk_all_label);
	week_panel.chk_all = chk_all;
	this.push(label,week_panel);
	this.label = label;
	this.week_panel = week_panel;
	obj2obj(tag,this);
}
function initSimpleWeek(tag){
	var tag = new SimpleWeekTag(tag);
	return tag;
}
//默认文件提交
function SimpleFileTag(tag){
	DefaultTag.call(this);
	var label = new DefaultLabel(tag);
	var file = new DefaultFile(tag);
	this.push(label,file);
	this.label = label;
	this.file = file;
	obj2obj(tag,this);
}
function initSimpleFile(tag){
	var tag = new SimpleFileTag(tag);
	return tag;
}
function initSimpleFileFunction(tag){
	//tag.entity.setAttribut('frameborder','0',0);
}
var loadtime;
function SimpleLoadTag(tag){
	DefaultTag.call(this);
	var _this = this;
	this.setAttr({"style":"padding:0 0 15px 0"});
	var tip = new Element("DIV:df_load_tip");
	tip.html($.CommonLan["load_tip"]);
	var load = new Element("DIV:df_load");
	var run = new Element("DIV:df_run");
	var math = new Element("DIV:df_math");
	load.push(run,math);
	load.run = run;
	load.math = math;
	this.push(tip,load);
	this.tip = tip;
	this.load = load;
	this.clearTimeout = function(){
		window.clearInterval(loadtime);
	};
	this.setTimeout = function(t,ip,tag){
		var to = t;
		loadtime = window.setInterval(function(){
			if(t >= 0){
				_this.load.run.entity.style.width = 398*((to-t)/to)+"px";
				var num = (to-t)/to*100;
				//_this.load.math.html(num.toFixed(2) + " %");
				_this.load.math.html(Math.ceil((to-t)/to*100) + " %");
				//SJ 小數進位問題, 會造成進度條數字在某些位數不動
				t -= 1;
			}else{
				window.clearInterval(loadtime);
				if(ip){
					window.location = ip;
				}else{
					window.location.reload();
				}
			}
		},1000);
	}
	obj2obj(tag,this);
}
function initSimpleLoad(tag){
	var tag = new SimpleLoadTag(tag);
	return tag;
}
//默认表单构造
function SimpleTable(tag){
	Element.call(this,"TABLE:df_tab");
	var _this = this;
	this.setAttr({
		"cellspacing":"1",
		"cellpadding":"3"
	});
	if (tag.name == "sys_log_list")
		this.size = 25;
	else if(tag.name == "wl_link_ap_list" || tag.name == "arp_list")
		this.size = 20;
	else
		this.size = 10;

	this.page = 1;
	this.max = 0;
	var thead = new SimpleTabHead(tag);
	this.push(thead);
	this.thead = thead;
	var tfoot = new SimpleTabFoot(tag);
	this.tfoot = tfoot;
	this.createTable = function(data,size){
		if(size){
			_this.size = size;
		}
		_this.data = data;
		_this.max = Math.ceil(tag.tab.data.length/tag.tab.size);
		var tbody = new SimpleTabBody(_this);
		tbody.status = 1;
		tbody.create();
		_this.append(tbody);
		_this.tbody = tbody;
	}
}
function SimpleTabHead(tag){
	Element.call(this,"THEAD:df_thead");
	var _this = this;
	_this.arr = eval($.getLan(tag.name + "_thead")); 
	var r1 = new Element("TR");
	var r2 = new Element("TR");
	var htype = 0;
	_this.rowSpan = 1;
	for(var i in _this.arr){
		if(typeof _this.arr[i] == "object"){
			_this.rowSpan = 2;
			_this.colSpan = _this.arr[i].con.length;
			htype = 1;
			break;
		}
	}
	for(var i=0;i<_this.arr.length;i++){
		var title = _this.arr[i];
		if(typeof(title) != "object"){
			var c = new Element("TD");
			c.entity.setAttribute("rowSpan",_this.rowSpan);
			c.html(title);
			r1.append(c);
		}else{
			var h = new Element("TD");
			h.entity.setAttribute("colSpan",_this.colSpan);
			h.html(title.head);
			r1.append(h);
			for(var j=0;j<title.con.length;j++){
				var c = new Element("TD");
				c.html(title.con[j]);
				r2.append(c);
			}
		}
	}
	if(!htype){
		this.append(r1);
	}else{
		this.push(r1,r2);
	}
}
function SimpleTabBody(tab){
	Element.call(this,"TBODY:df_tbody")
	var _this = this;
	this.status = 0;
	if(!tab.data){
		return;
	}
	this.create = function(){
		if(tab.data.length >= tab.size*tab.page){
			var residue = tab.size;
		}else{
			var residue = tab.data.length%tab.size;
		}
		_this.Rows = new Array();
		var creat_btn =function(data)
		{
			var item = document.createElement("input");
			item.setAttribute("type",'button');
			item.setAttribute("id",data.ifname);
			item.setAttribute("value",data.connected);
			return item;
		}
		for(var i=0;i<residue;i++){
			var row = new Element("TR");
			row.setID("row_" + i);
			row.Cells = new Array();
			var start = (tab.page-1)*tab.size + i;
			row.data = tab.data[start];
			if (tab.parent.name == 'wanConfList' || tab.parent.name == 'modemList' || tab.parent.name == 'st_ipv6WanList') {
				for(var j in tab.data[start]){
					var cell = new Element("TD");
					if (j=='uptime')
						continue;
					if (j=='connected')
					{
						cell.html(tab.data[start][j]+'/');
						var item=creat_btn(row.data);
						cell.entity.append(item);
					} else
						cell.html(tab.data[start][j]);
					row.append(cell);
					row.Cells.push(cell);
				}
			} else {
				for(var j in tab.data[start]){
					var cell = new Element("TD");
					cell.html(tab.data[start][j]);
					row.append(cell);
					row.Cells.push(cell);
				}
			}
			if(tab.parent.mode == 3){
				var cell = new Element("TD:tab_del_mod");
				//cell.setAttr({"style":"width:40px"});
				var del = new Element("DIV:tab_del_btn");
				if(tab.parent.name=="dhcpList"){
					del.setClass("tab_can_btn");
					del.entity.title = $.CommonLan['cancel_reserve'];
				}
				del.setID(i)
				del.entity.onclick = function(){
					var action = tab.parent.action;
					if(action){
						$.exec(eval("("+action+")").del,_this.Rows[this.id]);
					}
				}
				var mod = new Element("DIV:tab_mod_btn");
				if(tab.parent.name=="dhcpList"){
				//	mod.setAttr({"style":'background:url("../images/link.gif")'});
					mod.setClass("tab_link_btn");
					mod.entity.title = $.CommonLan['set_reserve'];
				}
				mod.setID(i);
				mod.entity.onclick = function(){
					var action = tab.parent.action;
					if(action){
						$.exec(eval("("+action+")").mod,_this.Rows[this.id]);
					}
				}
				cell.append(mod);
				cell.mod = mod;
				cell.append(del);
				cell.del = del;
				row.append(cell);
				row.Cells.push(cell);
			}
			_this.append(row);
			_this.Rows.push(row);
		}

		tab.tfoot.num.html(tab.max);
		tab.tfoot.page_select.html('');
		if(tab.max=='0'){
			var o = new Option(0,0);
			tab.tfoot.page_select.entity.options[0]=o;
		}
		for(var i=0;i<tab.max;i++){
			var opt = new Option(i+1,i+1);
			tab.tfoot.page_select.entity.options.add(opt);
		}
		tab.tfoot.page_select.setValue(tab.page);
	}
	this.clear = function(){
		for(var i=_this.entity.childNodes.length-1;i>=0;i--){
			_this.entity.removeChild(_this.entity.childNodes[i]);
		}
	}
	this.refresh = function(){
		_this.clear();
		_this.create();
	}
}
function DefaultPageBtn(tag,key){
	DefaultInput.call(this,tag,"button");
	var _this = this;
	switch(key){
		case 0: this.setClass('df_page_btn1');break;
		case 1: this.setClass('df_page_btn2');break;
		case 2: this.setClass('df_page_btn3');break;
		case 3: this.setClass('df_page_btn4');break;
	}
	this.key = key;
	this.entity.onclick = function(){
		switch(_this.key){
			case 0:
			if(tag.tab.page == 1){
				return;
			};
			changeTabPage(tag,1);break;
			case 1:changeTabPage(tag,tag.tab.page-1);break;
			case 2:changeTabPage(tag,tag.tab.page+1);break;
			case 3:
			if(tag.tab.page == tag.tab.max){
				return;
			};
			changeTabPage(tag,tag.tab.max);break;
			default:break;
		}
		reload_list_show();
	}
}
function changeTabPage(tag,page){
	if(page > 0 && page <= tag.tab.max){
		tag.tab.page = page;
		tag.tab.tbody.refresh();
	}
}
function SimpleTabFoot(tag){
	Element.call(this,"DIV:df_tfoot")
	var _this = this;
	var size_label = new DefaultSpan(tag);
	size_label.setClass('df_page_size_label');
	size_label.html($.CommonLan["size_label"]);
	var size_set = new DefaultInput(tag,"text");
	size_set.setID("page_size");
	size_set.setClass('df_page_size_set');
	size_set.setAttr({"maxlength":"3"});
	size_set.entity.style.width = '25px';
	if(tag.name == "sys_log_list"){
		size_set.setValue(25);
	}else if(tag.name == "wl_link_ap_list" || tag.name == "arp_list"){
		size_set.setValue(20);
	}else{
		size_set.setValue(10);
	}
	var size_btn = new DefaultInput(tag,"button");
	size_btn.setClass('df_page_size_btn');
	size_btn.setValue($.CommonLan["size_set_btn"]);
	this.push(size_label,size_set,size_btn);
	this.size_set = size_set;
	this.size_btn = size_btn;

	var first = new DefaultPageBtn(tag,0);
	var pre = new DefaultPageBtn(tag,1);
	var next = new DefaultPageBtn(tag,2);
	var last = new DefaultPageBtn(tag,3);
	this.push(first,pre,next,last);
	var page_select = new DefaultSelect(tag);
	page_select.entity.style.width = '40px';
	page_select.entity.onchange = function(){
		resetTabPage(tag,this.value);
		reload_list_show();
	}
	this.push(page_select);
	this.page_select = page_select;
	var all = new DefaultSpan(tag);
	all.html($.CommonLan["max_size_label_a"]);
	var num = new DefaultSpan(tag);
	var page = new DefaultSpan(tag);
	page.html($.CommonLan["max_size_label_b"]);
	this.push(all,num,page);
	this.num = num;
	size_btn.entity.onclick = function(){
		resetTabSize(tag,_this.size_set.entity.value);
		reload_list_show();
	}
}

function reload_list_show()
{
	var arr = ['lan','virtual','port_trigger','ip_filter','mac_filter','ipv6_filter']
	for(var i in arr){
		if($.CurrentApp == arr[i]){
			eval($.CurrentApp+"_list_show")();
		}
	}
}
function resetTabPage(tag,page){
	tag.tab.page = parseInt(page);
	tag.tab.tbody.refresh();
}
function resetTabSize(tag,size){
	tag.tab.page = 1;
	if(!checkSingleText(ID("page_size"),'text_page')){return;}
	tag.tab.size = size;
	tag.tab.max = Math.ceil(tag.tab.data.length/tag.tab.size);
	if(size > tag.tab.data.length){
		tag.tab.tfoot.size_set.setValue(tag.tab.data.length);
	}
	tag.tab.tbody.refresh();
}

function SimpleTableTag(tag){
	DefaultTag.call(this);
	this.setClass("df_tab_tag");
	var _this = this;
	var tab = new SimpleTable(tag);
	if(tag.mode == 2){
		this.push(tab);
	}else{
		this.push(tab,tab.tfoot);
	}

	this.tab = tab;
	obj2obj(tag,this);
}
function initSimpleTable(tag){
	var tag = new SimpleTableTag(tag);
	return tag;
}
function SimpleRemoteTag(tag){
	DefaultTag.call(this,tag);
	var label = new DefaultLabel(tag);
	var name = tag.name.substring("remote".length);
	label.html(name);
	var span_ = new Element('span');
	var lang = eval(Language[$.Language][$.CurrentModule][$.CurrentApp]['remoteList'+'_thead']);
	this.push(label);
	for(var i=1;i<=2;i++){
		var str = i==1 ? 'lan_': 'wan_';
		var span = new Element('span');
		var chbox = new DefaultInput(tag,"checkbox");
		var panel = new Element("DIV:check_panel");
		var text = new DefaultInput(tag,"text");
		var span_ = new Element('span');
		if($.BrowserVersion.toString().indexOf('IE') >= 0){
			chbox.setClass("df_checkbox_ie");
		}else{
			chbox.setClass("df_checkbox");
		}
		span.html(lang[i]);
		chbox.setName(tag.name);
		chbox.setID(str+name);
		chbox.setValue(1);
		span.setClass("df_chkbox_label");
		panel.setClass("chkbox_panel");
		panel.push(chbox, span);
		this.append(panel);
	}

	span_.setID('pan_'+tag.name);
	span_.html('&nbsp;&nbsp;'+ lang[3]+'&nbsp;:&nbsp;');
	span_.setClass("df_chkbox_label");
	//span_.entity.style.float=left;
	text.entity.style.width = "140px";
	this.push(span_, text);
	// (port = -1) 隱藏
	// lan 1
	// wan 2
	// lan + wan 3
	
/* 	var spanL = new Element('span');
	var spanW = new Element('span');
	var chboxL = new DefaultInput(tag,"checkbox");
	var chboxW = new DefaultInput(tag,"checkbox");
	var panelL = new Element("DIV:check_panel");
	var panelW = new Element("DIV:check_panel");
	var text = new DefaultInput(tag,"text");
	var lang = eval(Language[$.Language][$.CurrentModule][$.CurrentApp]['remoteList'+'_thead']);

	if($.BrowserVersion.toString().indexOf('IE') >= 0){
		chboxL.setClass("df_checkbox_ie");
		chboxW.setClass("df_checkbox_ie");
	}else{
		chboxL.setClass("df_checkbox");
		chboxW.setClass("df_checkbox");
	}
	spanL.html(lang[1]);
	spanW.html(lang[2]);
	chboxL.setID('lan_'+tag.name);
	chboxW.setID('wan_'+tag.name);
	chboxL.setValue(1);
	chboxW.setValue(1);
	spanL.setClass("df_chkbox_label");
	spanW.setClass("df_chkbox_label");
	text.entity.style.width = "80px";
	panelL.setClass("radio_panel");
	panelL.push(spanL, chboxL);
	panelW.setClass("radio_panel");
	panelW.push(spanW, chboxW);

	this.push(label, panelL, panelW, text); */
	obj2obj(tag,this);
}
function initSimpleRemote(tag){
	var tag = new SimpleRemoteTag(tag);
	return tag;
}
function initMappingTable(tag){
	var tag = new MappingTag(tag);
	return tag;
}
function MappingTag(tag){
	DefaultTag.call(this);
	var body_ = new Element("DIV");
	body_.setClass("df_checkbox_panel");
	body_.setID('mapping_panel');

	for(var i=1,k=1;i<15;i++){
		var checkbox = new DefaultInput(tag,"checkbox");
		if($.BrowserVersion.toString().indexOf('IE') >= 0){
			checkbox.setClass("df_checkbox_ie");
		}else{
			checkbox.setClass("df_checkbox");
		}
		checkbox.setName(tag.name);
		checkbox.setValue(1);
		var ln = new Element("SPAN");
		ln.html("<br />");
		var checkbox_label = new Element("SPAN");
		checkbox_label.setClass("df_checkbox_label");
		if (i<=4)
			checkbox_label.html('LAN'+i);
		else if (i==5){
			checkbox_label.html('WLAN0'); k=1;}
		else if (i>5 && i<10){
			checkbox_label.html('WLAN0'+'_AP'+k); k++;}
		else if (i==10){
			checkbox_label.html('WLAN1'); k=1;}
		else if (i>10 && i<15){
			checkbox_label.html('WLAN1'+'_AP'+k); k++;}
		if (i == 5 || i == 10)
			body_.push(ln,checkbox,checkbox_label);
		else
			body_.push(checkbox,checkbox_label);
	}
	this.push(body_);
	this.body_ = body_;
	obj2obj(tag,this);
}

//公共函数区域
function ID(id){
	return document.getElementById(id);
}
function createByTag(t){
	return document.createElement(t);
}
function disableDom(d,bo){
	d.entity.disabled = bo;
}
function getLen(){
	var num = 0;
	for(var key in $.DataMap){
		num++;
	}
	return num;
}

function pan2idx(pan){
	if(typeof pan == "string"){
		for(var i=0; i < $.Apps[$.CurrentApp].Pans.length; i++){
			if(pan == $.Apps[$.CurrentApp].Pans[i].name)
				pan = i;
				break;
		}
	}
	return pan;
}
function getPan(pan){
	pan = pan2idx(pan);
	return $.Apps[$.CurrentApp].Pans[pan];
}
function getTag(pan,tag){
	pan = pan2idx(pan);
	return $.Apps[$.CurrentApp].Pans[pan].Tags[tag];
}
function getTagDom(pan,tag,dom){
	return $.Apps[$.CurrentApp].Pans[pan].Tags[tag][dom];
}
function getTagRadio(pan,tag,pan2){
	return $.Apps[$.CurrentApp].Pans[pan].Tags[tag].panel[pan2];
}
function SHRadioAct(pan,name) {return (getTag(pan,name).data == '0')?'hide':'show';}
function setOldData(data){
	var obj = new Object();
	if(typeof data=='object'){
		for(var j in data){
			obj["old_"+j] = data[j];
		}
	}
	//testInfo(obj);
	return obj;
}
function setModify(obj){
	var lens = $.Apps[$.CurrentApp].Pans.len;
	for(var i in obj)
	{
		var pan;
		for(var n=0;n<lens;n++){
			if($.Apps[$.CurrentApp].Pans[n].name == "ap_get")
				pan = getPan(lens-3);
			else if($.Apps[$.CurrentApp].Pans[n].name == "schedule" || $.Apps[$.CurrentApp].Pans[n].name == "schedule" || $.Apps[$.CurrentApp].Pans[n].name == "interval")
				pan = getPan(0);
			else pan = getPan(lens-2);
		}
		for(var j in pan.Tags)
		{
			var tag = pan.Tags[j];
			if(tag.name==i)
			{
				switch(tag.type){
					case "simple_select":
						tag.select.setData(obj[i]);
						tag.data = obj[i];
						break;
					case "simple_host":
						var host = obj[i].split(' ');
						tag.select.setData(host[0]);
						tag.data = host[0];
						if(host[0] == '1') {
							pan.Tags[tag.name+"_ip"].text.setData(host[1]);
							pan.Tags[tag.name+"_mask"].text.setData(host[2]);
						}
						else if(host[0] == '2') {
							pan.Tags[tag.name+"_sub_ip"].text.setData(host[1]);
							pan.Tags[tag.name+"_sub_mask"].text.setData(host[2]);
						}
						else if(host[0] == '3') {
							pan.Tags[tag.name+"_ip_start"].text.setData(host[1]);
							pan.Tags[tag.name+"_ip_end"].text.setData(host[2]);
						}
						break;
					case 'simple_host6':
						var host6 = obj[i].split(' ');
						tag.select.setData(host6[0]);
						tag.data = host6[0];
						if(host6[0] != '0') {
							var arr = host6[1].split('/');
							pan.Tags[tag.name+"_ip6addr"].text.setData(arr[0]);
							pan.Tags[tag.name+"_ip6addr"].prefix.setData(arr[1]);
						}
						break;
					case "simple_text":
						if(tag.text.Name == "text_ipv6" && obj[i].indexOf('/')!=-1)
						{
							var arr = obj[i].split('/');
							tag.text.setData(arr[0]);
							tag.prefix.setData(arr[1]);
						}
						else
							tag.text.setData(obj[i]);
						break;
					case "simple_text_encode":
						tag.text.setData(htmlstr(obj[i]));
						break;
					case "radio_group":
						for(var k=0;k<tag.panel.length;k++){
							tag.panel[k].radio.setData(obj[i]);
						}
						break;
					case "text_limit":
						if(obj[i].indexOf('-')!=-1){
							var arr = obj[i].split('-');
							tag.text_a.setData(arr[0]);
							tag.text_b.setData(arr[1]);
						}else{
							tag.text_a.setData(obj[i]);
						}
						break;
					case "simple_week":
						tag.week_panel.chk_all.entity.checked = false;
						for(var h=0;h<tag.week_panel.chk_arr.length;h++){
							disableDom(tag.week_panel.chk_arr[h],false);
							tag.week_panel.chk_arr[h].entity.checked = false;
							if(obj[i] & (64 >> h)) {
								tag.week_panel.chk_arr[h].entity.checked = true;
							}
							if(obj[i]==127){
								disableDom(tag.week_panel.chk_arr[h],true);
							}
						}
						if(obj[i]==127){
							tag.week_panel.chk_all.entity.checked = true;
						}
						break;
					case "simple_time":
						tag.time_panel.chk_all.entity.checked = false;
						tag.s_hour.entity.disabled = false;
						tag.s_min.entity.disabled = false;
						tag.e_hour.entity.disabled = false;
						tag.e_min.entity.disabled = false;

						if(obj[i].indexOf('-')!=-1 && obj[i].indexOf(':')!=-1){
							var _time = obj[i].split('-');
							tag.s_hour.setData(_time[0].split(':')[0]);
							tag.s_min.setData(_time[0].split(':')[1]);
							tag.e_hour.setData(_time[1].split(':')[0]);
							tag.e_min.setData(_time[1].split(':')[1]);
							$.exec(getTag(1,1).action);
							tag.s_hour.entity.onclick = function(){
								$.exec(getTag(1,1).action);
							}
							tag.s_min.entity.onclick = function(){
								$.exec(getTag(1,1).action);
							}
						} else if(obj[i]=='all'){
							tag.time_panel.chk_all.entity.checked = true;
							tag.s_hour.entity.disabled = true;
							tag.s_min.entity.disabled = true;
							tag.e_hour.entity.disabled = true;
							tag.e_min.entity.disabled = true;
						}
						break;
					}
			}else{
				if(tag.type == "text_two"){
					ID(tag.name+"_start").value = obj[tag.name+"_up"];
					ID(tag.name+"_end").value = obj[tag.name+"_down"];
				}
			}
		}
	}
}

function getSubmitData(pan){
		if(pan == null){
			return $.CurrentData;
		}
		var obj = new Object();
		for(var i=0;i<pan.length;i++){
			var Pan = getPan(pan[i]);
			for(var j in Pan.Tags){
				if(checknobj(j)){
					continue;
				}
				var tag = Pan.Tags[j];
			/*	SJ for submit button set
				if(tag.type.indexOf('btn') != -1){
					tag.mod = "save";
					continue;
				}
			*/
				var dis = tag.entity.style.display;
				//只提交显示的
				if(dis!='none'){
					switch(tag.type){
						case 'simple_remote':
							//console.log(tag);
							var num = 0;
							if (tag.children[1].children[0].entity.checked == true)
								num |= 0x1;
							if (tag.children[2].children[0].entity.checked == true)
								num |= 0x2;
							obj[tag.name] = JQ('#'+tag.name+'_t').val() + ' ' + num;
						break;
						case 'simple_check':
							if(tag.checkbox.entity.checked == true)
								obj[tag.name] = 1;
							else
								obj[tag.name] = 0;
						break;
						case 'simple_three':
							var a = tag.text_a.entity.value;
							var b = tag.text_b.entity.value;
							var c = tag.text_c.entity.value;
							obj[tag.text_a.entity.id] = a;
							obj[tag.text_b.entity.id] = b;
							obj[tag.text_c.entity.id] = c;
							break;
						case 'text_limit':
							if(tag.select){
								var sel = tag.select.entity.value;
								obj[tag.select.entity.id] = sel;
							}
							var a = tag.text_a.entity.value;
							var b = (tag.text_b.entity.value).replace(/^\s*$/g,"");
							if(b=="") b=a;
							//只提交不是diabled的
							if(!tag.text_a.entity.disabled){
								obj[tag.name] = a+"-"+b;
							}
						break;
						case 'simple_week':
							var arr = tag.week_panel.chk_arr;
							var week_sum = 0;
							var check = false;
							for(var d=0;d<arr.length;d++){
								if(arr[d].entity.checked == true){
									week_sum += arr[d].entity.value << arr.length-1-d;
									check = true;
								}
							}
							tag.data = week_sum;
							obj[tag.name] = tag.data;
						break;
						case 'simple_time':
							var sh = tag.s_hour.entity.value;
							var sm = tag.s_min.entity.value;
							var eh = tag.e_hour.entity.value;
							var em = tag.e_min.entity.value;
							var chk = tag.chk_all;
							if(chk.entity.checked == true){
								tag.data = 'all';
							}else{
//								if((sh+':'+sm)=="00:00"&&(eh+':'+em)=="00:00"){
//									tag.data = 'all';
//								}else{
									tag.data = (sh+':'+sm) + '-' + (eh+':'+em);
//								}
							}
							obj[tag.name] = tag.data;
						break;
						case 'simple_slider':
						case 'simple_text':
							var datalen = tag.text.entity.value.length;
							if(tag.split){
								if (tag.mode != 'v4sp')
									obj[tag.name] = (datalen?tag.text.entity.value:"::")+"/"+tag.prefix.entity.value;
								else
									obj[tag.name] = tag.prefix.entity.value;
							}else{
								if(!tag.text.entity.disabled){
									obj[tag.name] = check_len(tag.text.entity.value,datalen,tag.len);
								}
								if ($.EncodingF) obj[tag.name] = btoa(obj[tag.name])
								//Base64.encode(obj[tag.name]);
							}
						break;
						case "simple_context_text":
							obj[tag.name] = parseInt(tag.text.entity.value,16);
							break;
						case 'simple_text_encode':
							if(!tag.text.entity.disabled){
								obj[tag.name] = btoa(check_len(tag.text.entity.value,tag.len));
								//obj[tag.name] = btoa(encodeURIComponent(check_len(tag.text.entity.value,tag.len)));
								//Base64.encode(check_len(tag.text.entity.value,tag.len));
							}
						break;
						case 'simple_wifi_pwd':
						case 'simple_pwd':
							if(!tag.text.entity.disabled){
								obj[tag.name] = btoa(tag.data);
								//check_special(Base64.encode(tag.data));
							}
						break;
						case 'radio_group':
							if(tag.mode=='3'){
								for(var i=0;i<tag.panel.length;i++){
									if(tag.panel[i].radio.entity.checked==true){
										obj[tag.name]=tag.panel[i].radio.entity.value;
									}
								}
								obj[tag.name+"_v"] = tag.text.entity.value;
							}else{
								obj[tag.name] = tag.data;
							}
							break;
						case 'simple_btn':
							obj[tag.name] = tag.mode;
							break;
						case 'btn_array':
							obj[tag.name] = MOD;
							break;
						case 'text_two':
							obj[tag.name+'_up'] = tag.text_a.entity.value;
							obj[tag.name+'_down'] = tag.text_b.entity.value;
							break;
						case 'simple_select':
							if(!JQ('[ID*="_type"]').prop('disabled')) 
								obj[tag.name] = tag.select.entity.value;
							break;
						case 'simple_host':
							if(tag.select.entity.value == '0') {
								obj[tag.name] = "0 0.0.0.0 0.0.0.0";
							}
							else if(tag.select.entity.value == '1') {
								obj[tag.name] = "1 "+Pan.Tags[tag.name+"_ip"].text.entity.value+" 255.255.255.255";
							}
							else if(tag.select.entity.value == '2') {
								obj[tag.name] = "2 "+
								Pan.Tags[tag.name+"_sub_ip"].text.entity.value+" "+
								Pan.Tags[tag.name+"_sub_mask"].text.entity.value;
							}
							else if(tag.select.entity.value == '3') {
								obj[tag.name] = "3 "+
								Pan.Tags[tag.name+"_ip_start"].text.entity.value+" "+
								Pan.Tags[tag.name+"_ip_end"].text.entity.value;
							}
							break;
						case 'simple_host6':
							if(tag.select.entity.value == '0') {
								obj[tag.name] = "0 ::/128";
							}
							else {
								obj[tag.name] = tag.select.entity.value +" "+Pan.Tags[tag.name+"_ip6addr"].text.entity.value+"/"+Pan.Tags[tag.name+"_ip6addr"].prefix.entity.value;
							}
							break;
						case 'simple_table':
							obj[tag.name] = "del_all";
							break;
						case 'mapping_table':
							var tmp = 0, num = 1;
							var Obj = JQ("input[id='map']");
							for (var m=0; m< Obj.length; m++)
							{
								if (Obj[(Obj.length-m-1)].checked == true)
									tmp += num;
								num = num << 1;
							}
							obj[tag.name] = tmp;
							break;
						default:
							obj[tag.name] = tag.data;
							break;
					}
				}
			}
		}
		if ($.CurrentApp == 'wan' || $.CurrentApp == 'ipv6_configure')
			return dis_wan_type(obj);
		else
			return obj;
}
function getObjStr(obj){
	var str = '{';
	for(var i in obj){
		str += i + ':"'+obj[i] + '",';
	}
	str = str.substring(0,str.length-1);
	str += '}';
	return str;
}
function testInfo(obj){
	var str ='';
	for(var i in obj){
		if(typeof obj[i] == 'object'){
			str += i + ":[";
			for(var j=0;j<obj[i].length;j++){
				if(j<obj[i].length-1){
					str += getObjStr(obj[i][j])+',';
				}else{
					str += getObjStr(obj[i][j]);
				}
			}
			str += ']\r\n';
		}else{
			str += i + ":" + obj[i] + '\r\n';
		}
	}
	alert(str);
}
function setPanAction(pan,action){
	for(var i=0;i<pan.length;i++){
		if(typeof action == 'string'){
			getPan(pan[i])[action]();
		}else if(typeof action == 'function'){
			action(getPan(pan[i]));
		}
	}
}
function setPanArr(pan,data){
	for(var i=0;i<pan.length;i++){
		getPan(pan[i]).display = data;
	}
}
function setTagDomAction(pan,tag,dom,action){
	var obj = {};
	obj = new Array();
	if(tag==null){return;}	//SJ
	var t = tag[0].toString().split('-');
	if(t.length > 1){
		var len = parseInt(t[1],10) - parseInt(t[0],10) + 1;
		for(var i=0;i<len;i++){
			if(dom != null){
				obj.push($.Apps[$.CurrentApp].Pans[pan].Tags[i+parseInt(t[0],10)][dom]);
			}else{
				obj.push($.Apps[$.CurrentApp].Pans[pan].Tags[i+parseInt(t[0],10)]);
			}
		}
	}else{
		var len = tag.length
		for(var i=0;i<len;i++){
			if(dom != null){
				obj.push($.Apps[$.CurrentApp].Pans[pan].Tags[tag[i]][dom]);
			}else{
				obj.push($.Apps[$.CurrentApp].Pans[pan].Tags[tag[i]]);
			}
		}
	}
	if(typeof action == 'string'){
		for(var i=0;i<obj.length;i++){
			if(obj[i] != undefined)
				obj[i][action]();
		}
	}else if(typeof action == 'function'){
		for(var i=0;i<obj.length;i++){
			action(obj[i]);
		}
	}
}
function setTagData(dom,tag){
	if($.DataMap){
		if(wl_currApp[0].indexOf($.CurrentApp) != -1){
			var i = ($.DataMap.wlanBandMode == 2) ?$.DataMap.wl5g_idx:$.DataMap.wl2g_idx;
			dom.setData($.DataMap.wlan[i][tag.name]);
			tag.data = $.DataMap.wlan[i][tag.name];
		}else if(wl_currApp[1].indexOf($.CurrentApp) != -1){
			dom.setData($.DataMap.wlan[0][tag.name]);
			tag.data = $.DataMap.wlan[0][tag.name];
		}else{
			dom.setData($.DataMap[tag.name]);
			tag.data = $.DataMap[tag.name];
		}
	}
}
function setCurrentData(data,name){
	$.CurrentData[name] = data[name];
}
function setAppTagData(data){
	$.CurrentData = {};
	if(!data){
		return;
	}
	var pans = $.Apps[$.CurrentApp].Pans;
	for(var i in pans){
		if(checknobj(i)){
			continue;
		}
		for(var j in pans[i].Tags){
			if(checknobj(j)){
				continue;
			}
			var tag = pans[i].Tags[j];
			var d_name = data[tag.name];
			if(typeof(data[tag.name]) != 'undefined'){
				setCurrentData(data,tag.name);
			}else{
				continue;
			}
			switch(tag.type){
				case 'simple_remote':
					var infos = d_name.split(' ');
					var tmp = parseInt(infos[1], 10);
					var Obj = JQ("input[name='"+tag.name+"']");
					for (var m=0; m< Obj.length; m++)
					{
						if ((tmp & 1) == 1)
							tag.entity.children[m+1].children[0].checked = true;
						tmp = tmp >> 1;
					}
					JQ('#'+tag.name+'_t').val(infos[0]);
					break;
				case 'simple_check':
					tag.checkbox.entity.checked = data[tag.name] == '1' ? true : false;
					tag.data = data[tag.name];
					break;
				case "simple_context": 
					if(d_name.length == 17 && d_name.split('-').length == 6){
						tag.context.html(d_name.toUpperCase());
						tag.data = (d_name.toUpperCase());
					}else{
						tag.context.html(d_name);
						tag.data = (d_name);
					}
					break;
				case "simple_context_encode": 
					d_name = atob(d_name);
					if(d_name.length == 17 && d_name.split('-').length == 6){
						tag.context.html(d_name.toUpperCase());
					}else{
						tag.context.html(d_name);
					}
					break;
				case "simple_context_text":
					tag.text.setData(parseInt(d_name).toString(16));
					break;
				case "simple_select":
					tag.select.setData(d_name);
					break;
				case "simple_three":
					tag.text_a.setData(data["sys_"+tag.name]);
					tag.text_b.setData(data["sys_"+tag.name+2]);
					tag.text_c.setData(data["sys_"+tag.name+3]);
					break;
				case "simple_text":
					if(tag.split) {
						if (tag.mode != 'v4sp') {
							if(data[tag.name].split("/")[0] == "::") tag.text.setData('')
							else {tag.text.setData(data[tag.name].split("/")[0]);
								  tag.prefix.setData(data[tag.name].split("/")[1]);}
						}
						else
							tag.prefix.setData(data[tag.name]);
					}else{
						if ($.EncodingF) d_name = atob(d_name);
						if(d_name.length == 17 && d_name.split('-').length == 6){
							tag.text.setData(d_name.toUpperCase());
						}else{
							tag.text.setData(d_name);	// not decode
						}
					}
					break;
				case "simple_text_encode":
					d_name = atob(d_name);
					if(d_name.length == 17 && d_name.split('-').length == 6){
						tag.text.setData(d_name.toUpperCase());
					}else{
						tag.text.setData(d_name);
					}
					break;
				case "simple_wifi_pwd":
				case "simple_pwd":
					tag.text.setData(atob(d_name));
					break;
				case "radio_group":
					for(var k=0;k<tag.panel.length;k++){
						tag.panel[k].radio.setData(d_name);
					}
					if(tag.mode=="3"){
						tag.text.entity.value=$.DataMap[tag.name+'_v'];
					}
					break;
				case "simple_table":
					if(tag.tab.tbody){
						tag.tab.data = d_name;
						tag.tab.tbody.refresh();
					}else{
						for(var x in d_name){
							if( !checknobj(x) ) continue;
						}
						if (tag.name == "apLinkList")
						{
							for (let i in d_name)
							{
								d_name[i].ssid = Base64.decode(d_name[i].ssid);
							}
						}
						tag.tab.createTable(d_name);
					}
					break;
				case "mapping_table":
					var num = 0x3fff;
					if (data.ifname != '' && data.ifidx == '1') num = d_name;
					var Obj = JQ("input[name='map']");
					for (var i=0; i< Obj.length; i++)
					{
						if (((num >> i) & 1) == 1)
							Obj[Obj.length-i-1].checked = true;
						else
							Obj[Obj.length-i-1].checked = false;
					}
					break;
				default: break;
			}
		}
	}
}

function ltrim(s){
	return s.replace(/(^s*)/g, "");
}
//去右空格;
function rtrim(s){
	return s.replace(/(s*$)/g, "");
}
//去左右空格;
function trim(s){
	//s.replace(/(^s*)|(s*$)/g, "");
	return rtrim(ltrim(s));
}
var CheckMap = {
	"text_null":"check_null",
	"text_num4094":"check_num4094",
	"text_page":"check_page_size",
	"text_num":"check_num",
	"text_lanip":"check_lanip",
	"text_ip":"check_ip",
	"text_ipv6":"check_ipv6",
	"text_dns":"check_dns",
	"text_dnsv6":"check_dnsv6",
	"text_mac":"check_mac",
	"text_mask":"check_mask",
	"text_mask_wan":"check_mask_wan",
	"text_port":"check_port",
	"text_key_time":"check_key_time",
	"text_dhcp_time":"check_dhcp_time",
	"text_string":"check_string",
	"text_string_null":"check_string_null",
	"text_az09":"check_az09_string",
	"text_domain":"check_domain",
	"text_url":"check_url",
	"text_pin":"check_pin",
	"text_mtu":"check_mtu",
	"text_router":"check_router_num",
	"text_ack_timeout":"check_ack_timeout",
	"text_rfPower":"check_RfPower",
	"text_common":"check_common",
	"text_hex":"check_hex",
	"text_port_null":"check_port_null",
	"text_qos_band":"check_qos_bandwidth",
	"text_string_len":"check_string_len",
	"text_string_ssid":"check_string_ssid",
	"text_keyboard_pass":"check_keyboard_pass",
	"text_interval":"check_interval",
	"text_wd_pkcycle":"check_wd_pkcycle",
	"text_wd_delay":"check_wd_delay",
	"text_wd_lost":"check_wd_lost",
	"text_snmp_oid":"check_snmp_oid",
	"text_domip":"check_domip"
};
/*检查字符串长度*/
function check_string_len(ch){
	var str = ch.data;
	ch.info = '';
	if(str.length > ch.len){
		ch.info= $.CommonLan[ch.id + '_' + "len_err"];
		return;
	}
	ch.val = true;
}
/*框架调用验证方法,通过skk对象获取input*/
function checkText(text,type){
	var check = new Object();
	check.data = text.entity.value;
	check.len = text.entity.maxLength;
	check.id = text.entity.id;
	check.val = false;
	check.info = " ";
	$.exec(CheckMap[type],check);
	return check;
}
/*单独调用验证方法,通过ID获取input*/
function checkSingleText(txt,type){
	var check = new Object();
	check.data = txt.value;
	check.val = false;
	check.info = " ";
	$.exec(CheckMap[type],check);
	if(!check.val){
		checkShow(txt,check.info);
		return false;
	}
	return true;
}
/*框架自动验证函数*/
function checkTag(pa){
	for(var i=0;i<pa.length;i++){
		var pan = getPan(pa[i]);
		var tags = pan.Tags;
		for(var j=0; j < tags.len;j++){
			if (tags[j].type=='simple_remote')
			{
				var ch_text = tags[j].children[4];
				var ch = ch_text.getCheck();
				if(JQ('#'+ch.id).is(':visible') == true){
					if(!ch.val){
						checkShow(ch_text,ch.info);
						return false;
					}
				}
			}
			if(checknobj(j)||tags[j].type!='simple_text'&&tags[j].type!='simple_text_encode'&&tags[j].type!='simple_wifi_pwd'&&tags[j].type!='simple_pwd'&&tags[j].type!='simple_slider'&&tags[j].type!='simple_context_text'){
				continue;
			}
			var ch_text = tags[j].text;
			var ch = ch_text.getCheck();
			//只验证显示的和不是disabled的
			if(tags[j].entity.style.display!='none'){
				if(tags[j].text){
					if(tags[j].text.entity.disabled){continue;}
				}
				if(!ch.val){
					checkShow(ch_text,ch.info);
					return false;
				}
				if(tags[j].type == "simple_text"){
					if(tags[j].split && tags[j].prefix.entity.style.display != "none"){
						if(/^[1-9]$|^[1-9]\d$|^1[01]\d$|^12[0-8]$/.test(tags[j].prefix.entity.value) != true){
							checkShow(tags[j].prefix,$.CommonLan['int_number_err']+"(1-128)");
							return false;
						}
					}
				}
			}
		}
	}
	return true;
}
//对单个Dom元素进行验证(skk对象)
function checkDom(text,type,defstr){
	var ch = text.getCheck(type);
	if (defstr) ch.info = defstr;
	if(!ch.val){
		checkShow(text,ch.info);
		if ($.Debug) alert(ch.info);
		return false;
	}
	return true;
}
//对多个Dom元素进行验证(skk对象)
function checkDomArr(p,t_r,t_c){
	for(var i=0;i<t_r.length;i++){
		var txt = getTag(p,t_r[i]).text;
		if(!checkDom(txt,t_c[i])){
			return false;
		}
	}
	return true;
}
//显示验证信息(skk对象或者dom对象)
function checkShow(text,info,flag){
	$.lockWin(' ',false,flag);
	if(info == ''){
		$.unlockWin($.CommonLan['_lock_error']);
	}else{
		$.unlockWin(info,flag);
		if ($.Debug) alert(info);
	}
	if(text.entity){
		var ent = text.entity;
	}else{
		var ent = text;
	}
	ent.style.border = "solid 1px #EA7E12";
	window.setTimeout(function(){
		ent.style.border = "solid 1px #d2d2d2";
	},6000);
}
//check
function check_common(ch){
	ch.val = true;
}

/**************** 正则表达式验证 *************************/
var regMap = {
	keyboard_pass:/^[\x20-\x7E]/,
	num			:/^\d*$/,
	str			:/[\\\'\"]|\s/,
	az09		:/^(|[A-Za-z\d]+)$/,
	che			:/[\u4E00-\u9FA5\uF900-\uFA2D]/,
	domain		:/^(?:[a-zA-Z]{1}(([a-zA-Z\d]{0,62})|([a-zA-Z\d\-]{1,61}[a-zA-Z\d]))\.){1,126}([a-zA-Z]{1}(([a-zA-Z\d]{0,62})|([a-zA-Z\d\-]{1,61}[a-zA-Z\d])))$/,
	url			:/^([A-Za-z\d\.]+)$/,
	hex			:/^[A-Fa-f\d]+$/,
	lanip			:/^((((0|127|(22[4-9])|(2[3-4]\d)|(24[0-4]))\.)(([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5])\.){2}([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5]))|((255\.){3})255)$|(((100\.(6[4-9]|[7-9]\d|1[0-1]\d|12[0-7])\.)|(169\.254\.)|(198\.(1[8-9])\.))([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5])\.)([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5])$|(((192\.)((0\.((0|2)\.))|(88\.99\.))|(198\.51\.100\.)|(203\.0\.113\.))([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5]))$/,
	ip			:/^(([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5])\.){3}([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5])$/,
	ipv6 		:/^([\da-fA-F]{1,4}:){6}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^::([\da-fA-F]{1,4}:){0,4}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:):([\da-fA-F]{1,4}:){0,3}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){2}:([\da-fA-F]{1,4}:){0,2}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){3}:([\da-fA-F]{1,4}:){0,1}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){4}:((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){7}[\da-fA-F]{1,4}$|^:((:[\da-fA-F]{1,4}){1,6}|:)$|^[\da-fA-F]{1,4}:((:[\da-fA-F]{1,4}){1,5}|:)$|^([\da-fA-F]{1,4}:){2}((:[\da-fA-F]{1,4}){1,4}|:)$|^([\da-fA-F]{1,4}:){3}((:[\da-fA-F]{1,4}){1,3}|:)$|^([\da-fA-F]{1,4}:){4}((:[\da-fA-F]{1,4}){1,2}|:)$|^([\da-fA-F]{1,4}:){5}:([\da-fA-F]{1,4})?$|^([\da-fA-F]{1,4}:){6}:$/,
//	dns			:/^(|((22[0-3])|(2[0-1]\d)|(1\d\d)|([1-9]\d)|[1-9])(\.((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]\d)|\d)){3})$/,
	dns			:/^(|(([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5])\.){3}([\d]|[\d]{2}|1[\d]{2}|2[0-4][\d]|25[0-5]))$/,
	dnsv6 		:/^(|([\da-fA-F]{1,4}:){6}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^::([\da-fA-F]{1,4}:){0,4}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:):([\da-fA-F]{1,4}:){0,3}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){2}:([\da-fA-F]{1,4}:){0,2}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){3}:([\da-fA-F]{1,4}:){0,1}((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){4}:((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$|^([\da-fA-F]{1,4}:){7}[\da-fA-F]{1,4}$|^:((:[\da-fA-F]{1,4}){1,6}|:)$|^[\da-fA-F]{1,4}:((:[\da-fA-F]{1,4}){1,5}|:)$|^([\da-fA-F]{1,4}:){2}((:[\da-fA-F]{1,4}){1,4}|:)$|^([\da-fA-F]{1,4}:){3}((:[\da-fA-F]{1,4}){1,3}|:)$|^([\da-fA-F]{1,4}:){4}((:[\da-fA-F]{1,4}){1,2}|:)$|^([\da-fA-F]{1,4}:){5}:([\da-fA-F]{1,4})?$|^([\da-fA-F]{1,4}:){6}:)$/,
	mac			:/^([A-Fa-f\d][^13579bdfBDF]:[A-Fa-f\d]{2}:[A-Fa-f\d]{2}:[A-Fa-f\d]{2}:[A-Fa-f\d]{2}:[A-Fa-f\d]{2})$/,
	mac1		:/^[A-Fa-f\d]{2}-[A-Fa-f\d]{2}-[A-Fa-f\d]{2}-[A-Fa-f\d]{2}-[A-Fa-f\d]{2}-[A-Fa-f\d]{2}$/,
	port		:/^(\d{1,4}|([1-5]\d{4})|6[0-4]\d{3}|65[0-4]\d\d|655[0-2]\d|6553[0-5])$/,
	port_null	:/^(|\d{1,4}|([1-5]\d{4})|6[0-4]\d{3}|65[0-4]\d\d|655[0-2]\d|6553[0-5])$/,
	keytime		:/^([6-9]\d|\d{3,4}|[1-8][0-5]\d\d\d|86[0-3]\d\d|86400)$/,
	dhcptime	:/^([6-9]\d|\d{3,6}|1\d{6}|2[0-4][\d{5}|25[0-8]\d{4}|2591\d{3}|2592000)$/,
	ack_timeout	:/^((25[0-5]|2[0-4]\d)|(1\d\d)|([1-9]\d)|[0-9])$/,
	rfPower		:/^(100|([1-9]\d)|\d)$/,
	update_time	:/^(9[0]{3}|[1-8]\d\d\d|[1-9]\d\d)$/,
	limit255	:/^(25[0-5]|2[0-4]\d|1\d\d|[1-9]\d|[1-9])$/,
	limit12799	:/^(\d{1,4}|1[0-1]\d\d\d|12[0-7]\d\d)$/,
	mon			:/^(0[1-9]|[1-9]|1[0-2])$/,
	hour		:/^(0[0-9]|[0-9]|1[0-9]|2[0-3])$/,
	minsec		:/^(0[0-9]|[0-9]|[1-5][0-9])$/,
	pak			:/^([5-9]|[1-9]\d|[1-9]\d\d|[1-2]\d\d\d|3000)$/,
	pin			:/^\d{8}$/,
	page		:/^([1-9]|[1-9]\d|[1-9]\d\d)$/,
	stmax		:/^-[1-9]\d$/,
	stnum		:/^-100|-[1-9]\d$/,
	ssid		:/[\\\'\"]/,	//Maybe do not use
	wl_ssid		:/^[\s]|[\s]$/,
	sql_injec		:/['"\x22\x2A%&\x3F\x3D\\]+/,
	interval	:/^([1-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])$/,
	pkcycle		:/^(300|[1-2]\d{2}|[1-9]\d)$/,
	wd_delay	:/^(600|[1-5]\d{2}|[6-9]\d)$/,
	wd_lost		:/^((25[0-5]|2[0-4]\d)|(1\d\d)|([1-9]\d)|[0-9])$/,
	tblvid		:/^(4090|40[0-8]\d|[1-3]\d{3}|[1-9]\d{2}|[1-9]\d|[1-9])$/,
	snmpoid		:/^(1\.3\.6\.1\.4\.1\.)[0-9]/
};
function check_domip(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.domain);
	flag = reg.test(str);
	var stip = true;
	var regip = new RegExp(regMap.ip);
	flagip = regip.test(str);
	var str2=str.split(".");

	for(var i=0;i<str2.length;i++){
		if (!JQ.isNumeric(str2[i])) stip = false;
	}

	if (stip == false){
		if(!flag){ch.info=$.CommonLan["domain_err"];return;}
	}else{
		if(!flagip){ch.info=$.CommonLan["ip_err"];return;}
		if(str2[0]==127||str2[3]==255){ch.info=$.CommonLan["ip_err"];return;}
	}
	ch.val = true;
}
function check_snmp_oid(ch){	//1.3.6.1.4.1.X
	var str = ch.data;
	var reg = new RegExp(regMap.snmpoid);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["snmp_oid_err"];return;
	}
	ch.val = true;
}
function check_text_obj(data){
	var obj = new Object();
	obj.data = data;
	obj.val = false;
	obj.info = " ";
	return obj;
}
function check_wd_lost(ch){	//1-65535
	var str = ch.data;
	var reg = new RegExp(regMap.wd_lost);
	flag = reg.test(str);
	if(!flag){
		ch.info = $.CommonLan["wd_lost_err"];return;
	}
	ch.val = true;
}
function check_wd_delay(ch){	//60-600
	var str = ch.data;
	var reg = new RegExp(regMap.wd_delay);
	flag = reg.test(str);
	if(!flag){
		ch.info = $.CommonLan["wd_delay_err"];return;
	}
	ch.val = true;
}
function check_wd_pkcycle(ch){	//10-300
	var str = ch.data;
	var reg = new RegExp(regMap.pkcycle);
	flag = reg.test(str);
	if(!flag){
		ch.info = $.CommonLan["pkcycle_err"];return;
	}
	ch.val = true;
}
function check_interval(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.interval);
	flag = reg.test(str);
	if(JQ('#interval_time_t').prop('disabled')){
		ch.val = true;
	}
	else if(!flag){
		ch.info = $.CommonLan["interval_err"];return;
	}
	ch.val = true;
}
//检查整数 
function check_num(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.num);
	flag = reg.test(str);
	if(!flag||str==''){
		ch.info = $.CommonLan["int_number_err"];return;
	}
	ch.val = true;
}
//检查lanip合法性
function check_lanip(ch){
	check_ip(ch);
	if (ch.val != true) return;
	ch.val = false;
	var str = ch.data;
	var reg=new RegExp(regMap.lanip);
	flag = reg.test(str);
	if(flag){
		ch.info=$.CommonLan["ip_err"];return;
	}
	ch.val = true;
}
//检查ip合法性(不可以为空)
function check_ip(ch){
	var str = ch.data;
	var reg=new RegExp(regMap.ip);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["ip_err"];return;
	}
	ch.val = true;
}
//检查mac合法性(xn:xx:xx:xx:xx:xx,n!=13579bdfBDF)
function check_mac(ch){
	var str = ch.data;
	var reg=new RegExp(regMap.mac);
	var flag = reg.test(str);
	if(!flag||str=='00:00:00:00:00:00'){
		ch.info=$.CommonLan["mac_addr_err"];return;
	}
	ch.val = true;
}
//检查dns合法性(可以为空)
function check_dns(ch){
	var str = ch.data;
	var reg=new RegExp(regMap.dns);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan['ip_err'];return;
	}
/* 	var str2=str.split(".");
	if(str2[0]==127||str2[3]==0||str2[3]==255){
		ch.info=$.CommonLan["ip_err"];return;
	} */
	ch.val = true;
}

//检查mask合法性
function check_mask_wan(ch){
	check_mask(ch);
}
function check_mask(ch){
	var str = ch.data;
	var strsub=str.split(".");
	if(str==""||str=="0.0.0.0"||str=="255.255.255.255"||strsub.length != 4){
		ch.info=$.CommonLan["mask_addr_err"];return;
	}
	for(var j=0;j<strsub.length;j++){
		if(strsub[j]!=0 && strsub[j]!=128 && strsub[j]!=192 && strsub[j]!=224 && strsub[j]!=240 && strsub[j]!=248 && strsub[j]!=252 && strsub[j]!=254 && strsub[j]!=255 ||strsub[j]==''||strsub[j]==' '){
			ch.info=$.CommonLan["mask_addr_err"];return;
		}
	}
	if(strsub[0]!=255 && strsub[1]!=0){
		ch.info=$.CommonLan["mask_addr_err"];return;
	}
	if(strsub[1]!=255 && strsub[2]!=0){
		ch.info=$.CommonLan["mask_addr_err"];return;
	}
	if(strsub[2]!=255 && strsub[3]!=0){
		ch.info=$.CommonLan["mask_addr_err"];return;
	}
	if(strsub[3]==''){
		ch.info=$.CommonLan["mask_addr_err"];return;
	}
	ch.val = true;
}
function check_ipv6(ch){
	var str = ch.data;
	var reg=new RegExp(regMap.ipv6);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["ipv6_addr_err"];return;
	}
	ch.val = true;
}

//(可為空白)
function check_dnsv6(ch){
	var str = ch.data;
	var reg=new RegExp(regMap.dnsv6);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan['ipv6_addr_err'];return;
	}
	ch.val = true;
}
/**************************************************/
function IP2Bin(ip)
{
	var strIP = ip.toString(2);
	var len = strIP.length;
	if(len<8)
	{
		for(var i=0;i<8-len;i++){
			strIP = "0" + strIP;
		}
	}
	return strIP;
}
function GetIP(ip_str)
{
	var ip="";
	var obj={};
	var ip_arr = ip_str.split(".");
	for(var i=0;i<ip_arr.length;i++){
		obj["ip"+i]=parseInt(ip_arr[i],10);
		ip +=IP2Bin(obj["ip"+i])
	}
	return ip;
}
function GetSubnet(ip,mask){
	var sub = "";
	for(var i=0;i<4;i++){
		var arr1 = ip.split('.');
		var arr2 = mask.split('.');
		var sub_str = IP2Bin(parseInt(arr1[i],10).toString(2)) & parseInt(arr2[i],10);
		sub += IP2Bin(sub_str);
	}
	return sub;
}
function check_ip_mask(ip,mask,tag,flag){
	var index=0;
	var mask_str=GetIP(mask);
	for(var i=0;i<mask_str.length;i++){
		if(mask_str.charAt(i)=="0"){
			index=i
			break;
		}
	}
	var ip_str="",ip_temp="";
	ip_str=GetIP(ip);
	ip_temp=ip_str.substring(index,32);
	var cmp_str1="",cmp_str2="";
	for(var i=0;i<ip_temp.length;i++){
		cmp_str1 +="1";
		cmp_str2 +="0";
	}
	if(ip_temp==cmp_str1){
		checkShow(tag.text,$.CommonLan['Bcast_err']);
		return false;
	}
	if(ip_temp==cmp_str2){
		checkShow(tag.text,$.CommonLan['segment_err']);
		return false;
	}
	var subnet = AND(ip_str,mask_str);
	var bcast = XOR(subnet,mask_str);
	var sub_ten = parseInt(subnet,2).toString(10);
	var bct_ten = parseInt(bcast,2).toString(10);
	if(flag){
		var ip_ten = parseInt(GetIP(flag),2).toString(10);
		if(ip_ten<sub_ten||ip_ten>bct_ten){
			checkShow(tag.text,$.CommonLan['segment_err']);
			return false;
		}
	}
	return true;
}
//与运算（二进制） 
function AND(ip,mask){
	var str = '' ;
	for(var i=0;i<32;i++){
		var a = ip.substring(i,i+1);
		var b = mask.substring(i,i+1);
		if(a=='0'||b=='0'){
			str +='0';
		}else{
			str +='1';
		}
	}
	return str;
}
//异或运算(二进制)
function XOR(ip,mask){
	var str = '' ;
	for(var i=0;i<32;i++){
		var a = ip.substring(i,i+1);
		var b = mask.substring(i,i+1);
		if(a==b){
			str +='1';
		}else{
			str +='0';
		}
	}
	return str;
}
//二进制IP转换成点分十进制IP 
function NtoH(str){
	var data='';
	for(var i=0;i<str.length;i++){
		var st = str.substring(i,i+8);
		var ten = parseInt(st,2).toString();
		data += ten +"."; 
		i=i+7;
	}
	data = data.substring(0,data.length-1);
	return data;
}
/**************************************************/
//檢查空
function check_null(ch){
	ch.val = false;
	if(ch.data ==''){
		ch.info=$.CommonLan["string_space"];return;
	}
	ch.val = true;
}
//检查port合法性
function check_port(ch){
	var arr = ch.data.split(',');
	for(var i=0;i<arr.length;i++){
		var str = arr[i];
		var reg = new RegExp(regMap.port);
		flag = reg.test(str);
		if(!flag || str=='0'){
			ch.info = $.CommonLan['port_err'];return;
		}
	}
	ch.val = true;
}
function check_port_null(ch){
	var str = ch.data;
	if(str==" "){str='';}
	var reg = new RegExp(regMap.port_null);
	flag = reg.test(str);
	if(!flag || str=='0'){
		ch.info = $.CommonLan['port_err'];return;
	}
	ch.val = true;
}
//检验密钥更新周期合法性(60-86400)
function check_key_time(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.keytime);
	flag = reg.test(str);
	if(!flag){
		ch.info = $.CommonLan['key_time_err'];return;
	}
	ch.val = true;
}
//检查DHCP续租时间(60-2592000)
function check_dhcp_time(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.dhcptime);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["lease_time_err"];return;
	}
	ch.val = true;
}
//檢查ACK Time必須為整數0~255(0:default, 單位:us 微秒)
function check_ack_timeout(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.ack_timeout);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["ack_timeout_err"];return;
	}
	ch.val = true;
}
function check_RfPower(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.rfPower);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["rfPower_err"];return;
	}
	ch.val = true;
}
//检查字符串 (不可以为空,不可以为汉字,不可以为空格)
function check_string(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.str);
	flag = reg.test(str);
	if(flag){
		ch.info=$.CommonLan["string_err"];return;
	}
	var reg1 = new RegExp(regMap.che);
	flag1 = reg1.test(str);
	if(flag1||!str){
		ch.info=$.CommonLan["string_null"];return;
	}
	var reg2 = new RegExp(regMap.che);
	flag2 = reg2.test(str);
	if(flag2){
		ch.info=$.CommonLan["string_nch"];return;
	}
	ch.val = true;
}
//检查字符串 (可以为空,不可以为汉字)
function check_string_null(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.str);
	flag = reg.test(str);
	if(flag){
		ch.info=$.CommonLan["string_err"];return;
	}
	var reg1 = new RegExp(regMap.che);
	flag1 = reg1.test(str);
	if(flag1){
		ch.info=$.CommonLan["string_nch"];return;
	}
	ch.val = true;
}

function check_keyboard_pass(ch){
	ch.val = false;
	var str = ch.data;
	var reg = new RegExp(regMap.keyboard_pass);
	flag = reg.test(str);
	if(!flag&&str!=''){
		ch.info=$.CommonLan["_lock_error"];return;
	}
	ch.val = true;
}
//检查字符串 (不可以为空,a-z,0-9)
function check_az09_string(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.az09);
	flag = reg.test(str);
	if(!flag||str==''){
		ch.info=$.CommonLan["az09_string_err"];return;
	}
	ch.val = true;
}
//檢查SSID (開頭結尾不可為空, 不可為中文)
function check_string_ssid(ch){
	ch.val = false;
	var str = ch.data;
	var reg = new RegExp(regMap.wl_ssid);
	flag = reg.test(str);
	if(flag){
		ch.info=$.CommonLan["string_space"];return;
	}
	var reg1 = new RegExp(regMap.che);
	flag1 = reg1.test(str);
	if(flag1){
		ch.info=$.CommonLan["string_nch"];return;
	}
/* 	var reg2 = new RegExp(regMap.sql_injec);
	flag2 = reg2.test(str);
	if(flag2){
		ch.info=$.CommonLan["string_sql_injec"];return;
	} */
	ch.val = true;
}
//检查域名
function check_domain(ch){
	var str = ch.data;
	var obj = str.split('.');
	for(var i=0;i<obj.length;i++){
		if (obj[i].length >63) {
			ch.info=$.CommonLan["domain_err"];return;
		}
	}
	var reg = new RegExp(regMap.domain);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["domain_err"];return;
	}
	ch.val = true;
}
//检查DNS过滤关键字合法性
function check_url(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.url);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["string_url_err"];return;
	}
	ch.val = true;
}
//检查十六进制合法性
function check_hex(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.hex);
	flag = reg.test(str);
	if(!flag){
		ch.info=$.CommonLan["string_hex_err"];return;
	}
	ch.val = true;
}
//验证QOS带宽
function check_qos_bandwidth(ch){
	var str = ch.data;
	if(str.length > 1 && str.substring(0,1) == '0'){
		ch.info = $.CommonLan["qos_band_err"];return;
	}
	var reg = new RegExp(regMap.limit12799);
	flag = reg.test(str);
	if(!flag){
		ch.info = $.CommonLan["qos_band_err"];return;
	}
	ch.val = true;
}
//验证pin码
function check_pin(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.pin);
	flag = reg.test(str);
	if(!flag){
		ch.info = $.CommonLan["pin_number_err"];return;
	}
	ch.val = true;
}
function check_page_size(ch){
	var str = ch.data;
	var reg = new RegExp(regMap.page);
	flag = reg.test(str);
	if(!flag){
		ch.info = $.CommonLan['page_err'];return;
	}
	ch.val = true;
}
//检查0~4094的整数 
function check_num4094(ch){
	var str = ch.data;
	if( parseInt(str)==9 || parseInt(str)==8){
		ch.info = $.CommonLan["int_number_err"];return;
	}
	var reg = new RegExp(regMap.num4094);
	flag = reg.test(str);
	if(!flag||str==''){
		ch.info = $.CommonLan["int_number_err"];return;
	}
	ch.val = true;
}
/********************************************************/
//检查mtu合法性
function check_mtu(ch){
	var max = 1492;
	if ($.CurrentApp == 'wan') {
		var type = getTag(3,'type').data;
		var p=3, t=9;
	} else {
		var type=$.CurrentApp;
		if ($.CurrentApp == 'modem') {var p=0, t=7;}
		else if ($.CurrentApp == 'ipv6_configure') {var p=1, t=6;}
	}
	if ((typeof(mtu_mapping[type])) != 'undefined')
		max = mtu_mapping[type];
	check_limit_int(ch,getTag(p,t),mtu_mapping.min,max);
}
//检查路由器连接数
function check_router_num(ch){
	check_limit_int(ch,getTag(0,0),100,1024,'router_err');
}
/*************************** End Common Check ************************/
function check_YMD(year,mon,day){
	var data = $.DataMap;
//	var yearArr = [parseInt(JQ.trim(data.version.split(',')[1].split('-')[0]),10), 2036];
	var yearArr = [parseInt(JQ.trim(" 2019"),10), 2036];
	if(!JQ.isNumeric(year) || (year<yearArr[0] || year>yearArr[1])){
		checkShow(ID("date"),(SpanLang($.CommonLan["year_err"],yearArr)));return;
	}

	var regM = new RegExp(regMap.mon);
	flagM = regM.test(mon);
	if(!flagM){
		checkShow(ID("date2"),$.CommonLan["mon_err"]);return;
	}
	mon = parseInt(mon,10);
	if (!JQ.isNumeric(day)){
		checkShow(ID("date3"),$.CommonLan["string_null"]);return;
	}
	day = parseInt(day,10);

	var dayArr = [1];
	switch (mon){
		case 1: case 3: case 5: case 7: case 8: case 10: case 12:
		if(day<1||day>31) dayArr[1] = 31;
		break;
		case 4: case 6: case 9: case 11:
			if(day<1||day>30) dayArr[1] = 30;
		break;
		case 2:
		if((year%4=='0' && year%100!='0')||year%400=='0'){ //闰年
			if(day<1||day>29) dayArr[1] = 29;
		}else if(day<1||day>28) dayArr[1] = 28;
		break;
	}
	if (dayArr[1] != undefined){
		checkShow(ID("date3"),(SpanLang($.CommonLan["day_err"],dayArr)));return;
	}
	return true;
}
function check_HMS(hour,min,sec){
	var regH = new RegExp(regMap.hour);
	flagH = regH.test(hour);
	if(!flagH){
		checkShow(ID("time"),$.CommonLan['hour_err']);return;
	}
	var regM = new RegExp(regMap.minsec);
	flagM = regM.test(min);
	if(!flagM){
		checkShow(ID("time2"),$.CommonLan['min_err']);return;
	}	
	var regS = new RegExp(regMap.minsec);
	flagS = regS.test(sec);
	if(!flagS){
		checkShow(ID("time3"),$.CommonLan['sec_err']);return;
	}
	return true;
}
function check_reboot_date(hour,min){
	var regH = new RegExp(regMap.hour);
	flagH = regH.test(hour);
	if(!flagH){
		checkShow(getTag(1,1).text,$.CommonLan['hour_err']);return;
	}
	var regM = new RegExp(regMap.minsec);
	flagM = regM.test(min);
	if(!flagM){
		checkShow(getTag(1,2).text,$.CommonLan['min_sec_err']);return;
	}

	return true;
}
function check_lan_ip_in_range(tag){
	var data = $.DataMap;
	var lan = GetIP(tag.text.entity.value);
	lan_ten = parseInt(lan,2).toString(10);
	dhcp_s = parseInt(GetIP(data.dhcpClientStart),2).toString(10);
	dhcp_e = parseInt(GetIP(data.dhcpClientEnd),2).toString(10);
	if(lan_ten<=dhcp_e&&lan_ten>=dhcp_s){
		checkShow(tag.text,$.CommonLan['lan_addr_err']);
		return false;
	}
	return true;
}
//验保留地址IP是否在DHCP池内 
function check_lan_ip(tag){
	var lan = GetIP(tag.text.entity.value);
	lan_ten = parseInt(lan,2).toString(10);
	dhcp_s = parseInt(GetIP($.DataMap.dhcpClientStart),2).toString(10);
	dhcp_e = parseInt(GetIP($.DataMap.dhcpClientEnd),2).toString(10);
	if(lan_ten>dhcp_e||lan_ten<dhcp_s){
		checkShow(tag.text,$.CommonLan['reserver_err']);
		return false;
	}
	return true;
}
//验证列表中添加IP重复 
function check_text_list(tag,list){
	var Rows = list.tab.tbody.Rows;
	for(var i=0;i<Rows.length;i++){
		if((Rows[0].data == MODData) && (MOD == "mod"))
			continue;
		
		if(Rows[0].data[tag.name] == tag.text.entity.value) {
			var err = $.CommonLan['add_item_err'];
			if(tag.name=="ipAddr") err = $.CommonLan['ip_occupy_err'];
			checkShow(tag.text,err);
			return false;
		}
	}
	
	return true;
}
//检查IP地址池范围
function check_ip_limit(start,end,flag){
	var s = parseInt(GetIP(start.text.entity.value),2);
	var e = parseInt(GetIP(end.text.entity.value),2);
	var len = e - s + 1;
	if(s > e){
		checkShow(start.text,$.CommonLan['cmp_ip_err']);
		return false;
	}
	if(flag=='dhcp'){
		var lanIpAddr = $.DataMap.lanIpAddr;
		var lanSubMask = $.DataMap.lanSubMask;
		var dhcp_s = start.text.entity.value;
		var dhcp_e = end.text.entity.value;
		var sub   = AND(GetIP(lanIpAddr),GetIP(lanSubMask));
		var sub_a = AND(GetIP(dhcp_s),GetIP(lanSubMask));
		var sub_b = AND(GetIP(dhcp_e),GetIP(lanSubMask));
		if(sub!=sub_a){
			checkShow(start.text,$.CommonLan['lan_ip_err']);
			return false;
		}
		if(sub!=sub_b){
			checkShow(end.text,$.CommonLan['lan_ip_err']);
			return false;
		}
		if(!check_ip_mask(dhcp_s,lanSubMask,getTag(1,'dhcpClientStart'))){return;}
		if(!check_ip_mask(dhcp_e,lanSubMask,getTag(1,'dhcpClientEnd'))){return;}
		lan_ten = parseInt((GetIP(lanIpAddr)),2).toString(10);
		dhcp_st = parseInt(GetIP(dhcp_s),2).toString(10);
		dhcp_et = parseInt(GetIP(dhcp_e),2).toString(10);
		if(lan_ten>=dhcp_st&&lan_ten<=dhcp_et){
			checkShow(getTag(1,1).text,$.CommonLan['lan_addr_err']);
			var ent = getTag(1,2).text.entity;
			ent.style.border = "solid 1px #EA7E12";
			window.setTimeout(function(){
				ent.style.border = "solid 1px #d2d2d2";
			},6000);
			return false;
		}
		if(len>253){
			checkShow(end.text,$.CommonLan['addr_err']);
			return false;
		}
	}
	return true;
}
//验证纯数字范围
function check_limit_int(ch,tag,min,max){
	var val = parseInt(tag.text.entity.value,10);
	var reg = /^\d+$/;
	flag = reg.test(val);
	if(!flag){
		ch.info = SpanLang($.CommonLan['mtu_err'],[min,max]);return;
	}
	if(val<min ||val>max){
		ch.info = SpanLang($.CommonLan['mtu_err'],[min,max]);return;
	}
	ch.val = true;
}
//特殊值转换
var special_map = {"%":"%25","&":"%26","=":"%3D","+":"%2B"};
function check_special(val){
	var str = val;
	if(str==""||str ==null){return str;}
	var cmp = '%&=+';
	var tmp = '';
	for(var i=0;i<str.length;i++){
		var s = str.substring(i,i+1);
		if(cmp.indexOf(s)!='-1'){
			tmp += special_map[s];
			continue;
		}
		tmp += s;
	}
	return tmp;
}
//验证WAN口设置静态IP网段
function check_segment(p,t){
	var lan_ip = $.DataMap.lan_ip;
	var wan_ip = getTag(p,t).data;
	var mask = getTag(p,t+1).data;
	for(var i=0;i<lan_ip.split('.').length;i++){
		var a = wan_ip.split('.')[i];
		var b = lan_ip.split('.')[i];
		var m0 = mask.split('.')[0];
		var m1 = mask.split('.')[1];
		var m2 = mask.split('.')[2];
		var m3 = mask.split('.')[3];
		if(m3==0 && m0!=0 && m1!=0 && m2!=0 ){
			if(i==2){
				if(a == b){
					checkShow(getTagDom(p,t,'text'),$.CommonLan['ip_err']);
					return false;
				}
			}
		}else if(m2==0 && m0!=0 && m1!=0 && m3==0){
			if(i==1){
				if(a == b){
					checkShow(getTagDom(p,t,'text'),$.CommonLan['ip_err']);
					return false;
				}
			}
		}else if(m1==0 && m0!=0 && m2==0 && m3==0){
			if(i==0){
				if(a == b){
					checkShow(getTagDom(p,t,'text'),$.CommonLan['ip_err']);
					return false;
				}
			}
		}
	}
	var c = wan_ip.split('.')[3];
	if(c=="0"||c=="255"){
		checkShow(getTagDom(p,t,'text'),$.CommonLan['ip_err']);
		return false;
	}
	var gw = getTag(p,t+2).data.split('.')[3];
	if(gw=="0"||gw=="255"){
		checkShow(getTagDom(p,t+2,'text'),$.CommonLan['ip_err']);
		return false;
	}
	return true;
}

//检验静态路由表目的网络和子网掩码是否在同一网络
function check_subset(){
	var ip = getTagDom(0,1,"text").entity.value;
	var mask = getTagDom(0,2,"text").entity.value;
	var gw = getTag(0,3).data.split('.')[3];
	var ms = getTag(0,2).data.split('.')[3];
	var pp = getTag(0,1).data.split('.')[3];
	for(var i =3;i>=0;i--){
		var a = ip.split('.')[i]; 
		var b = mask.split('.')[i];
		if(i!=0 && b == 0 && a!=0){
			if(a!=b){
				checkShow(getTagDom(0,1,'text'),$.CommonLan['route_ip_err']);
				return false;
			}
		}
	}
	if(getTag(0,0).data=='1'){
		if(pp == "255"){
			checkShow(getTagDom(0,1,'text'),$.CommonLan['ip_err']);
			return false;
		}
	}else{
		if(ms == "255"|| ms==''){
			checkShow(getTagDom(0,2,'text'),$.CommonLan['mask_err']);
			return false;
		}
	}
	if(gw == '0'){
		checkShow(getTagDom(0,3,'text'),$.CommonLan['ip_err']);
		return false;
	}
	return true;
}

//网页内容控制
function setLabelHeight(p,t,h){
	getTagDom(p,t,'label').entity.style.height = h;
	getTagDom(p,t,'label').entity.style.lineHeight = h;
}
function initPageStatus(n){
	if($.CurrentApp=='lan_set'||$.CurrentApp=='reboot'
		||$.CurrentApp=='default'||$.CurrentApp=='update'
		||$.CurrentApp=='backup' || $.CurrentApp == 'wan'){
		return;
	}
	var Pans = $.Apps[$.CurrentApp].Pans;
	for(var i in Pans){
		if(checknobj(i)){
			continue;
		}
		if(Pans[i].display == '0'){
			Pans[i].hide();
		}else{
			Pans[i].show();
		}
	}
}
function check_port_limit(tag,proto){
	if( proto == protoval_map['TCP'] || proto == protoval_map['UDP'] || proto == null){
		var tag_a = tag.text_a;
		var tag_b = tag.text_b;
		if(!checkDom(tag_a,"text_port")){return false;}
		if(!checkDom(tag_b,"text_port_null")){return false;}
	}
	if(!port_compare(tag)){return false;}
	return true;
}
//验证前一个端口必须小于后一个端口
function port_compare(tag){
	var val_a = tag.text_a.entity.value;
	var val_b = tag.text_b.entity.value;
	if(parseInt(val_a)>parseInt(val_b)){
		checkShow(tag.text_b,$.CommonLan['cmp_port_err']);
		return false;}
	return true;
}

function time_compare(p,t){
	var sh = getTagDom(p,t,"s_hour").entity.value;
	var sm = getTagDom(p,t,"s_min").entity.value;
	var eh = getTagDom(p,t,"e_hour").entity.value;
	var em = getTagDom(p,t,"e_min").entity.value;
	if((sh+':'+sm) > (eh+':'+em)){
		checkShow(getTagDom(p,t,'e_hour'),$.CommonLan['end_time_err']);
		return false;
	}
	return true;
}
//字符串截取len指定长度 
function check_len(data,len){
	var le = data.replace(/[^\x00-\xff]/g,"**").length;
	if(le>len){
		var data = data.substring(0,len-(le-len));
	}
	return data;
}
function week_null_check(tag){
	var arr = tag.week_panel.chk_arr;
	if(tag.week_panel.chk_all.entity.checked != true){
		var chked = false;
		for(var i=0;i<arr.length;i++){
			if(arr[i].entity.checked == true)
				chked = true;
		}
		 if(!chked){
			checkShow(tag.week_panel,$.CommonLan['week_err']);
			return false;
		}
	}
	return true;
}
//验证外部和内部端口长度必须一样 
function check_port_len(tag1,tag2){
	var start1 = parseInt(tag1.text_a.entity.value,10);
	var end1= parseInt(tag1.text_b.entity.value,10);
	var len1 = (end1)?(end1-start1+1):(1);
	var start2 = parseInt(tag2.text_a.entity.value,10);
	var end2 = parseInt(tag2.text_b.entity.value,10);
	var len2 = (end2)?(end2-start2+1):(1);
	if(len1!=len2){
		checkShow(tag2.text_a,$.CommonLan['port_len_err']);
		return false;
	}
	return true;
}
//验证虚拟服务添加修改重复
function check_vir_tab(){
	var List = $.DataMap.virtual_server_list;
	var list = new Array();
	obj2obj(list,List);
	if(MOD=='mod'){
		list.splice(MODData.id-1,1);
	}
	var ip = getTag(0,1).data;
	var proto = getTag(0,2).data;
	var port1 = get_port_arr_value(getTag(0,3));
	var port2 = get_port_arr_value(getTag(0,4));
	for(var i=0;i<list.length;i++){
		if(ip == list[i].vir_ip&&proto ==list[i].vir_proto&&port1 == list[i].vir_outport&&port2 ==list[i].vir_inport){
			$.lockWin(" ");
			$.unlockWin($.CommonLan["add_item_err"]);
			return false;
		}
	}
	return true;
}
//获取端口值
function get_port_arr_value(tag){
	var s_port = tag.text_a.entity.value;
	var e_port = tag.text_b.entity.value;
	var port =(!parseInt(e_port) ||s_port == e_port)?s_port:s_port +"-"+e_port;
	return port;
}
function emu_countdown(msg)
{
	if($.LockTime < 6){
		$.LockTime += 1;
		$.Lock.load.html(msg +":"+ $.LockTime + ' seconds');
		timeoutID_emu = setTimeout(function(){emu_countdown(msg);},1000);
	}else{
		$.unlockWin($.CommonLan['_save_success']);
		clearTimeout(timeoutID_emu);
	}
}
// dync change language
function SpanLang(str, arr)
{
	if (str.indexOf('%d')!= -1)
	{
		var len = str.split('%d').length-1;
		for (var i=0; i<=len; i++)
		{
			str = str.replace('%d',arr[i]);
		}
	}else if (str.indexOf('%s')!= -1){
		var len = str.split('%s').length-1;
		
		for (var i=0; i<=len; i++)
		{
			var tmp = '%s';
			if (str.indexOf(tmp)==0) arr[i]+=' ';
			if (str.indexOf(tmp)==str.length-2) arr[i] =' '+arr[i];
			str = str.replace(tmp,arr[i]);
		}
	}
	return str;
}
// 隐藏/显示添加表单的取消按钮（data为0是隐藏，1是显示） 
function SetCancelBtn(tag,data){
	var val = (data=='0')?"none":"";
	tag.btn_b.entity.style.display = val;
}
function cancel_modfiy(){$.Refresh();}
function R(fav, def){return fav ? fav : def;}

// device detection
var mobnav = navigator.userAgent||navigator.vendor||window.opera;
if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(mobnav) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s)|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg(g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(mobnav.substr(0,4))) isMobile = true;

function resize_content()
{
		var fn = JQ('#f_nav').outerHeight();
		var fb = JQ('.f_bottom').outerHeight();
		var ah =  JQ("#all_h").height();
		
		JQ("#full_center").height(ah-fn-fb);
		JQ('.f_center').outerHeight(ah-fn-fb);
}
function acc_terminal()
{
	var arr = ["p_menu_workmode","p_menu_ipv6","p_menu_usb_settings",
				"p_menu_vlan",
				"p_menu_qos","p_menu_forward","p_menu_management",
				"p_menu_ddns","p_menu_advanceSetup","c_menu_eth_wan",
				"p_menu_tr069_config",
				"c_menu_address_reservation","c_menu_opmode","c_menu_modem",
				"c_menu_backup","c_menu_diagnostic","c_menu_remote",
				"c_menu_sys_time","c_menu_statistics","c_menu_sys_log",
				"c_menu_watchdog","c_menu_schedule","c_menu_update"
				];
	if ($.SUPPORT_MULTI_WAN == 1)
		arr.push('p_menu_network');
	hideMenu(arr,1);
}
function hideMenu(arr,ishide){
	for(var i=0; i < arr.length; i++){
		if (JQ('#'+arr[i])[0])
		{
			var tmp = JQ('#'+arr[i])[0].id;
			if(ishide==1)
				JQ('#'+tmp).hide();
			else
				JQ('#'+tmp).show();
		}
	}
}

function lang_str_mapping()
{
	switch (true)
	{
		case (brwlang.indexOf('CN') != -1): sys_lang = 'CN'; break;
		case (brwlang.indexOf('TW') != -1): sys_lang = 'TW'; break;
		case (brwlang.indexOf('ZH-') != -1): sys_lang = 'TW'; break;
		case (brwlang.indexOf('EN') != -1): sys_lang = 'US'; break;
		case (brwlang.indexOf('ES') != -1): sys_lang = 'ES'; break;
		case (brwlang.indexOf('DE') != -1): sys_lang = 'DE'; break;
		case (brwlang.indexOf('FR') != -1): sys_lang = 'FR'; break;
		case (brwlang.indexOf('PT') != -1): sys_lang = 'PT'; break;
		case (brwlang.indexOf('IT') != -1): sys_lang = 'IT'; break;
		case (brwlang.indexOf('NL') != -1): sys_lang = 'NL'; break;
		case (brwlang.indexOf('RU') != -1): sys_lang = 'RU'; break;
		default: sys_lang = brwlang; break;
	}
	for (var i in CUS.Lang_map)
	{
		if (CUS.Lang_map[i] == sys_lang) {sys_lang = i; break;}
	}
	if (typeof(CUS.Lang_map[sys_lang]) == "undefined") sys_lang ='1';
	return sys_lang;
}
// SJ:::debug_multi_single
function debug_multi_single()
{
	var arr = ["p_menu_workmode","c_menu_eth_wan","c_menu_opmode","p_menu_network","c_menu_lan","p_menu_wireless","p_menu_wireless5g"];
	hideMenu(arr,0);
}

function comb_wan_type()
{
	var def = $.DataMap.wan[0];
	if (def.type == 1 && def.dhcp == 0) $.DataMap.wan[0].type = '20';
	if (def.type == 1 && def.dhcp == 1) $.DataMap.wan[0].type = '21';
	if (def.type == 2 && def.dhcp != 2) $.DataMap.wan[0].type = '22';

	if (def.ipv6Type == 1 && def.ipv6Dhcp == 0) $.DataMap.wan[0].ipv6Type = '23';	//autoconfig
	if (def.ipv6Type == 1 && def.ipv6Dhcp == 1) $.DataMap.wan[0].ipv6Type = '24';	//static
	if (def.ipv6Type == 2) $.DataMap.wan[0].ipv6Type = '25';	//pppoev6
}
function dis_wan_type(obj)
{
	switch(obj.type){
		case '2': obj.dhcp = '2'; break;
		case '20': obj.type = '1'; obj.dhcp = '0'; break;
		case '21': obj.type = '1'; obj.dhcp = '1'; break;
		case '22': obj.type = '2'; break;
		default: break;
	}
	switch(obj.ipv6Type){
		case '23': obj.ipv6Type = '1'; obj.ipv6Dhcp = '0'; break;
		case '24': obj.ipv6Type = '1'; obj.ipv6Dhcp = '1'; break;
		case '25': obj.ipv6Type = '2'; obj.ipv6Dhcp = '0'; break;
		default: break;
	}
	return obj;
}
function htmlstr(str)
{
	var tagArr = ['<','>'];
	var trArr = ['&lt;','&gt'];
	var tmp = '';

	str = Base64.decode(str);
	str = str.split('');
	
	for(var i in str){
		var st = false;
		for(var t in tagArr){
			if (str[i] == tagArr[t])
				st = trArr[t];
		}
		if (st == false) tmp += str[i];
		else tmp += st;
	}

	return tmp;
}